function medusaGpioDataSet(nodeid, port, value)
% function medusaGpioDataSet(nodeid, port, value)
%  port    = device port address, ie. 0,1,2...
%  value   = bitfield output value to set
%            bitvalue 0 => pin is LOW
%            bitvalue 1 => pin is HIGH
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global MEDUSA
global sock

concmd32(sock, nodeid, MEDUSA.CMD.GPIODATA, [value]);
