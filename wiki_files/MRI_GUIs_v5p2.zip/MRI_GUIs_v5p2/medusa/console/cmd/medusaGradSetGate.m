function medusaGradSetGate(nodeid, bitfield)
% function medusaGradSetGate(nodeid, bitfield)
% sets Gradient Board gating immediately
%  - bitfield is a 16-bit value controlling each of the 16 gating outputs
%  - For each bit, 0=gate off, 1=gate on
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

medusaRegWrite(nodeid, MEDUSA.REG.MAIN.GATE, bitfield);
