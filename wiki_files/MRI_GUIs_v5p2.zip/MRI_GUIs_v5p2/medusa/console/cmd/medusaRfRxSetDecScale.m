function medusaRfRxSetDecScale(nodeid,dec1,scale1,dec2,scale2,dec3)
% function medusaRfRxSetDecScale(nodeid,dec1,scale1,dec2,scale2,dec3)
%  > dec1   = 2 to 16
%  > scale1 = 0 to 6
%  > dec2   = 1 to 32
%  > scale2 = 0 to 20
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% enforce limits
if( (dec1 < 2) | (dec1 > 16) )
	fprintf('rfSetRxDecScale: dec1 out of bounds = %d\n', dec1);
	dec1 = max(dec1,2);
	dec1 = min(dec1,16);
end
if( (dec2 < 1) | (dec2 > 32) )
	fprintf('rfSetRxDecScale: dec2 out of bounds = %d\n', dec2);
	dec2 = max(dec2,1);
	dec2 = min(dec2,32);
end
if( dec3 ~= 10 )
	fprintf('rfSetRxDecScale: warning: dec3 does not equal 10\n');
end
if( (scale1 < 0) | (scale1 > 6) )
	fprintf('rfSetRxDecScale: scale1 out of bounds = %d\n', scale1);
	scale1 = max(scale1,0);
	scale1 = min(scale1,6);
end
if( (scale2 < 0) | (scale2 > 20) )
	fprintf('rfSetRxDecScale: scale1 out of bounds = %d\n', scale2);
	scale2 = max(scale2,0);
	scale2 = min(scale2,20);
end

global sock
global MEDUSA
concmd32(sock, nodeid, MEDUSA.CMD.DDRDECSCALE1, [dec1 scale1]);
concmd32(sock, nodeid, MEDUSA.CMD.DDRDECSCALE2, [dec2 scale2]);
concmd32(sock, nodeid, MEDUSA.CMD.DDRDEC3, [dec3 0]);

