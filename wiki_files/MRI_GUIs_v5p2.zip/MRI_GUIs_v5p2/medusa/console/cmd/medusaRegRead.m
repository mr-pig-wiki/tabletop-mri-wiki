function value = medusaRegRead(nodeid,regaddr)
% function value = medusaRegRead(nodeid,regaddr)
%  > nodeid = address of controller/module
%  > regaddr = address of register
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% issue command
packet = concmd32Read(sock, nodeid, MEDUSA.CMD.RAWREG, [regaddr 0]);
value = packet(2);
