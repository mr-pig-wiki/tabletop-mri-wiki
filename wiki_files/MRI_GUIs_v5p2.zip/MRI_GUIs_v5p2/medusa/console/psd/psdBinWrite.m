function psdBinWrite(psd, filename)
% function psdBinWrite(psd, filename)
% write PSD as binary files (for use with 'medusasx')
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% setup output fid
%fid = MEDUSA.FID;
fid = 1;

% ----------------------------------------------------
% determine channel count(s)
psd.rftx.nch = size(psd.rftx.data,1);
psd.rfrx.nch = size(psd.rfrx.data,1);
psd.grad.nch = floor(size(psd.grad.data,1)/5);

% intro
fprintf(fid,'----- PsdBinWrite Utility -----\n');
if( (psd.rftx.nch > 1) | (psd.rfrx.nch > 1) | (psd.grad.nch > 1) )
	fprintf(fid,'  WARNING: Your PSD uses mutli-channel RF Tx/Rx which may not be handled properly.\n');
	fprintf(fid,'  Press any key to continue...\n');
	pause
end
% prepare PSD data
fprintf(fid,'  Preparing PSD data...');
% make version
psdversion = hex2dec('00009406');
chksum = bitshift(psdversion,0,8) + bitshift(psdversion,-8,8) + bitshift(psdversion,-16,8);
psdversion = psdversion + bitshift(bitand(chksum,hex2dec('FF')),24,32);
%dec2hex(psdversion)
% make psd data
psddata = [ psdversion psd.id ...
			psd.ctrl.nodeid psd.ctrl.smpclk psd.ctrl.trlength psd.ctrl.ntrs ...
			psd.grad.nodeid psd.grad.nch psd.grad.smpclk psd.grad.start psd.grad.length ...
			psd.rftx.nodeid psd.rftx.nch psd.rftx.smpclk psd.rftx.start psd.rftx.length psd.rftx.freq psd.rftx.gain ...
			psd.rfrx.nodeid psd.rfrx.nch psd.rfrx.smpclk psd.rfrx.start psd.rfrx.length psd.rfrx.freq psd.rfrx.gain ...
		];
% save psd data
fprintf(fid,'Writing PSD file...');
mfid = fopen(['psd/' filename '_psd.bin'],'wb','n'); % n=native endian, b=big endian
stat = fwrite(mfid, psddata, 'uint32');
fclose(mfid);
fprintf(fid,'done.\n');
% ----------------------------------------------------
fprintf(fid,'  Preparing RFTX data...');
% translate data into DDS format
% 12-bit amplitude (0-4095)
% 14-bit phase (0-16384)
txdata = uint16([abs(psd.rftx.data)*4095; mod(round(angle(psd.rftx.data)*16384/(2*pi)), 16384);]);
txdata = (reshape(txdata,size(txdata,1)*size(txdata,2),1));
% save rftx data
fprintf(fid,'Writing RFTX file (%1.0f samples)...', length(txdata)/2);
mfid = fopen(['psd/' filename '_rftx.bin'],'wb','n'); % n=native endian, b=big endian
stat = fwrite(mfid, txdata, 'uint16');
fclose(mfid);
clear txdata;
fprintf(fid,'done.\n');
% ----------------------------------------------------
fprintf(fid,'  Preparing GRAD data...');
% translate data into gradient format
%psd.grad.data(1,:) = mod((psd.grad.data(1,:)*32767) + 32768, 65536);
%psd.grad.data(2,:) = mod((psd.grad.data(2,:)*32767) + 32768, 65536);
%psd.grad.data(3,:) = mod((psd.grad.data(3,:)*32767) + 32768, 65536);
%psd.grad.data(4,:) = mod((psd.grad.data(4,:)*32767) + 32768, 65536);
psd.grad.data(1:4,:) = (psd.grad.data(1:4,:)*32767);
psd.grad.data = (reshape(psd.grad.data,size(psd.grad.data,1)*size(psd.grad.data,2),1));

% save rftx data
fprintf(fid,'Writing GRAD file (%1.0f samples)...', length(psd.grad.data)/5);
mfid = fopen(['psd/' filename '_grad.bin'],'wb','n'); % n=native endian, b=big endian
stat = fwrite(mfid, psd.grad.data, 'int16');
fclose(mfid);
fprintf(fid,'done.\n');
% ----------------------------------------------------

%txdata(500000+(1:20))
%grdata(1:50)
