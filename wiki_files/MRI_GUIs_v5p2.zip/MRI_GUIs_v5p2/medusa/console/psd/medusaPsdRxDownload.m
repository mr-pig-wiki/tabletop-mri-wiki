function psd = medusaPsdRxDownload(psd)
% function psd = medusaPsdRxDownload(psd)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% setup output fid
fid = MEDUSA.FID;

fprintf(fid,'MEDUSA: ----- PSD Rx Download (ID# %1.0f) -----\n', psd.id);

% determine number of channels of data
if(isfield(psd,'rfrx')) rfrx_nch = size(psd.rfrx.data,1); else rfrx_nch=0; end;

% get received RF data for each channel
if(rfrx_nch)
	fprintf(fid,'MEDUSA: Downloading NTRs = %1.0f\n', psd.ctrl.ntrs);
	for ch = 1:rfrx_nch
		nodeid = psd.rfrx.nodeid + hex2dec('100')*(ch-1);
		% get rx data
		samples = psd.ctrl.ntrs * psd.rfrx.length;
		fprintf(fid,'MEDUSA: RFRx Ch#%1.0f: Getting  %7.0f samples...', ch, samples );
		psd.rfrx.data(ch,:) = medusaRfRxRead(nodeid, samples);
		fprintf(fid,'Done.\n');
		%psd.rfrx.data(ch,:) = medusaRfRxReadStream(psd.rfrx.nodeid, psd.ctrl.ntrs * psd.rfrx.length);
	end
end
