function medusaPsdConfigure(psd)
% function medusaPsdConfigure(psd)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% notes:
% RF Rx is subchannel 0
% RF Tx is subchannel 1
% RF Rx Buffer Write is subchannel 0
% RF Rx Buffer Read  is subchannel 1 (for us to read)
% RF Tx Buffer Read  is subchannel 2
% RF Tx Buffer Write is subchannel 3 (for us to write)

global sock
global MEDUSA

% setup output fid

fid = MEDUSA.FID;

% how many TRs?
%ntrs = floor(size(psd.grad.data,2)/psd.grad.length);
fprintf(fid,'MEDUSA: ----- PSD Configure (ID# %1.0f) -----\n', psd.id);
fprintf(fid,'MEDUSA: NTRs = %1.0f\n', psd.ctrl.ntrs);

% determine number of channels of data
if(isfield(psd,'rftx')) rftx_nch = size(psd.rftx.data,1); else rftx_nch=0; end;
if(isfield(psd,'rfrx')) rfrx_nch = size(psd.rfrx.data,1); else rfrx_nch=0; end;
if(isfield(psd,'grad')) grad_nch = floor(size(psd.grad.data,1)/5); else grad_nch=0; end;
if(isfield(psd,'vmod')) vmod_nch =  ceil(size(psd.vmod.data,1)/5); else vmod_nch=0; end;

% do console setup
% get system clock frequency
sysclk = medusaGetSysclk(psd.ctrl.nodeid);

fprintf(fid,'MEDUSA: System Clock       = %8.0f MHz\n', sysclk/1000000);
fprintf(fid,'MEDUSA: Ctrl Sampling Freq = %8.0f Hz\n', psd.ctrl.smpclk);
smpclk_list = psd.ctrl.smpclk;
if(grad_nch) fprintf(fid,'MEDUSA: Grad Sampling Freq = %8.0f Hz\n', psd.grad.smpclk); smpclk_list = [smpclk_list psd.grad.smpclk]; end;
if(vmod_nch) fprintf(fid,'MEDUSA: Vmod Sampling Freq = %8.0f Hz\n', psd.vmod.smpclk); smpclk_list = [smpclk_list psd.vmod.smpclk]; end;
if(rftx_nch) fprintf(fid,'MEDUSA: RFtx Sampling Freq = %8.0f Hz\n', psd.rftx.smpclk); smpclk_list = [smpclk_list psd.rftx.smpclk]; end;
if(rfrx_nch) fprintf(fid,'MEDUSA: RFrx Sampling Freq = %8.0f Hz\n', psd.rfrx.smpclk); smpclk_list = [smpclk_list psd.rfrx.smpclk]; end;

if( psd.ctrl.smpclk == smpclk_list )
	if( rfrx_nch > 0 )
		fprintf(fid,'MEDUSA: All sample clocks are equal to RFRx SMPCLK. Using RFRx as master.\n');
		smpclk_global_rfrx = 1;
	else
		fprintf(fid,'MEDUSA: All sample clocks are equal to Ctrl SMPCLK.\n');
		smpclk_global_rfrx = 0;
	end
else
	fprintf(fid,'MEDUSA: WARNING: Sample clocks are not equal. Sync problems could result.\n');
	smpclk_global_rfrx = 0;
end
	
% configure all transmit channels
fprintf(fid,'MEDUSA: Configuring %1.0f RF Transmit channel(s)\n', rftx_nch);
for ch = 1:rftx_nch
	nodeid = psd.rftx.nodeid + hex2dec('100')*(ch-1);
	% disable TR control and MSYNC trigger
	medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC | MEDUSA.REG.TRCTRL.CTRL_ENABLE);
	% clocking
	if(smpclk_global_rfrx == 1)
		% configure module to accept external sample clock
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_OE);
		% turn off local sample clock generator
		medusaSetSmpclk(nodeid, 0);
		% disable smpclk resync
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_RESYNC);
	else
		% configure module to disable drive of external sample clock
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_OE);
		% configure module's local clock generator
		medusaSetSmpclk(nodeid, psd.rftx.smpclk);
		% disable smpclk resync
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_RESYNC);
	end
	% set RF parameters
	medusaRfTxSetFreq(nodeid, psd.rftx.freq);
	% set TR length
	medusaSetTrLength(nodeid, psd.ctrl.trlength);
	% set TR window for RF
	medusaSetTrInterval(nodeid+1, psd.rftx.start, psd.rftx.length);
	% enable TR control
	medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_ENABLE);
	% set PGA, if setting available
	if(isfield(psd.rftx,'gain'))
		medusaPgaGainSet(nodeid, ch-1, psd.rftx.gain);
	end
end
% configure all receive channels
fprintf(fid,'MEDUSA: Configuring %1.0f RF Receive channel(s)\n', rfrx_nch);
for ch = 1:rfrx_nch
	nodeid = psd.rfrx.nodeid + hex2dec('100')*(ch-1);
	% disable TR control and MSYNC trigger
	medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC | MEDUSA.REG.TRCTRL.CTRL_ENABLE);
	% clocking
	if(smpclk_global_rfrx == 1)
		% configure module to accept external sample clock
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_OE);
		% turn off local sample clock generator
		medusaSetSmpclk(nodeid, 0);
		% disable smpclk resync
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_RESYNC);
	else
		% configure module to disable drive of external sample clock
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_OE);
		% configure module's local clock generator
		%medusaSetSmpclk(nodeid, psd.rfrx.smpclk);
		% disable smpclk resync
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_RESYNC);
	end
	% set RF parameters
	% for tuning, skip master channel -- will be done later
	if(ch ~= 1); medusaRfRxSetFreq(nodeid, psd.rfrx.freq); end;
	% set sample rate and gain for Rx
	psd.rfrx.smpclka = medusaRfRxSetRate(nodeid, psd.rfrx.smpclk, psd.rfrx.gain, sysclk);
	if( psd.rfrx.smpclka == psd.rfrx.smpclk )
		fprintf(fid,'MEDUSA: RFRx Ch#%1.0f SMPCLK can achieve perfect match to requested rate of %1.0f Hz\n', ch, psd.rfrx.smpclk);
	else
		fprintf(fid,'MEDUSA: WARNING: RFRx Ch#%1.0f SMPCLK cannot match requested %1.0f Hz. Using best match of %1.0f Hz.\n', ch, psd.rfrx.smpclk, psd.rfrx.smpclka);
	end
	% set TR length
	medusaSetTrLength(nodeid, psd.ctrl.trlength);
	% set TR window for RF
	medusaSetTrInterval(nodeid+0, psd.rfrx.start, psd.rfrx.length);
	% enable TR control
	medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_ENABLE);
end
if( rfrx_nch > 0 )
	% if master RF board present, enable SMPCLK output-enable
	% (this drives the SMPCLK onto the backbone bus)
	medusaRegBitSet(psd.rfrx.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_OE);
	% HACK: do freq retuning on master channel to sync all receiver NCOs
	% NOTE: could also just configure the RF boards in reverse order
	medusaRfRxSetFreq(psd.rfrx.nodeid, psd.rfrx.freq);
end

% configure all gradient boards/channels
fprintf(fid,'MEDUSA: Configuring %1.0f Gradient Board(s)\n', grad_nch);
for ch = 1:grad_nch
	nodeid = psd.grad.nodeid + hex2dec('100')*(ch-1);
	% disable TR control and MSYNC trigger
	medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC | MEDUSA.REG.TRCTRL.CTRL_ENABLE);
	% clocking
	if(smpclk_global_rfrx == 1)
		% configure module to accept external sample clock
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_OE);
		% turn off local sample clock generator
		%medusaSetSmpclk(nodeid, 0);
		medusaSetSmpclk(nodeid, psd.grad.smpclk);
		% disable smpclk resync
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_RESYNC);
	else	
		% configure module to disable drive of external sample clock
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_OE);
		% configure module's local clock generator
		medusaSetSmpclk(nodeid, psd.grad.smpclk);
		% disable smpclk resync
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_RESYNC);
	end
	% set TR length
	medusaSetTrLength(nodeid, psd.ctrl.trlength);
	% set TR window for gradients
	medusaSetTrInterval(nodeid+0, psd.grad.start, psd.grad.length);
	medusaSetTrInterval(nodeid+1, psd.grad.start, psd.grad.length);
	% set data lines to inverted operation, serclock divider to 4+1=5
	%medusaRegWrite(nodeid, MEDUSA.REG.MAIN.CONF, hex2dec('8E04'));
	% enable TR control
	medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_ENABLE);
end

% configure all vector modulator boards/channels
fprintf(fid,'MEDUSA: Configuring %1.0f Vector Modulator Board(s)\n', vmod_nch);
for ch = 1:vmod_nch
	nodeid = psd.vmod.nodeid + hex2dec('100')*(ch-1);
	% disable TR control and MSYNC trigger
	medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC | MEDUSA.REG.TRCTRL.CTRL_ENABLE);
	% clocking
	if(smpclk_global_rfrx == 1)
		% configure module to accept external sample clock
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_OE);
		% turn off local sample clock generator
		%medusaSetSmpclk(nodeid, 0);
		medusaSetSmpclk(nodeid, psd.vmod.smpclk);
		% disable smpclk resync
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_RESYNC);
	else	
		% configure module to disable drive of external sample clock
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_OE);
		% configure module's local clock generator
		medusaSetSmpclk(nodeid, psd.vmod.smpclk);
		% disable smpclk resync
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_RESYNC);
	end
	% set TR length
	medusaSetTrLength(nodeid, psd.ctrl.trlength);
	% set TR window for gradients
	medusaSetTrInterval(nodeid+0, psd.vmod.start, psd.vmod.length);
	medusaSetTrInterval(nodeid+1, psd.vmod.start, psd.vmod.length);
	% set data lines to inverted operation, serclock divider to 4+1=5
	%medusaRegWrite(nodeid, MEDUSA.REG.MAIN.CONF, hex2dec('8E04'));
	% enable TR control
	medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_ENABLE);
end

fprintf(fid,'MEDUSA: Configuring Controller\n');
% configure controller
nodeid = psd.ctrl.nodeid;
% disable TR control and MSYNC trigger
medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC | MEDUSA.REG.TRCTRL.CTRL_ENABLE);
% controller
if(smpclk_global_rfrx == 1)
	% configure module to accept external sample clock
	medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_OE);
	% turn off local sample clock generator
	medusaSetSmpclk(nodeid, 0);
	% disable smpclk resync
	medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_RESYNC);
else	
	% configure module to disable drive of external sample clock
	medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_OE);
	% configure controller's local clock generator
	medusaSetSmpclk(nodeid, psd.ctrl.smpclk);
	% disable smpclk resync
	medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_RESYNC);
	% by default, enable SMPCLK output-enable from controller
	% (this drives the SMPCLK onto the backbone bus)
	medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_SMPCLK_OE);
end
% set TR length
medusaSetTrLength(nodeid, psd.ctrl.trlength);
% enable TR control
medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_ENABLE);

