function psd = medusaPsdReduce(psd)
% function psd = medusaPsdReduce(psd)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% setup output fid
fid = MEDUSA.FID;

fprintf(fid,'MEDUSA: ----- PSD Reduce (ID# %1.0f) -----\n', psd.id);

% reformat
psd.rftx.data = reshape(psd.rftx.data, psd.rftx.length, psd.ctrl.ntrs)';
%psd.grad.data = reshape(psd.grad.data, psd.grad.length, psd.ctrl.ntrs)';
% reduce
rftx_start = psd.rftx.length;
rftx_end = 1;
grad_start = psd.grad.length;
grad_end = 1;
for ntr = 1:psd.ctrl.ntrs
	% do rf
	nzrange = find(psd.rftx.data(ntr,:) ~= 0);
	rftx_start = min( nzrange(1)-1, rftx_start );
	rftx_end   = max( nzrange(end)+1, rftx_end );
	% do grad
%	nzrange(1) = find(psd.grad.data(ntr,:) ~= 0);
%	grad_start = min( nzrange(1)-1, grad_start );
%	grad_end   = max( nzrange(end)+1, grad_end );
end
%rftx_start
%rftx_end
%len = rftx_end-rftx_start
% truncate
fprintf(fid, 'MEDUSA: Reduced RF Tx to interval [%1.0f %1.0f]\n', rftx_start, rftx_end);
psd.rftx.data = psd.rftx.data(:,rftx_start:rftx_end);
psd.rftx.start = rftx_start;
psd.rftx.length = 1+rftx_end-rftx_start;
% truncate
%psd.grad.data = psd.grad.data(:,grad_start:grad_end);
%psd.grad.start = grad_start;
%psd.grad.length = 1+grad_end-grad_start;
% reformat
%size(psd.rftx.data)
psd.rftx.data = reshape(psd.rftx.data', 1, psd.ctrl.ntrs*psd.rftx.length);
%psd.grad.data = reshape(psd.grad.data', 1, psd.ctrl.ntrs*psd.grad.length);
