function psd = psdBinReadRx(psd, filename)
% function psd = psdBinReadRx(psd, filename)
% read binary receive data from file (from 'medusasx') into PSD
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% setup output fid
%fid = MEDUSA.FID;
fid = 1;

% ----------------------------------------------------
% determine channel count(s)
psd.rfrx.nch = size(psd.rfrx.data,1);

% intro
fprintf(fid,'----- PsdBinReadRx Utility -----\n');
if( (psd.rfrx.nch > 1) )
	fprintf(fid,'  WARNING: Your PSD uses mutli-channel RF Tx/Rx which may not be handled properly.\n');
	fprintf(fid,'  Press any key to continue...\n');
	pause
end

% open file
fprintf(fid,'  Opening RFRX binary file...');
mfid = fopen(['psd/' filename '_rfrx.bin'],'rb','n'); % n=native endian, b=big endian
% read data in int16 format
fprintf(fid,'Reading RFRX file...');
rxdata = fread(mfid,inf,'int16');
% close file
fclose(mfid);
% convert to complex format
rxdata = rxdata(1:2:end) + i*rxdata(2:2:end);
% convert to row vector
rxdata = reshape(rxdata, 1, size(rxdata,1)*size(rxdata,2));
fprintf(fid,'done (%1.0f samples).\n', length(rxdata) );
% save data to PSD
psd.rfrx.data = rxdata./32768;

if(0)
figure(200)
hold off
plot(1:length(rxdata), real(rxdata), 'b');
hold on
plot(1:length(rxdata), imag(rxdata), 'r');
grid off
axis([1 length(rxdata) -32767 +32767])
legend('I','Q');
end
