function psd = psdRecon2dft(psd)
% function psd = psdRecon2dft(psd)
% performs simple recon on a 2DFT scan
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% setup output fid
%fid = MEDUSA.FID;
fid = 1;

% assumes that scan was 2DFT !!!
if( ~isfield(psd,'param') )
	fprintf(fid,'PsdRecon2dft: Cannot reconstruct, psd.params structure not present\n');
	return
end

% get scan parameters
nx = psd.param.Nro;
ny = psd.param.Npe;
% reconstruct each channel seperately
rfrx_nch = size(psd.rfrx.data,1);
for ch = 1:rfrx_nch
	% reformat data
	imk(:,:,ch) = reshape(psd.rfrx.data(ch,:), nx, ny);
	% reconstruct
	im(:,:,ch) = fft2c(imk(:,:,ch))';
end
% put the image(s) back into the psd
psd.img = im;

% crop
%im = im(:,floor(nx*0.35):floor(nx*0.85));
%im = im(:,floor(nx*0.25):floor(nx*0.75));
% window
range = [0 1.0];
% show
figure(psd.id+1)
for ch = 1:rfrx_nch
	subplot(1,rfrx_nch,ch);
	imshow(abs(im(:,:,ch)), range * max(max(abs(im(:,:,ch)))) );
	hold on
	title(sprintf('Image Ch%1.0f (%1.0f x %1.0f)', ch, nx, ny));
	xlabel(sprintf('Nro: %1.0f', psd.param.Nro));
	ylabel(sprintf('Npe: %1.0f', psd.param.Npe));
	hold off
end
if(0)
figure(6)
%imshow(abs( im(end:-1:1,: ) ),[]);
subplot(2,1,1);
%imshow(abs( rawm' ), []);
%imshow(abs( im(:,200:350) ),[0 0.3*max(max(abs(im(:,:)))) ]);
imshow(abs(im),[]);
subplot(2,1,2);
imshow(angle(im),[]);
end

% save data
psdSave(psd,'');
