function psd = medusaPsdRxDownload(psd)
% function psd = medusaPsdRxDownload(psd)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% setup output fid
fid = MEDUSA.FID;

fprintf(fid,'MEDUSA: ----- PSD Rx Download (ID# %1.0f) -----\n', psd.id);

% determine number of channels
if(isfield(psd,'rftx')) rftx_nch = size(psd.rftx.data,1); else rftx_nch=0; end;
if(isfield(psd,'rfrx')) rfrx_nch = size(psd.rfrx.data,1); else rfrx_nch=0; end;
if(isfield(psd,'grad')) grad_nch = floor(size(psd.grad.data,1)/5); else grad_nch=0; end;
if(isfield(psd,'vmod')) vmod_nch =  ceil(size(psd.vmod.data,1)/5); else vmod_nch=0; end;

% using broadcast address (see below)
if(0)
% disable triggers on all boards
for ch = 1:rftx_nch
	nodeid = psd.rftx.nodeid + hex2dec('100')*(ch-1);
	medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
end
for ch = 1:rfrx_nch
	nodeid = psd.rfrx.nodeid + hex2dec('100')*(ch-1);
	medusaRegBitClr(psd.rfrx.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
end
for ch = 1:grad_nch
	nodeid = psd.grad.nodeid + hex2dec('100')*(ch-1);
	medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
end
for ch = 1:vmod_nch
	nodeid = psd.vmod.nodeid + hex2dec('100')*(ch-1);
	medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
end
nodeid = psd.ctrl.nodeid;
medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
end

% use broadcast address to disable modules
nodeid = bitor(psd.ctrl.nodeid, hex2dec('FF00'));
medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);

% get received RF data for each channel
if(rfrx_nch)
	fprintf(fid,'MEDUSA: Downloading NTRs = %1.0f\n', psd.ctrl.ntrs);
	for ch = 1:rfrx_nch
		nodeid = psd.rfrx.nodeid + hex2dec('100')*(ch-1);
		% get rx data
		samples = psd.ctrl.ntrs * psd.rfrx.length;
		fprintf(fid,'MEDUSA: RFRx Ch#%1.0f: Getting  %7.0f samples...', ch, samples );
		psd.rfrx.data(ch,:) = medusaRfRxRead(nodeid, samples);
		fprintf(fid,'Done.\n');
		%psd.rfrx.data(ch,:) = medusaRfRxReadStream(psd.rfrx.nodeid, psd.ctrl.ntrs * psd.rfrx.length);
	end
end
