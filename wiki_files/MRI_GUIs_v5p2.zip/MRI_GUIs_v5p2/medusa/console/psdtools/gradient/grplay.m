% test gradient waveform generation tools
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

fs = 10000;
phase_time = 5e-3;
readout_time = 10e-3;

grwave = [];
%grwave = [grwave, grLobeRect(-0.1, 20)];
%grwave = [grwave, grLobeRect(+0.1, 20)];
%grwave = [grwave, grLobeRect(0, 20)];
%grwave = [grwave, grLobeTrap(-0.1, 4, 20)];
%grwave = [grwave, grLobeTrap(+0.1, 4, 20)];

grwave = [grwave, grLobeTrap(-50, 8, phase_time, fs)];
grwave = [grwave, grLobeTrap(+100, 8, readout_time, fs)];
grwave = [grwave, grLobeTrap(-50, 8, phase_time, fs)];

integral_gr = sum(grwave)

plot(0:(length(grwave)-1), grwave, 'r.-');
grid on