function [X] = Rxyz(X,angles,units)
%function [X] = Rxyz(X,angles,units)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

if ~exist('units','var'), units = 'radians'; end
% convert degrees to radians
if isequal(units,'degrees'),
	angles = angles*pi/180;
end

Rx =	[	1		0				0;
			0		+cos(angles(1))	-sin(angles(1));
			0		+sin(angles(1))	+cos(angles(1));	];

Ry =	[	+cos(angles(2))	0		+sin(angles(2));
			0				1		0;
			-sin(angles(2))	0		+cos(angles(2)); ];

Rz =	[	+cos(angles(3))	-sin(angles(3))	0;
			+sin(angles(3))	+cos(angles(3))	0;
			0				0				1; ];

R = (Rz * Ry * Rx);
		
if(size(X,1) == 3)
	X = R * X;
else if(size(X,2) == 3)
	X = (R * X')';
else
	error('Rxyz: Input X must be [N,3] or [3,N] matrix.\n');
end
end

return
