function im = ifftc(d)
% im = ifftc(d)
%
% ifftc performs a centered inverse fft
%
im = fftshift(ifft(fftshift(d)));