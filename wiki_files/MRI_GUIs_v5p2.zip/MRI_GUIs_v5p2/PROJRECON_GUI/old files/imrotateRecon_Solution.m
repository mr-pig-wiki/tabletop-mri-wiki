%% my projection reconstruction algorithm (modified from mine and Jeff's)

load('radial16projectionsreadout_offrescorrected.mat')

%%
% Take FFT just down the columns: 
imdom_projcol=fftshift(fft(fftshift(offrescorrected_data_projrecon,1),[],1),1); 

deg = all_angles(2:end)*180/pi;

for j=1:length(imdom_projcol(1,:))
    individ_backprojections(:,:,j)=ones(numel(imdom_projcol(:,1)),numel(imdom_projcol(:,2)))*diag(imdom_projcol(:,j));
    figure, imagesc(abs(individ_backprojections(:,:,j))), axis square, xlabel('FOV [pixels]'), colormap gray;
end

dtheta = deg(2)-deg(1);

imdom_projrecon = zeros(numel(imdom_projcol(:,1)),numel(imdom_projcol(:,2)),numel(deg));
%%
% Project 0 data
imdom_projrecon(:,:,1)=ones(numel(imdom_projcol(:,1)),numel(imdom_projcol(:,2)))*diag(imdom_projcol(:,1));
figure, imagesc(abs(imdom_projrecon(:,:,1))), axis square, colormap gray;


for a = 2:numel(deg)
    projrot = imrotate(imdom_projrecon(:,:,a-1),dtheta);
    cropamt = round((length(projrot(:,1)) - length(imdom_projrecon(:,:,1)))/2);
    projrotcrop = projrot(cropamt:cropamt+length(imdom_projrecon(:,:,1))-1,cropamt:cropamt+length(imdom_projrecon(:,:,1))-1);

    imdom_projrecon(:,:,a) = projrotcrop*diag(imdom_projcol(:,a));
    figure, imagesc(abs(imdom_projrecon(:,:,a))), axis square, colormap gray;
end

%%
I = iradon(abs(imdom_projcol),deg);
figure, imagesc(I);
colormap gray; axis square;