% ConMex - Medusa MR Console I/O Access for Matlab.
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

error('You need to compile conmex.c to a mex-file for your platform. Read the header of conmex.c');
