function value = concmd32Read(sock,nodeid,cmd,args32)
% function value = concmd32Read(sock,nodeid,cmd,[args32])
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global MEDUSA

% issue command
concmd32(sock, nodeid, cmd+MEDUSA.CMD.READ, [args32]);

% try to get response
value = NaN;
timeout = 50;
while(timeout > 0)
	packet = conmex('read', double(nodeid), 4);
	% if we get an empty packet, wait a moment, and try again
	if(packet == 0)
		pause(0.1);
		timeout = timeout-1;
		continue;
	end
	% if we get what we want, break right away
	if(length(packet) > 1)
		if(packet(2) == cmd+MEDUSA.CMD.READ)
			% get high/low words
%			valueL = packet(5:2:end);
%			valueH = packet(6:2:end);
			% take care of signed integer wrap
%			valueL(find(valueL < 0)) = valueL(find(valueL < 0)) + 65536;
%			valueH(find(valueL < 0)) = valueH(find(valueL < 0)) + 65536;
			% merge
%			value = valueL + 65536*valueH;
			value = packet(3:end);
			break;
		end
	end
end
