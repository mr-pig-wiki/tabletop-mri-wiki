% Medusa connect script
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global MEDUSA
medusaCommands

global sock
sock = conconnect('localhost');
