
%psdgen_p2dft

medusaPsdConfigure(psd);
psd = medusaPsdRun(psd);

if(0)
fprintf('Grad DMA Ptr: %1.0f\n', medusaDataGetPtr( psd.grad.nodeid+MEDUSA.SUB.GRAD.DMA_CH));
fprintf('Grad MEM Ptr: %1.0f\n', medusaDataGetPtr( psd.grad.nodeid+MEDUSA.SUB.GRAD.MEM_CH));
fprintf('RFRx DMA Ptr: %1.0f\n', medusaDataGetPtr( psd.rfrx.nodeid+MEDUSA.SUB.RFRX.DMA_CH));
fprintf('RFRx MEM Ptr: %1.0f\n', medusaDataGetPtr( psd.rfrx.nodeid+MEDUSA.SUB.RFRX.MEM_CH));
fprintf('RFTx DMA Ptr: %1.0f\n', medusaDataGetPtr( psd.rfrx.nodeid+MEDUSA.SUB.RFTX.DMA_CH));
fprintf('RFTx MEM Ptr: %1.0f\n', medusaDataGetPtr( psd.rfrx.nodeid+MEDUSA.SUB.RFTX.MEM_CH));
end
	
psdPlotOV(100,psd,0,-0.1);
refresh(100);
beep

if(1)
	psdPlotRX(psd.id+10,psd);
	psd = psdRecon2dft(psd);
end

