
% generate psd
psdgen_fo_cal
% setup medusa
medusaPsdConfigure(psd);
% run the sequence
psd = medusaPsdRun(psd);

% plot the sequence (now with receive data included)
psdPlotOV(100,psd,0,-0.1);
refresh(100);
beep

% reformat data
kdata_len = length(psd.rfrx.data)/psd.ctrl.ntrs;
kdata = reshape(psd.rfrx.data, kdata_len, psd.ctrl.ntrs);
% do pulse spectrum
spect = fftc(kdata(:,1)');
freq = (((0:(kdata_len-1))/kdata_len)-0.5) * psd.rfrx.smpclk;

figure(2)
subplot(2,1,1)
plot(freq, abs(spect), 'b.-');
axis([min(freq) max(freq) -0.1*max(max(abs(spect))) 1.1*max(max(abs(spect)))]);
grid on
ylabel('Signal Magn');
xlabel('Full-bandwidth -- Frequency Offset [Hz]');
title('Center Frequency Check');
hold off

subplot(2,1,2)
plot(freq, abs(spect), 'b.-');
axis([min(freq)/16 max(freq)/16 -0.1*max(max(abs(spect))) 1.1*max(max(abs(spect)))]);
grid on
ylabel('Signal Magn');
xlabel('Zoomed -- Frequency Offset [Hz]');
hold off

