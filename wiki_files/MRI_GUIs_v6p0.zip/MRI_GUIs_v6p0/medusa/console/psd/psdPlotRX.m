function psdPlotRX(fig,psd)
% function psdPlotRX(fig,psd)
% plot RF RX signal, back-to-back TRs, each channel on a separate subplot
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% set scaling
rfrx_hscale = 1000/psd.rfrx.smpclk;
rf_vscale = [-max(max(abs(psd.rfrx.data))) max(max(abs(psd.rfrx.data)))];

% plot RX
figure(fig)
clf
t = rfrx_hscale*((0):(size(psd.rfrx.data,2)-1));
nch = size(psd.rfrx.data,1);
for ch = 1:nch
	subplot(nch,1,ch)
	plot(t, real(psd.rfrx.data(ch,:)), 'r');
	hold on
	plot(t, imag(psd.rfrx.data(ch,:)), 'g');
	plot(t, abs(psd.rfrx.data(ch,:)), 'b');

	if(ch==1) title(sprintf('RF Receive Data - %1.0f TRs', psd.ctrl.ntrs)); end;
	
	for N = 1:psd.ctrl.ntrs
		% TR separator line
		tref = rfrx_hscale*(((N-1)*psd.rfrx.length));
		h=plot([tref tref], rf_vscale, 'k-');	
	end	
	axis([0 max(t) rf_vscale]);
	ylabel(sprintf('Ch %d',ch));
	hold off
end
grid off
%legend('Gx','Gy','Gz','RF Tx','RF Rx');

xlabel(sprintf('Relative Time [ms] - %1.0fus/sample', 1e6/psd.rfrx.smpclk));
