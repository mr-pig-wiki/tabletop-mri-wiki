function psdPlotRG(fig,psd)
% function psdPlotRG(fig,psd)
% plots RF and gradients on separate subplots
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% set scaling
rftx_hscale = 1000/psd.rftx.smpclk;
rfrx_hscale = 1000/psd.rfrx.smpclk;
grad_hscale = 1000/psd.grad.smpclk;
ctrl_hscale = 1000/psd.ctrl.smpclk;

%rf_hscale = 1000/psd.rfrx.smpclk;
%gr_hscale = 1000/psd.grad.smpclk;
rf_vscale = 1.1;
gr_vscale = 1.1;

% plot pulse sequence

figure(fig)
subplot(2,1,1)
hold off
for N = 1:psd.ctrl.ntrs
%for N = [ 1:round(psd.ctrl.ntrs/32):psd.ctrl.ntrs psd.ctrl.ntrs] 
	% rf tx
	if(size(psd.rftx.data,1))
		t = rftx_hscale*(psd.rftx.start+[1:psd.rftx.length])+ctrl_hscale*((N-1)*psd.ctrl.trlength);
		h=plot(t, real(psd.rftx.data(:, ((N-1)*psd.rftx.length)+(1:psd.rftx.length) )), 'r.-');
		set(h,'linewidth',2)
	end
	hold on
	% rf rx
	if(size(psd.rfrx.data,1))
		t = rfrx_hscale*(psd.rfrx.start+[1:psd.rfrx.length])+ctrl_hscale*((N-1)*psd.ctrl.trlength);
		h=plot(t, abs(psd.rfrx.data(:, ((N-1)*psd.rfrx.length)+(1:psd.rfrx.length))),'b');
		%h=plot(t, real(psd.rfrx.data( ((N-1)*psd.rfrx.length)+(1:psd.rfrx.length))),'c');
		%h=plot(t, imag(psd.rfrx.data( ((N-1)*psd.rfrx.length)+(1:psd.rfrx.length))),'m');
		set(h,'linewidth',1)
	end
	% reference lines
	% TR interval
	t = ctrl_hscale*(((N-1)*psd.ctrl.trlength));
	h=plot([t t], [-rf_vscale rf_vscale], 'k.-');
	% RF RX interval
	t = rfrx_hscale*(psd.rfrx.start+[1:psd.rfrx.length]);
	h=plot([min(t) min(t)], [-0.1 +0.1], 'k-');
	h=plot([max(t) max(t)], [-0.1 +0.1], 'k-');
	%h=plot(RF_start+[tref tref], [-1.1 1.1], 'k.-');
	%h=plot(RF_start+[tref+te/2 tref+te/2], [-1.1 1.1], 'k.-');
	%h=plot(RF_start+[tref+te tref+te], [-1.1 1.1], 'k.-');
end
axis([0 ctrl_hscale*psd.ctrl.ntrs*psd.ctrl.trlength -rf_vscale rf_vscale])
grid off
ylabel('RF Tx/Rx');
legend('RF Tx','RF Rx');

subplot(2,1,2)
hold off
for N = 1:psd.ctrl.ntrs
	% make gradient time axis
	t = grad_hscale*(psd.grad.start+[1:psd.grad.length])+ctrl_hscale*((N-1)*psd.ctrl.trlength);
	% gradient Gx
	h=plot(t, psd.grad.data(1, ((N-1)*psd.grad.length)+(1:psd.grad.length) ), 'r.-');
	set(h,'linewidth',1)
	hold on
	% gradient Gy
	h=plot(t, psd.grad.data(2, ((N-1)*psd.grad.length)+(1:psd.grad.length) ), 'g.-');
	set(h,'linewidth',1)
	% gradient Gz
	h=plot(t, psd.grad.data(3, ((N-1)*psd.grad.length)+(1:psd.grad.length) ), 'b.-');
	set(h,'linewidth',1)
	% reference lines
	t = ctrl_hscale*((N-1)*psd.ctrl.trlength);
	h=plot([t t], [-gr_vscale gr_vscale], 'k.-');
end
axis([0 ctrl_hscale*psd.ctrl.ntrs*psd.ctrl.trlength -gr_vscale gr_vscale])
grid off
ylabel('Gx/Gy/Gz');
legend('Gx','Gy','Gz');

subplot(2,1,1)
title(sprintf('Pulse Sequence - %1.0f TRs', psd.ctrl.ntrs));
xlabel(sprintf('Time [ms] - %1.0fus/sample', 1e6/psd.rfrx.smpclk));
subplot(2,1,2)
xlabel(sprintf('Time [ms] - %1.0fus/sample', 1e6/psd.grad.smpclk));
