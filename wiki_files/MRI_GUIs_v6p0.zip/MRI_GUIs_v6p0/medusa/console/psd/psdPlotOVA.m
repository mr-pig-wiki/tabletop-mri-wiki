function psdPlotOV(fig,psd,rf_offset,gr_offset)
% function psdPlotOV(fig,psd,rf_offset,gr_offset)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% set scaling
if( isfield(psd,'rftx') ); rftx_hscale = 1000/psd.rftx.smpclk; end;
if( isfield(psd,'rfrx') ); rfrx_hscale = 1000/psd.rfrx.smpclk; end;
if( isfield(psd,'grad') ); grad_hscale = 1000/psd.grad.smpclk; end;
if( isfield(psd,'ctrl') ); ctrl_hscale = 1000/psd.ctrl.smpclk; end;
if( isfield(psd,'vmod') ); vmod_hscale = 1000/psd.vmod.smpclk; end;
rf_vscale = 1.1;
gr_vscale = 1.1;

% plot handle and legend text trackers
legend_hndl = [];
legend_text = [];

% plot pulse sequence
figure(fig)
subplot(1,1,1)
hold off

% for speed and clarity, plot only up to 32 TRs, evenly spaced throughout
% the sequence.
plot_trs = 1:(1+floor(psd.ctrl.ntrs/32)):psd.ctrl.ntrs;
% make sure last TR is shown
if(plot_trs(end) ~= psd.ctrl.ntrs) plot_trs = [plot_trs psd.ctrl.ntrs]; end;

% plot *ALL* TRs in this version of the command
for N = 1:psd.ctrl.ntrs
%for N = plot_trs;

	% plot gradients
	if( isfield(psd,'grad') )
		% make gradient time axis
		%t = gr_hscale*(((N-1)*psd.ctrl.trlength)+psd.grad.start+[1:psd.grad.length]);
		t = grad_hscale*(psd.grad.start+[1:psd.grad.length]);
		% gradient Gx
		h=plot(t, gr_offset+psd.grad.data(1, ((N-1)*psd.grad.length)+(1:psd.grad.length) ), 'r.-');
		if(N==1); legend_hndl = [legend_hndl; h]; legend_text = [legend_text; 'Gx   ']; end;
		set(h,'linewidth',1)
		hold on
		% gradient Gy
		h=plot(t, gr_offset+psd.grad.data(2, ((N-1)*psd.grad.length)+(1:psd.grad.length) ), 'g.-');
		if(N==1); legend_hndl = [legend_hndl; h]; legend_text = [legend_text; 'Gy   ']; end;
		set(h,'linewidth',1)
		% gradient Gz
		h=plot(t, gr_offset+psd.grad.data(3, ((N-1)*psd.grad.length)+(1:psd.grad.length) ), 'b.-');
		if(N==1); legend_hndl = [legend_hndl; h]; legend_text = [legend_text; 'Gz   ']; end;
		set(h,'linewidth',1)
		% gating
		if( (max(max(psd.grad.data(5,:)))) > 0)
			h=plot(t, gr_offset+ 1/(max(max(psd.grad.data(5,:))))*psd.grad.data(5, ((N-1)*psd.grad.length)+(1:psd.grad.length) ), 'k.-');
			if(N==1); legend_hndl = [legend_hndl; h]; legend_text = [legend_text; 'Gate ']; end;
			set(h,'linewidth',1)
		end
	end

	% plot vector modulation
	if( isfield(psd,'vmod') )
		% make vmod time axis
		t = vmod_hscale*(psd.vmod.start+[1:psd.vmod.length]);
		% vmod
		%for(ch=1:size(psd.vmod.data,1))
		%	h=plot(t, gr_offset+real(psd.vmod.data(ch, ((N-1)*psd.vmod.length)+(1:psd.vmod.length) )), 'r.-'); set(h,'linewidth',1); hold on
		%end
		h=plot(t, gr_offset+real(psd.vmod.data(:, ((N-1)*psd.vmod.length)+(1:psd.vmod.length) )), '.-'); set(h,'linewidth',1); hold on
		if(N==1); legend_hndl = [legend_hndl; h]; legend_text = [legend_text; 'VM0  '; 'VM1  '; 'VM2  '; 'VM3  ';]; end;
	end
	
	% rf tx
	if( isfield(psd,'rftx') )
		if(size(psd.rftx.data,1))
			t = rftx_hscale*(psd.rftx.start+[1:psd.rftx.length]);
			h=plot(t, rf_offset+real(psd.rftx.data(:,((N-1)*psd.rftx.length)+(1:psd.rftx.length))), 'r.-');
			if(N==1); legend_hndl = [legend_hndl; h(1)]; legend_text = [legend_text; 'RF Tx']; end;
			set(h,'linewidth',2)
		end
	end
	hold on
	
	% rf rx
	if( isfield(psd,'rfrx') )
		if(size(psd.rfrx.data,1))
			t = rfrx_hscale*(psd.rfrx.start+[1:psd.rfrx.length]);
			h=plot(t, rf_offset+abs(psd.rfrx.data(:,((N-1)*psd.rfrx.length)+(1:psd.rfrx.length))),'b');
			if(N==1); legend_hndl = [legend_hndl; h(1)]; legend_text = [legend_text; 'RF Rx']; end;
			%h=plot(t, real(psd.rfrx.data( ((N-1)*psd.rfrx.length)+(1:psd.rfrx.length))),'c');
			%h=plot(t, imag(psd.rfrx.data( ((N-1)*psd.rfrx.length)+(1:psd.rfrx.length))),'m');
			set(h,'linewidth',1)
		end
		% RF RX interval
		t = rfrx_hscale*(psd.rfrx.start+[1:psd.rfrx.length]);
		h=plot([min(t) min(t)], rf_offset+[-0.1 +0.1], 'k-');
		h=plot([max(t) max(t)], rf_offset+[-0.1 +0.1], 'k-');
	end
	
	% reference lines
	% TR separator
	%t = rf_hscale*(((N-1)*psd.ctrl.trlength));
	%h=plot([t t], [-rf_vscale+gr_offset rf_vscale], 'k.-');
	
	%h=plot(RF_start+[tref tref], [-1.1 1.1], 'k.-');
	%h=plot(RF_start+[tref+te/2 tref+te/2], [-1.1 1.1], 'k.-');
	%h=plot(RF_start+[tref+te tref+te], [-1.1 1.1], 'k.-');
end
% draw ground lines
h=plot([0 ctrl_hscale*psd.ctrl.trlength], [rf_offset rf_offset], 'k');
h=plot([0 ctrl_hscale*psd.ctrl.trlength], [gr_offset gr_offset], 'k');

axis([0 ctrl_hscale*psd.ctrl.trlength -rf_vscale+gr_offset rf_vscale])
grid off
ylabel('Tx/Rx/Gx/Gy/Gz');
legend(legend_hndl, legend_text);
%legend('Gx','Gy','Gz','RF Tx','RF Rx');

title(sprintf('Pulse Sequence - %1.0f TRs', psd.ctrl.ntrs));
xlabel(sprintf('Time [ms] - %1.0fus/sample', 1e6/psd.ctrl.smpclk));
