function err_warn = medusaPsdValidate(psd, mode)
% function err_warn = medusaPsdValidate(psd, mode)
% mode = 'streaming' if this is psd will be played in streaming mode,
% mode = '' (empty-string) if using batch/regular operation
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% setup output fid
%fid = MEDUSA.FID;
fid = 1;

fprintf(fid,'\nMEDUSA: ----- PSD Validate (ID# %1.0f) -----\n', psd.id);

% determine number of channels
if(isfield(psd,'rftx')) rftx_nch = size(psd.rftx.data,1); else rftx_nch=0; end;
if(isfield(psd,'rfrx')) rfrx_nch = size(psd.rfrx.data,1); else rfrx_nch=0; end;
if(isfield(psd,'grad')) grad_nch = floor(size(psd.grad.data,1)/5); else grad_nch=0; end;
if(isfield(psd,'vmod')) vmod_nch =  ceil(size(psd.vmod.data,1)/5); else vmod_nch=0; end;

% clear error and warning counters
err_warn = [0 0];

% default to non-streaming
if(~exist('mode','var'))
	mode = '';
end

% check data types
if(grad_nch)
	% gradient waveforms
	if( max(max(abs(psd.grad.data(1:4,:)))) <= 1.0 )
		fprintf(fid,'MEDUSA: NOTE: Gradient waveform data will be treated as normalized to +/-1.0\n');
	else
		fprintf(fid,'MEDUSA: NOTE: Gradient waveform data will be treated as normalized to Signed 16-bit\n');
	end
	% gradient gating
	if( max(max(abs(psd.grad.data(5,:)))) <= 1.0 )
		fprintf(fid,'MEDUSA: WARNING: Gradient gating data will be treated as normalized to +/-1.0\n');
		fprintf(fid,'MEDUSA: Suggest coding Gradient gating as Unsigned 16-bit (integer 0-65535)\n');
		err_warn = err_warn+[0 1];
	else
		fprintf(fid,'MEDUSA: NOTE: Gradient gating data will be treated as normalized to Signed 16-bit\n');
	end
end

if(vmod_nch)
	% vector modulator waveforms
%	if( max(max(abs(psd.vmod.data(1:4,:)))) <= 1.0 )
	if( max(max(abs(psd.vmod.data(:,:)))) <= 1.0 )
		fprintf(fid,'MEDUSA: NOTE: Vmod waveform data will be treated as normalized to +/-1.0\n');
	else
		fprintf(fid,'MEDUSA: NOTE: Vmod waveform data will be treated as normalized to Signed 16-bit\n');
	end
end

if(rftx_nch)
	% rf transmit
	if( max(max(abs(psd.rftx.data))) <= 1.0 )
		fprintf(fid,'MEDUSA: NOTE: RF Tx waveform data will be treated as normalized to +/-1.0\n');
	else
		fprintf(fid,'MEDUSA: NOTE: RF Tx waveform data will be treated as normalized to Signed 16-bit\n');
	end
end

% check length of provided data
if( ~isequal(mode,'streaming') )
	% check only if mode is NOT streaming
	if(grad_nch)
		if( size(psd.grad.data,2)*5 > 1024*1024 )
			fprintf(fid,'MEDUSA: ERROR: Gradient waveform data will not fit into memory (%1.0f KB)\n', size(psd.grad.data,2)*5*2/1024);
			err_warn = err_warn+[1 0];
		end
	end
	if(vmod_nch)
		if( size(psd.vmod.data,2)*9 > 1024*1024 )
			fprintf(fid,'MEDUSA: ERROR: Vmod waveform data will not fit into memory (%1.0f KB)\n', size(psd.vmod.data,2)*9*2/1024);
			err_warn = err_warn+[1 0];
		end
	end
	if(rftx_nch)
		if( size(psd.rftx.data,2)*2 > 512*1024 )
			fprintf(fid,'MEDUSA: ERROR: RF Tx waveform data will not fit into memory (%1.0f KB)\n', size(psd.rftx.data,2)*2*2/1024);
			err_warn = err_warn+[1 0];
		end
	end
	if(rfrx_nch)
		if( size(psd.rfrx.data,2)*2 > 512*1024 )
			fprintf(fid,'MEDUSA: ERROR: RF Rx waveform data will not fit into memory (%1.0f KB)\n', size(psd.rfrx.data,2)*2*2/1024);
			err_warn = err_warn+[1 0];
		end
	end
end
	
% check TR count vs. length of provided data
% valid data can be for N TRs, or 1 TR
if(grad_nch)
	grad_ntrs = size(psd.grad.data,2)/psd.grad.length;
	if( (grad_ntrs ~= psd.ctrl.ntrs) & (grad_ntrs ~= 1) )
		fprintf(fid,'MEDUSA: ERROR: Gradient waveform data length is %1.3f TRs. Must be 1 or %1.0f TRs.\n', grad_ntrs, psd.ctrl.ntrs);
		err_warn = err_warn+[1 0];
	end
end
if(vmod_nch)
	vmod_ntrs = size(psd.vmod.data,2)/psd.vmod.length;
	if( (vmod_ntrs ~= psd.ctrl.ntrs) & (vmod_ntrs ~= 1) )
		fprintf(fid,'MEDUSA: ERROR: Vmod waveform data length is %1.3f TRs. Must be 1 or %1.0f TRs.\n', vmod_ntrs, psd.ctrl.ntrs);
		err_warn = err_warn+[1 0];
	end
end
if(rftx_nch)
	rftx_ntrs = size(psd.rftx.data,2)/psd.rftx.length;
	if( (rftx_ntrs ~= psd.ctrl.ntrs) & (rftx_ntrs ~= 1) )
		fprintf(fid,'MEDUSA: ERROR: RF Tx waveform data length is %1.3f TRs. Must be 1 or %1.0f TRs.\n', grad_ntrs, psd.ctrl.ntrs);
		err_warn = err_warn+[1 0];
	end
end

% check intervals
% gradients
if(grad_nch)
	% error on negative start
	if( min(psd.grad.start) < 0 )
		fprintf(fid,'MEDUSA: ERROR: Gradient start is at %1.0f. Must be => 0.\n', min(psd.grad.start));
		err_warn = err_warn+[1 0];
	end
	% error on negative length
	if( min(psd.grad.length) < 0 )
		fprintf(fid,'MEDUSA: ERROR: Gradient length is %1.0f. Negative length not allowed.\n', psd.grad.length);
		err_warn = err_warn+[1 0];
	end
	% warn on zero length
	if( min(psd.grad.length) == 0 )
		fprintf(fid,'MEDUSA: WARNING: Gradient length is %1.0f. Zero-length will disable module.\n', psd.grad.length);
		err_warn = err_warn+[0 1];
	end
	% error on start+interval > trlength
	if( max((psd.grad.start+psd.grad.length)/psd.grad.smpclk) > (psd.ctrl.trlength/psd.ctrl.smpclk) )
		fprintf(fid,'MEDUSA: ERROR: Gradients run past end of TR (GradEnd=%1.3fms > TR=%1.3f).\n', (psd.grad.start+psd.grad.length)/psd.grad.smpclk, 1e3*psd.ctrl.trlength/psd.ctrl.smpclk);
		err_warn = err_warn+[1 0];
	end
end
% vector modulator
if(vmod_nch)
	% error on negative start
	if( min(psd.vmod.start) < 0 )
		fprintf(fid,'MEDUSA: ERROR: Vmod start is at %1.0f. Must be => 0.\n', min(psd.vmod.start));
		err_warn = err_warn+[1 0];
	end
	% error on negative length
	if( min(psd.vmod.length) < 0 )
		fprintf(fid,'MEDUSA: ERROR: Vmod length is %1.0f. Negative length not allowed.\n', psd.vmod.length);
		err_warn = err_warn+[1 0];
	end
	% warn on zero length
	if( min(psd.vmod.length) == 0 )
		fprintf(fid,'MEDUSA: WARNING: Vmod length is %1.0f. Zero-length will disable module.\n', psd.vmod.length);
		err_warn = err_warn+[0 1];
	end
	% error on start+interval > trlength
	if( max((psd.vmod.start+psd.vmod.length)/psd.vmod.smpclk) > (psd.ctrl.trlength/psd.ctrl.smpclk) )
		fprintf(fid,'MEDUSA: ERROR: Vmod runs past end of TR (VmodEnd=%1.3fms > TR=%1.3f).\n', (psd.vmod.start+psd.vmod.length)/psd.vmod.smpclk, 1e3*psd.ctrl.trlength/psd.ctrl.smpclk);
		err_warn = err_warn+[1 0];
	end
end
% RF transmit
if(rftx_nch)
	% error on negative start
	if( min(psd.rftx.start) < 0 )
		fprintf(fid,'MEDUSA: ERROR: RF Tx start is at %1.0f. Must be => 0.\n', min(psd.rftx.start));
		err_warn = err_warn+[1 0];
	end
	% error on negative length
	if( min(psd.rftx.length) < 0 )
		fprintf(fid,'MEDUSA: ERROR: RF Tx length is %1.0f. Negative length not allowed.\n', psd.rftx.length);
		err_warn = err_warn+[1 0];
	end
	% warn on zero length
	if( min(psd.rftx.length) == 0 )
		fprintf(fid,'MEDUSA: WARNING: RF Tx length is %1.0f. Zero-length will disable module.\n', psd.rftx.length);
		err_warn = err_warn+[0 1];
	end
	% error on start+interval > trlength
	if( max((psd.rftx.start+psd.rftx.length)/psd.rftx.smpclk) > (psd.ctrl.trlength/psd.ctrl.smpclk) )
		fprintf(fid,'MEDUSA: ERROR: RF Tx runs past end of TR (RfTxEnd=%1.3fms > TR=%1.3f).\n', (psd.rftx.start+psd.rftx.length)/psd.rftx.smpclk, 1e3*psd.ctrl.trlength/psd.ctrl.smpclk);
		err_warn = err_warn+[1 0];
	end
end
% RF receive
if(rfrx_nch)
	% error on negative start
	if( min(psd.rfrx.start) < 0 )
		fprintf(fid,'MEDUSA: ERROR: Rf Rx start is at %1.0f. Must be => 0.\n', min(psd.rfrx.start));
		err_warn = err_warn+[1 0];
	end
	% error on negative length
	if( min(psd.rfrx.length) < 0 )
		fprintf(fid,'MEDUSA: ERROR: Rf Rx length is %1.0f. Negative length not allowed.\n', psd.rfrx.length);
		err_warn = err_warn+[1 0];
	end
	% warn on zero length
	if( min(psd.rfrx.length) == 0 )
		fprintf(fid,'MEDUSA: WARNING: Rf Rx length is %1.0f. Zero-length will disable module.\n', psd.rfrx.length);
		err_warn = err_warn+[0 1];
	end
	% error on start+interval > trlength
	if( max((psd.rfrx.start+psd.rfrx.length)/psd.rfrx.smpclk) > (psd.ctrl.trlength/psd.ctrl.smpclk) )
		fprintf(fid,'MEDUSA: ERROR: Rf Rx runs past end of TR (RfRxEnd=%1.3fms > TR=%1.3f).\n', (psd.rfrx.start+psd.rfrx.length)/psd.rfrx.smpclk, 1e3*psd.ctrl.trlength/psd.ctrl.smpclk);
		err_warn = err_warn+[1 0];
	end
end

% check sample rates
smpclk_list = psd.ctrl.smpclk;
if(grad_nch) smpclk_list = [smpclk_list psd.grad.smpclk]; end;
if(vmod_nch) smpclk_list = [smpclk_list psd.vmod.smpclk]; end;
if(rftx_nch) smpclk_list = [smpclk_list psd.rftx.smpclk]; end;
if(rfrx_nch) smpclk_list = [smpclk_list psd.rfrx.smpclk]; end;
% psd.ctrl.smpclk must be equal to, or a multiple of, highest rate in system
if( max(max([smpclk_list])) > psd.ctrl.smpclk )
	%fprintf(fid,'MEDUSA: ERROR: Controller smpclk must be equal to, or a multiple of, the highest smpclk in the system.\n');
	fprintf(fid,'MEDUSA: ERROR: Controller smpclk must be equal to the highest smpclk in the system.\n');
	err_warn = err_warn+[1 0];
end
if((rfrx_nch>0) & (rftx_nch>0))
	% psd.rfrx.smpclk must be equal to integer multiple or fraction of psd.rftx.smpclk
	rftxrx_ratio = psd.rftx.smpclk/psd.rfrx.smpclk;
	% if rfrxtx_ratio is 1, nothing special is needed
	if( (rftxrx_ratio == 1/1) )
		% all clear
	elseif( (rftxrx_ratio == 1/64) | ...
		(rftxrx_ratio == 1/32) | ...
		(rftxrx_ratio == 1/16) | ...
		(rftxrx_ratio == 1/8) | ...
		(rftxrx_ratio == 1/4) | ...
		(rftxrx_ratio == 1/2) | ...
		(rftxrx_ratio == 2) | ...
		(rftxrx_ratio == 4) | ...
		(rftxrx_ratio == 8) | ...
		(rftxrx_ratio == 16) | ...
		(rftxrx_ratio == 32) | ...
		(rftxrx_ratio == 64) )
		fprintf(fid,'MEDUSA: WARNING: RfTx/RfRx smpclk ratio is %1.4f. For ratios other than 1, special data handling is required.\n', rftxrx_ratio);
		err_warn = err_warn+[0 1];
	else
		fprintf(fid,'MEDUSA: ERROR: RfTx/RfRx smpclk ratio is %1.4f. Ratio must be a 2^N with N=-7 to 7.\n', rftxrx_ratio);
		err_warn = err_warn+[1 0];
	end
end

% check the results
if( (err_warn==[0 0]) )
	fprintf(fid,'MEDUSA: No Errors: No Warnings.\n');
end
if( (err_warn(1)>0) | (err_warn(2)>0) )
	fprintf(fid,'MEDUSA: %1.0f Error(s) and %1.0f Warnings(s).\n', err_warn(1), err_warn(2));
end
return

