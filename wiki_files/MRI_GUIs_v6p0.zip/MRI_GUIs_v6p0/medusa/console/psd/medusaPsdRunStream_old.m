function psd = medusaPsdRunStream(psd)
% function psd = medusaPsdRunStream(psd)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% setup output fid
fid = MEDUSA.FID;

medusaPsdValidate(psd, 'streaming');

fprintf(fid,'MEDUSA: ----- PSD Run Stream (ID# %1.0f) -----\n', psd.id);

% reset CPU TR counter
concmd32(sock, psd.ctrl.nodeid, MEDUSA.CMD.TRCOUNT, [0]);

% set for streaming mode
medusaRegBitClr(psd.rfrx.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM0_RESET);
medusaRegBitClr(psd.rftx.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM1_RESET);
medusaRegBitClr(psd.grad.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM0_RESET);
medusaRegBitClr(psd.grad.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM1_RESET);

% reset all data pointers
medusaDataSetPtr(psd.grad.nodeid+MEDUSA.SUB.GRAD.DMA_CH, 0);
medusaDataSetPtr(psd.grad.nodeid+MEDUSA.SUB.GRAD.MEM_CH, 0);
medusaDataSetPtr(psd.rftx.nodeid+MEDUSA.SUB.RFTX.DMA_CH, 0);
medusaDataSetPtr(psd.rftx.nodeid+MEDUSA.SUB.RFTX.MEM_CH, 0);
medusaDataSetPtr(psd.rfrx.nodeid+MEDUSA.SUB.RFRX.DMA_CH, 0);
medusaDataSetPtr(psd.rfrx.nodeid+MEDUSA.SUB.RFRX.MEM_CH, 0);

% figure out how many TRs will fit into memory
ntrs_buf_grad = floor( (1024*1024)/(psd.grad.length*5) );
ntrs_buf_rftx = floor( ( 512*1024)/(psd.rftx.length*2) );
ntrs_buf_rfrx = floor( ( 512*1024)/(psd.rfrx.length*2) );
ntrs_buf = floor(min([psd.ctrl.ntrs ntrs_buf_grad ntrs_buf_rftx ntrs_buf_rfrx]));

% figure load range
ntr = 0;
ntrload = ntrs_buf;
grad_ldrange = ((ntr-0)*psd.grad.length) + (1:(psd.grad.length*ntrload));
rftx_ldrange = ((ntr-0)*psd.rftx.length) + (1:(psd.rftx.length*ntrload));
% fill buffers
fprintf(fid,'MEDUSA: TR=%4.0f-%4.0f: Pre-loading', 1,ntrload);
time = medusaGradLoadStream(psd.grad.nodeid, psd.grad.data(1,grad_ldrange), psd.grad.data(2,grad_ldrange), psd.grad.data(3,grad_ldrange), psd.grad.data(4,grad_ldrange), psd.grad.data(5,grad_ldrange));
time = time + medusaRfTxLoadStream(psd.rftx.nodeid, psd.rftx.data(rftx_ldrange));
if(time==0) time=1e-3; end
fprintf(fid,' in %3.0f ms (%1.0f ksps)\n', (time*1000), (5*length(grad_ldrange)+2*length(rftx_ldrange))/(time*1000) );
ntr = ntr+ntrload;

% set TR counter
medusaSetTrCount(psd.rfrx.nodeid, ntrs_buf);
medusaSetTrCount(psd.rftx.nodeid, ntrs_buf);
medusaSetTrCount(psd.grad.nodeid, ntrs_buf);
medusaSetTrCount(psd.ctrl.nodeid, ntrs_buf);

if(1)
% arm the triggers
medusaRegBitSet(psd.rfrx.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
medusaRegBitSet(psd.rftx.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
medusaRegBitSet(psd.grad.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
% run
fprintf(fid,'MEDUSA: Starting Scan.\n');
medusaRegBitClr(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
medusaRegBitSet(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MSYNC_OE);
medusaRegBitSet(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TR_REPEAT);
medusaRegBitSet(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_ENABLE);
medusaRegBitSet(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_SW);
end

if(1)
psd.rfrx.data = [];
rfrx_trcount = 0;
while(ntr < psd.ctrl.ntrs)
	% outgoing data
	% check the TR/buffer count to see if we need to refill	
	trcount = medusaRegRead(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.TRCOUNT);
	if(trcount < (ntrs_buf-1))
		% figure load range
		ntrload = (ntrs_buf-1) - trcount;
		ntrload = min(ntrload, psd.ctrl.ntrs-ntr);
		ntrload = min(ntrload, 20);
		grad_ldrange = ((ntr-0)*psd.grad.length) + (1:(psd.grad.length*ntrload));
		rftx_ldrange = ((ntr-0)*psd.rftx.length) + (1:(psd.rftx.length*ntrload));
		% load more data
		fprintf(fid,'MEDUSA: TR=%4.0f-%4.0f: Streaming', ntr, ntr+ntrload);
		time = medusaGradLoadStream(psd.grad.nodeid, psd.grad.data(1,grad_ldrange), psd.grad.data(2,grad_ldrange), psd.grad.data(3,grad_ldrange), psd.grad.data(4,grad_ldrange), psd.grad.data(5,grad_ldrange));
		time = time + medusaRfTxLoadStream(psd.rftx.nodeid, psd.rftx.data(rftx_ldrange));
		if(time==0) time=1e-3; end
		fprintf(fid,' in %3.0f ms (%1.0f ksps)\n', (time*1000), (5*length(grad_ldrange)+2*length(rftx_ldrange))/(time*1000) );
		ntr = ntr+ntrload;
		% increment TR/buffer counter
		for(inc = 1:ntrload)
			medusaRegBitSet(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRCOUNT_INC);	% setting this bit safely increments the TR counter
		end
		
		% incoming data
		% for every TR sent, we read one in
		if(1)
		fprintf(fid,'MEDUSA: Reading RF Rx data: TR=%1.0f-%1.0f\n', rfrx_trcount, rfrx_trcount+ntrload);
		psd.rfrx.data = [psd.rfrx.data medusaRfRxReadStream(psd.rfrx.nodeid, ntrload*psd.rfrx.length) ];
		rfrx_trcount = rfrx_trcount + ntrload;
		end
	else
		pause(0.005);
	end
end
end

tr_remain = 1;
while(tr_remain)
	tr_remain = medusaRegRead(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.TRCOUNT);
	fprintf(fid,'MEDUSA: TRs remaining: %1.0f\n', tr_remain);
	pause(0.25);
end

% get the rest of data
fprintf(fid,'MEDUSA: Reading RF Rx data: TR=%1.0f-%1.0f\n', rfrx_trcount, psd.ctrl.ntrs);
psd.rfrx.data = [psd.rfrx.data medusaRfRxReadStream(psd.rfrx.nodeid, (psd.ctrl.ntrs-rfrx_trcount)*psd.rfrx.length) ];

fprintf(fid,'MEDUSA: Scan Done.\n', ntr);
