function psdSave(psd, filename);
% function psdSave(psd, filename);
%  Saves PSD data to *.mat file.
%  Saves any images in psd.img(x,y,n) to *.png files.
%  Each image plane (:,:,n) is saved as a seperate file.
%
%  - 'psd' is the PSD structure to save
%  - if 'filename' is omitted, one will be generated from PSD timestamp
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% make automatic filename is one is not provided
if( ~exist('filename','var') )
	if( isfield(psd,'timestamp') )
		timestamp = psd.timestamp;
	else
		timestamp = fix(clock);
	end
	% generate new filename from date/time
	filename = sprintf('%04d%02d%02d-%02d%02d%02d',fix(timestamp));	
end
if( isequal(filename,'') )
	if( isfield(psd,'timestamp') )
		timestamp = psd.timestamp;	% if psd has a timestamp, use it
	else
		timestamp = fix(clock);		% otherwise just use NOW
	end
	% generate new filename from date/time
	filename = sprintf('%04d%02d%02d-%02d%02d%02d',fix(timestamp));
end

% save psd structure
save([filename '.mat'], 'psd');

% if present, save images
if( isfield(psd,'img') )
	for ch = 1:size(psd.img,3);
		% append img parameters to create image filename
		imfilename_m = [filename sprintf('_img%dm-%dx%d.png',ch,size(psd.img(:,:,ch))) ];
		imfilename_p = [filename sprintf('_img%dp-%dx%d.png',ch,size(psd.img(:,:,ch))) ];
		% save as PNG
		imwrite(abs(psd.img(:,:,ch))./(max(max(abs(psd.img(:,:,ch))))), imfilename_m);
		imwrite((angle(psd.img(:,:,ch))+pi)./(2*pi), imfilename_p);
	end
end
