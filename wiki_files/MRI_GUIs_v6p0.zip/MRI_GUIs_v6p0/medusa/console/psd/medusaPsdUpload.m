function medusaPsdUpload(psd)
% function medusaPsdUpload(psd)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% notes:
% RF Rx is subchannel 0
% RF Tx is subchannel 1
% RF Rx Buffer Write is subchannel 0
% RF Rx Buffer Read  is subchannel 1 (for us to read)
% RF Tx Buffer Read  is subchannel 2
% RF Tx Buffer Write is subchannel 3 (for us to write)

% Grad subchannel 0 is used
% Grad subchannel 1 is unsupported
%% Grad Buffer Write is subchannel 0
%% Grad Buffer Read  is subchannel 1 (for us to read)

global sock
global MEDUSA
%gradientDacParams

% setup output fid
fid = MEDUSA.FID;

fprintf(fid,'MEDUSA: ----- PSD Upload (ID# %1.0f) -----\n', psd.id);

% determine number of channels
if(isfield(psd,'rftx')) rftx_nch = size(psd.rftx.data,1); else rftx_nch=0; end;
if(isfield(psd,'rfrx')) rfrx_nch = size(psd.rfrx.data,1); else rfrx_nch=0; end;
if(isfield(psd,'grad')) grad_nch = floor(size(psd.grad.data,1)/5); else grad_nch=0; end;
if(isfield(psd,'vmod')) vmod_nch =  ceil(size(psd.vmod.data,1)/5); else vmod_nch=0; end;

% -------------------------- BEGIN LOAD RFTx BUFFERS -----------------------------
for ch = 1:rftx_nch
	nodeid = psd.rftx.nodeid + hex2dec('100')*(ch-1);
	% reset data pointers
	medusaDataSetPtr(nodeid+MEDUSA.SUB.RFTX.DMA_CH, 0);	% subchannel for playback (used internally by module)
	medusaDataSetPtr(nodeid+MEDUSA.SUB.RFTX.MEM_CH, 0);	% subchannel for data loading (used by us to put data into module memory)
	% write data into buffer
	%rftxsamples = size(psd.rftx.data,1)*size(psd.rftx.data,2);
	samples = size(psd.rftx.data,2);
	fprintf(fid,'MEDUSA: RFTx Ch#%1.0f: Sending  %7.0f samples', ch, samples );
	time = medusaRfTxLoadStream(nodeid+2, psd.rftx.data(ch,:));
	%time = medusaRfTxLoad(nodeid+2, psd.rftx.data);
	if(time==0) time=0.001; end
	fprintf(fid,' in %1.3f seconds (%1.0f ksps)\n', time, samples/(time*1000) );
	% reset data pointers
	medusaDataSetPtr(nodeid+MEDUSA.SUB.RFTX.DMA_CH, 0);	% subchannel for playback (used internally by module)
	medusaDataSetPtr(nodeid+MEDUSA.SUB.RFTX.MEM_CH, 0);	% subchannel for data loading (used by us to put data into module memory)
	% set buffer handling for Rf Tx
	if(size(psd.rftx.data,2) == psd.rftx.length)
		% if only 1 TR, set for buffer looping
		medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM1_RESET);
	else
		% if more than 1 TR, set for buffer streaming
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM1_RESET);
	end
	% set TR counter
	medusaSetTrCount(nodeid, psd.ctrl.ntrs);
end	
% -------------------------- END LOAD BUFFERS -----------------------------

% -------------------------- BEGIN PREP RFRx BUFFERS -----------------------------
for ch = 1:rfrx_nch
	nodeid = psd.rfrx.nodeid + hex2dec('100')*(ch-1);
	% reset data pointers
	medusaDataSetPtr(nodeid+MEDUSA.SUB.RFRX.DMA_CH, 0);	% subchannel for playback (used internally by module)
	medusaDataSetPtr(nodeid+MEDUSA.SUB.RFRX.MEM_CH, 0);	% subchannel for data loading (used by us to put data into module memory)
	% clear memory
	samples = psd.ctrl.ntrs*psd.rfrx.length;
	fprintf(fid,'MEDUSA: RFRx Ch#%1.0f: Clearing %7.0f samples', ch, samples );
	time = medusaRfRxLoad(nodeid, zeros(1,psd.ctrl.ntrs*psd.rfrx.length));
	if(time==0) time=0.001; end
	fprintf(fid,' in %1.3f seconds (%1.0f ksps)\n', time, samples/(time*1000) );
	% reset data pointers
	medusaDataSetPtr(nodeid+MEDUSA.SUB.RFRX.DMA_CH, 0);	% subchannel for playback (used internally by module)
	medusaDataSetPtr(nodeid+MEDUSA.SUB.RFRX.MEM_CH, 0);	% subchannel for data loading (used by us to put data into module memory)
	% set buffer handling for RF Rx (always streaming mode)
	medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM0_RESET);
	% set TR counter
	medusaSetTrCount(nodeid, psd.ctrl.ntrs);
end
% -------------------------- END PREP BUFFERS -----------------------------

% -------------------------- BEGIN LOAD GRADIENT BUFFERS -----------------------------
for ch = 1:grad_nch
	nodeid = psd.grad.nodeid + hex2dec('100')*(ch-1);
	% reset data pointers
	medusaDataSetPtr(nodeid+MEDUSA.SUB.GRAD.DMA_CH, 0);	% subchannel for playback (used internally by module)
	medusaDataSetPtr(nodeid+MEDUSA.SUB.GRAD.MEM_CH, 0);	% subchannel for data loading (used by us to put data into module memory)
	% write data into buffer
	samples = size(psd.grad.data,1)*size(psd.grad.data,2);
	fprintf(fid,'MEDUSA: Grad Brd%1.0f: Sending  %7.0f samples', ch, samples );
	% handle gating as needed
	if(isfield(psd.grad,'gate'))
		time = medusaGradLoadStream(nodeid, psd.grad.data(1,:), psd.grad.data(2,:), psd.grad.data(3,:), psd.grad.data(4,:), psd.grad.gate);
	elseif(size(psd.grad.data,1) > 4)
		time = medusaGradLoadStream(nodeid, psd.grad.data(1,:), psd.grad.data(2,:), psd.grad.data(3,:), psd.grad.data(4,:), psd.grad.data(5,:));
	else
		time = medusaGradLoadStream(nodeid, psd.grad.data(1,:), psd.grad.data(2,:), psd.grad.data(3,:), psd.grad.data(4,:), 0);
	end
	if(time==0) time=0.001; end
	fprintf(fid,' in %1.3f seconds (%1.0f ksps)\n', time, samples/(time*1000) );
	% reset data pointers
	medusaDataSetPtr(nodeid+MEDUSA.SUB.GRAD.DMA_CH, 0);	% subchannel for playback (used internally by module)
	medusaDataSetPtr(nodeid+MEDUSA.SUB.GRAD.MEM_CH, 0);	% subchannel for data loading (used by us to put data into module memory)
	% set buffer handling for gradients
	if(size(psd.grad.data,2) == psd.grad.length)
		% if only 1 TR, set for buffer looping
		medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM0_RESET);
		medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM1_RESET);
	else
		% if more than 1 TR, set for buffer streaming
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM0_RESET);
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM1_RESET);
	end
	% set TR counter
	medusaSetTrCount(nodeid, psd.ctrl.ntrs);
end
% -------------------------- END LOAD BUFFERS -----------------------------

% -------------------------- BEGIN LOAD VMOD BUFFERS -----------------------------
for ch = 1:vmod_nch
	nodeid = psd.vmod.nodeid + hex2dec('100')*(ch-1);
	% reset data pointers
	medusaDataSetPtr(nodeid+MEDUSA.SUB.VMOD.DMA_CH, 0);	% subchannel for playback (used internally by module)
	medusaDataSetPtr(nodeid+MEDUSA.SUB.VMOD.MEM_CH, 0);	% subchannel for data loading (used by us to put data into module memory)
	% write data into buffer
	samples = size(psd.vmod.data,1)*size(psd.vmod.data,2);
	fprintf(fid,'MEDUSA: Vmod Brd%1.0f: Sending  %7.0f samples', ch, samples );
	% handle gating as needed
	if(isfield(psd.vmod,'gate'))
		time = medusaVmodLoadStream(nodeid, psd.vmod.data(1:4,:), psd.vmod.gate);
	elseif(size(psd.vmod.data,1) > 4)
		time = medusaVmodLoadStream(nodeid, psd.vmod.data(1:4,:), psd.vmod.data(5,:));
	else
		time = medusaVmodLoadStream(nodeid, psd.vmod.data(1:4,:), 0);
	end
	if(time==0) time=0.001; end
	fprintf(fid,' in %1.3f seconds (%1.0f ksps)\n', time, samples/(time*1000) );
	% reset data pointers
	medusaDataSetPtr(nodeid+MEDUSA.SUB.VMOD.DMA_CH, 0);	% subchannel for playback (used internally by module)
	medusaDataSetPtr(nodeid+MEDUSA.SUB.VMOD.MEM_CH, 0);	% subchannel for data loading (used by us to put data into module memory)
	% set buffer handling for gradients
	if(size(psd.vmod.data,2) == psd.vmod.length)
		% if only 1 TR, set for buffer looping
		medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM0_RESET);
		medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM1_RESET);
	else
		% if more than 1 TR, set for buffer streaming
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM0_RESET);
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM1_RESET);
	end
	% set TR counter
	medusaSetTrCount(nodeid, psd.ctrl.ntrs);
end
% -------------------------- END LOAD BUFFERS -----------------------------

% setup controller
% set TR counter
medusaSetTrCount(psd.ctrl.nodeid, psd.ctrl.ntrs);
% reset CPU TR counter
concmd32(sock, psd.ctrl.nodeid, MEDUSA.CMD.TRCOUNT, [0]);
