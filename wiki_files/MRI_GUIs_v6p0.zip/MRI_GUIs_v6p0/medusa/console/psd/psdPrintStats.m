function psdPrintStats(psd)
% function psdPrintStats(psd)
% print information and statistics about PSD
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% setup output fid
%fid = MEDUSA.FID;
fid = 1;

% PSD stats
fprintf(fid,'------------------ PSD ID#%5.0f ------------------\n', psd.id);
fprintf(fid,'--------------------------------------------------\n')
% data and time info
fprintf(fid,'TRs      : %8.0f @ %1.2fms\n', psd.ctrl.ntrs, 1e3*(psd.ctrl.trlength/psd.ctrl.smpclk));
fprintf(fid,'Scan time: %8.2f sec\n', psd.ctrl.ntrs*(psd.ctrl.trlength/psd.ctrl.smpclk));
if( isfield(psd,'rftx') ); fprintf(fid,'RFTx data: %8.0f samples x %1.0f ch (%5.0f kB/ch  x %1.0f)\n', size(psd.rftx.data,2), size(psd.rftx.data,1), 2*2*size(psd.rftx.data,2)/1024, size(psd.rftx.data,1) ); end;
if( isfield(psd,'rfrx') ); fprintf(fid,'RFRx data: %8.0f samples x %1.0f ch (%5.0f kB/ch  x %1.0f)\n', size(psd.rfrx.data,2), size(psd.rfrx.data,1), 2*2*size(psd.rfrx.data,2)/1024, size(psd.rfrx.data,1) ); end;
if( isfield(psd,'grad') ); fprintf(fid,'Grad data: %8.0f samples x %1.0f ch (%5.0f kB/brd x %1.0f)\n', size(psd.grad.data,2), size(psd.grad.data,1), 2*5*size(psd.grad.data,2)/1024, floor(size(psd.grad.data,1)/5) ); end;
if( isfield(psd,'vmod') ); fprintf(fid,'Vmod data: %8.0f samples x %1.0f ch (%5.0f kB/brd x %1.0f)\n', size(psd.vmod.data,2), size(psd.vmod.data,1), 2*9*size(psd.vmod.data,2)/1024,  ceil(size(psd.vmod.data,1)/5) ); end;
%fprintf(fid,'RFTx data: %8.0f samples x %1.0f ch (%5.0f kB)\n', size(psd.rftx.data,2), size(psd.rftx.data,1), 2*2*size(psd.rftx.data,2)*size(psd.rftx.data,1)/1024 );
%fprintf(fid,'RFRx data: %8.0f samples x %1.0f ch (%5.0f kB)\n', size(psd.rfrx.data,2), size(psd.rfrx.data,1), 2*2*size(psd.rfrx.data,2)*size(psd.rfrx.data,1)/1024 );
%fprintf(fid,'Grad data: %8.0f samples x %1.0f ch (%5.0f kB)\n', size(psd.grad.data,2), size(psd.grad.data,1), 2*size(psd.grad.data,2)*size(psd.grad.data,1)/1024 );
fprintf(fid,'--------------------------------------------------\n')
% PSD info
if( isfield(psd,'param') )
	if( isfield(psd.param,'Nro') & isfield(psd.param,'Npe') )
		fprintf(fid,'Nro x Npe: %1.0f x %1.0f\n', psd.param.Nro, psd.param.Npe);
	end
	if( isfield(psd.param,'tr')  ); fprintf(fid,'TR=  %7.2fms  (%7.0f samples)\n', psd.param.tr*1000,  psd.param.tr*psd.ctrl.smpclk ); end;
	if( isfield(psd.param,'te')  ); fprintf(fid,'TE=  %7.2fms  (%7.0f samples)\n', psd.param.te*1000,  psd.param.te*psd.rftx.smpclk ); end;
	if( isfield(psd.param,'tro') ); fprintf(fid,'Tro= %7.2fms  (%7.0f samples)\n', psd.param.tro*1000, psd.param.tro*psd.grad.smpclk); end;
	if( isfield(psd.param,'tpe') ); fprintf(fid,'Tpe= %7.2fms  (%7.0f samples)\n', psd.param.tpe*1000, psd.param.tpe*psd.grad.smpclk); end;
	fprintf(fid,'--------------------------------------------------\n')
end
if( isfield(psd,'grad') )
	% print gradient stats
	G_max = 100; % fixme!!!
	fprintf(fid,'Gx Level: %6.2f Amps (%5.3f full scale)\n', max(abs(psd.grad.data(1,:)*G_max)), max(abs(psd.grad.data(1,:))))
	fprintf(fid,'Gy Level: %6.2f Amps (%5.3f full scale)\n', max(abs(psd.grad.data(2,:)*G_max)), max(abs(psd.grad.data(2,:))))
	fprintf(fid,'Gz Level: %6.2f Amps (%5.3f full scale)\n', max(abs(psd.grad.data(3,:)*G_max)), max(abs(psd.grad.data(3,:))))
	fprintf(fid,'--------------------------------------------------\n')
end
if( isfield(psd,'vmod') )
	% print vector modulator stats
	for ch=1:size(psd.vmod.data,1)
		fprintf(fid,'VM%1.0f Level: %5.3f of full scale\n', ch, max(abs(psd.vmod.data(ch,:))) );
	end
	fprintf(fid,'--------------------------------------------------\n')
end
