function data = vmLobeTrap(ampl, pulselen, ramplen, fs)
% function data = vmLobeTrap(ampl, pulselen, ramplen, fs)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

if((nargin > 3) & (fs>0))
	% sample rate has been specified
	% translate times to samples
	pulselen = round(pulselen*fs);
	ramplen = round(ramplen*fs);
end

if(pulselen <= 0)
	fprintf('vmLobeTrap: WARNING: pulse length is %1.0f samples\n', pulselen);
	data = [];
	return
end

% first generate rectangular lobe
% - lobe is shorter because it will be convolved
% - amplitude increased to maintain net area
%data(1:pulselen-ramplen) = area/samples * (1+(ramplen/(pulselen-ramplen)));
%data(1:pulselen-ramplen) = ampl * (1+(ramplen/(pulselen-ramplen)));
data(1:pulselen-ramplen) = ampl * (1+0);
data(pulselen-ramplen+1) = 0;
% now apply convolution smoothing to spread lobe
data = conv(data,ones(ramplen,1)/ramplen);
