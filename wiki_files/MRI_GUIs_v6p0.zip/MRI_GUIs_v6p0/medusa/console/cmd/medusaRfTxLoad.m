function time = medusaRfTxLoad(nodeid, data)
% function time = medusaRfTxLoad(nodeid, data)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% mask subchannel bits of NODEID
nodeid = bitand(nodeid, hex2dec('FFFFFF00'));

% reset load address back to start
medusaDataSetPtr(nodeid+MEDUSA.SUB.RFTX.MEM_CH, 512*1024);
% load data
time = medusaRfTxLoadStream(nodeid+MEDUSA.SUB.RFTX.MEM_CH, data);
% reset load address back to start
medusaDataSetPtr(nodeid+MEDUSA.SUB.RFTX.MEM_CH, 512*1024);
