function value = medusaRegBitSet(nodeid, regaddr, clrmask)
% function value = medusaRegBitClr(nodeid, regaddr, clrmask)
%  > nodeid = address of controller/module
%  > regaddr = address of register
%  > clrmask = mask value of bits to clear (0=no change, 1=clear the bit)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% issue command
concmd32(sock, nodeid, MEDUSA.CMD.RAWREGCLRBIT, [regaddr clrmask]);
