function medusaRfTxSetPhase(nodeid, phase)
% function medusaRfTxSetPhase(nodeid, phase)
% sets RF Tx output phase immediately
%  - phase value is treated as normalized on 0 to 1 for 0-360 degrees phase shift
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% phase value is unsigned 14-bit
phase = phase * 16384;
% make it modulo 14-bit
phase = mod(phase, 16384);

global sock
global MEDUSA

% Normally this command should work, but we get register corruption in the
% AMPL, FREQ, and PHASE DDS registers.  Still need to investigate.
%concmd32(sock, nodeid, MEDUSA.CMD.DDSPHASE, [phase]);

% instead, use FPGA-controlled phase write
medusaRegWrite(nodeid, MEDUSA.REG.RF.TXDPHASE, phase);
