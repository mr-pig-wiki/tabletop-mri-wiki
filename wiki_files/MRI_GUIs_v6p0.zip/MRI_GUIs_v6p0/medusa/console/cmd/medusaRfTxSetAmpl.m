function medusaRfTxSetAmpl(nodeid, ampl)
% function medusaRfTxSetAmpl(nodeid, ampl)
% sets RF Tx output amplitude immediately
%  - if ampl is <= 1, value is treated as normalized on 0 to 1
%  - if ampl is > 1, value is treated as native digital value
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% do normalization to unsigned 12-bit
if(ampl<=1)
	ampl = ampl * 4095;
end

global sock
global MEDUSA

% Normally this command should work, but we get register corruption in the
% AMPL, FREQ, and PHASE DDS registers.  Still need to investigate.
%concmd32(sock, nodeid, MEDUSA.CMD.DDSAMPL, [ampl]);

% instead, use FPGA-controlled amplitude write
medusaRegWrite(nodeid, MEDUSA.REG.RF.TXDIA, ampl);
medusaRegWrite(nodeid, MEDUSA.REG.RF.TXDQA, ampl);
