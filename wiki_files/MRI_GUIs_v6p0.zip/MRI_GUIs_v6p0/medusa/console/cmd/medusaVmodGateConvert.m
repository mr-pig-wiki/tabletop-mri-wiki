function gate = medusaVmodGateConvert(txgate,coilen)
% function gate = medusaVmodGateConvert(txgate,coilen)
%
% Converts digital gate waveform data into bitfield gate word
% txgate - 4 x N sample matix of 1s,0s indicating desired action
%             of txgate signals for vector modulator boards 0-3
% coilen - 4 x N sample matix of 1s,0s indicating desired action
%             of coil enable signals for vector modulator boards 0-3
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% reformat data into bitfield
coilen_bits = coilen(1,:)*1 +  coilen(2,:)*2 +  coilen(3,:)*4 +	 coilen(4,:)*8;
txgate_bits = txgate(1,:)*16 + txgate(2,:)*32 + txgate(3,:)*64 + txgate(4,:)*128;
% set LED to be on during wave output
led_bits = (txgate_bits*0);
led_bits(end) = 1;
led_bits = led_bits*512;
% combine data into gate word
gate = (txgate_bits + coilen_bits + led_bits)*4;
