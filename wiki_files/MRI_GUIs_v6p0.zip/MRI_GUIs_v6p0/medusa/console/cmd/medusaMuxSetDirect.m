function medusaMuxSet(nodeid, muxaddr, channel)
% function medusaMuxSet(nodeid, muxaddr, channel)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global MEDUSA
global sock

if(channel==0)
	chsel = hex2dec('08');
	leds = 0;
else
	chsel = bitand(channel-1, 3);
	leds = bitshift(1,bitand(channel-1, 3));
end

% set mux to desired channel
data = [ hex2dec('40')+muxaddr 2 hex2dec('02')+(chsel*256)+(leds*256*16) ];
concmd32(sock, nodeid, MEDUSA.CMD.I2C, [data]);
