function time = medusaGradLoad(nodeid,Gx,Gy,Gz,Ga,gate)
% function time = medusaGradLoad(nodeid,Gx,Gy,Gz,Ga,gate)
% Gx,Gy,Gz,Ga,gate are expected in row vectors
% 'Ga' may be 0 if no extra channel is needed
% 'gate' may be 0 if no extended gating needed
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% mask subchannel bits of NODEID
nodeid = bitand(nodeid, hex2dec('FFFFFF00'));

% reset load address back to start
medusaDataSetPtr(nodeid+MEDUSA.SUB.GRAD.MEM_PTR, 0*1024);
% load gradient data
time = medusaGradLoadStream(nodeid,Gx,Gy,Gz,Ga,gate);
% reset load address back to start
medusaDataSetPtr(nodeid+MEDUSA.SUB.GRAD.MEM_PTR, 0*1024);
