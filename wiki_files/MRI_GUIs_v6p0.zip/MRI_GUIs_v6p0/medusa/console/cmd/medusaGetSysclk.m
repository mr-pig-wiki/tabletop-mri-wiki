function freqSysclk = medusaGetSysclk(nodeid)
% function freqSysclk = medusaGetSysclk(nodeid)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA
freqSysclk = concmd32Read(sock, nodeid, MEDUSA.CMD.CTRLSYSCLK, []);
