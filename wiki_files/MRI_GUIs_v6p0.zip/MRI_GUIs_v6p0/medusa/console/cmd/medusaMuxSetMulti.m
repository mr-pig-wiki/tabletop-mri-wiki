function medusaMuxSetMulti(nodeid, nchannels, channel)
% function medusaMuxSetMulti(nodeid, nchannels, channel)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global MEDUSA
global sock

% determine channel for aggregator mux
amux = floor(channel/4)+1;

% determine channels for front-end muxes
fmux(1:4) = [0 0 0 0];
fmux(amux) = mod(channel,4)+1;


% set aggregator mux
medusaMuxSetDirect(nodeid, 0, amux);
% set front muxes
medusaMuxSetDirect(nodeid, 1, fmux(1));
medusaMuxSetDirect(nodeid, 2, fmux(2));
medusaMuxSetDirect(nodeid, 3, fmux(3));
medusaMuxSetDirect(nodeid, 4, fmux(4));
