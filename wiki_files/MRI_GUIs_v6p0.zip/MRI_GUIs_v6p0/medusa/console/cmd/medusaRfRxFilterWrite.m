function medusaRfRxFilterWrite(nodeid, dfilter)
% function medusaRfRxFilterWrite(nodeid, dfilter)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% mask subchannel bits of NODEID
nodeid = bitand(nodeid, hex2dec('FFFFFF00'));

% rescale if needed
if(dfilter <= 1.0)
	% already normalized
else
	% rescale assuming signed 16-bit to +/-1.0
	dfilter = dfilter./32767;
end

% reformat filter to s32 & s16
filter_int32 = int32(floor(dfilter*(2^31-1)));
filter_int16 = int16(floor(dfilter*(2^15-1)));
% issue command (concmd expects "double" data)
concmd(sock, nodeid, MEDUSA.CMD.RXFILTER, double(filter_int16));

%%%% OLD %%%%
% load the RCF coefficients
%cmd = hex2dec('81');
%conmex('cmd',nodeid,cmd,filter_int16);
