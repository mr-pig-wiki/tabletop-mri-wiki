function time = medusaBufWrite(nodeid, data)
% function time = medusaBufWrite(nodeid, data)
%   nodeid = address of controller/module
%   data = data to write (normalized or signed 16-bit)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% make sure input is row vector
data = reshape(data,1,length(data));

% rescale data
if( max(abs(data)) <= 1.0 )
	% assume input normalized to 1.0
	data = data*32767;
else
	% assume input normalized to 16-bit value
end

% write data
if( bitand(nodeid,hex2dec('001000')) )
	% nodeid points to controller
	tic;
	%concmd(sock, nodeid, MEDUSA.CMD.SAMPLEBUFFER, data);
	concmd(sock, nodeid, MEDUSA.CMD.RAWDATA, data);
	time = toc;
else
	% nodeid points to module
	tic;
	concmd(sock, nodeid, MEDUSA.CMD.RAWDATA, data);
	time = toc;
end
