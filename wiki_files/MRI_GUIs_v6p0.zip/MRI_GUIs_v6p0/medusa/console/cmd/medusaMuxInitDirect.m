function medusaMuxInit(nodeid, muxaddr)
% function medusaMuxInit(nodeid, muxaddr)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global MEDUSA
global sock

% setup I/O port directions
data = [ hex2dec('40')+muxaddr 2 hex2dec('0006') ];
concmd32(sock, nodeid, MEDUSA.CMD.I2C, [data]);
data = [ hex2dec('40')+muxaddr 2 hex2dec('FF07') ];
concmd32(sock, nodeid, MEDUSA.CMD.I2C, [data]);

% set mux to disabled
medusaMuxSet(nodeid, muxaddr, 0);
