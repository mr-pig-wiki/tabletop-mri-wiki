function time = medusaVmodLoadStream(nodeid, data, gate)
% function time = medusaVmodLoadStream(nodeid, data, gate)
% 'data' expected as 4 x row vectors
% 'gate' may be 0 if no extended gating needed
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

fid = MEDUSA.FID;

% VMOD range
% +32767 = 65535 = 0xFFFF = 4.095V 
%      0 = 32768 = 0x8000 = 2.048V 
% -32767 =     1 = 0x0001 = 0.001V 

% mask subchannel bits of NODEID
nodeid = bitand(nodeid, hex2dec('FFFFFF00'));

% make sure data input is 4 x row vectors
if(size(data,1) < 4)
	data = [data;zeros(4-size(data,1),size(data,2))];
end
% fill gating data if user didn't provide
if(~exist('gate','var'))
	gate = 0;
end
if(gate == 0)
	% no gating signal specified - set to zero
	gate = 4096*ones(1,size(data,2));
end

% prepare vmod data interleave format
vmdata = [	real(data(1,:)); imag(data(1,:));...
			real(data(2,:)); imag(data(2,:));...
			real(data(3,:)); imag(data(3,:));...
			real(data(4,:)); imag(data(4,:)); ];
if(0)
	% new data handling (2009-05-10)
	if( max(max(abs(vmdata))) <= 1.0 )
		% assume input normalized to 1.0
		vmdata = (32767*vmdata);
	else
		% assume input normalized to 16-bit value
		vmdata = (1*vmdata)
	end
	% clamp vmdata to 16bit range
	vmdata = round(vmdata);
	vmdata(find(vmdata > +32767)) = +32767;
	vmdata(find(vmdata < -32768)) = -32768;
	vmdata = bitand(vmdata+65536, 65535);
else
	% old data handling
	if( max(max(abs(vmdata))) <= 1.0 )
		% assume input normalized to 1.0
		vmdata = (32767*vmdata)+32768;
	else
		% assume input normalized to 16-bit value
		vmdata = (1*vmdata)+32768;
	end
	% clamp vmdata to 16bit range
	vmdata = round(vmdata);
	vmdata(find(vmdata > +65535)) = 65535;
	vmdata(find(vmdata <      0)) =     0;
	vmdata = bitand(vmdata, 65535);
end

% rescale gating if needed
if( (max(max(abs(gate))) <= 1.0) & (gate ~= 0) & (gate ~= 1))
	% assume input normalized to +/-1.0 like gradient waveforms
	% discourage this encoding method
	gate = (32767*gate)+65536;
	fprintf(fid,'\n\n##### WARNING #####\n');
	fprintf(fid,'MedusaVmodLoadStream: Gate is coded with +/-1.0 normalization. Please use unsigned 16-bit coding (integers 0-65535)\n');
else
	% assume input normalized to unsigned 16-bit value
	if( min(min(gate)) < 0 )
		fprintf(fid,'\n\n##### WARNING #####\n');
		fprintf(fid,'MedusaVmodLoadStream: Gate coding has negative values! Please use unsigned 16-bit coding (integers 0-65535)\n');
	end
	gate = (1*gate)+65536;
end
gate = round(gate);
gate = bitand(gate, 65535);
% add gating and reshape
vmdata = [vmdata; gate];
vmdata = reshape(vmdata,1,size(vmdata,1)*size(vmdata,2));

% final VMOD data format
% [1i 1q 2i 2q 3i 3q 4i 4q gate 1i 1q 2i 2q .... ]

% load vmod data
tic;
concmd(sock, nodeid+MEDUSA.SUB.GRAD.MEM_CH, MEDUSA.CMD.RAWDATA, vmdata);
time = toc;
