function medusaRfTxPhaseSync(nodeid)
% function medusaRfTxPhaseSync(nodeid)
% synchronizes carrier phase between RF Tx channels
%  - typically accurate to within 1ns phase delay
%  - will disrupt any existing RF Tx signal
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA
concmd(sock, nodeid, MEDUSA.CMD.RFPHASESYNC, [0]);
