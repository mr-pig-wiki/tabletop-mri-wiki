% spin echo and projection pulse sequence
% for use with GUI for MIT 6.S02
% Jan 3, 2013
% 
% Updated by JPS 1/2017 to add second plot to GIU.  Now the full time 
% domain signal (including FID) and the readout window are both plotted
%

function [SE] = SE_PROJ_func
global psd
global H


debug_switch = 0;  % set to 1 for debugging mode.  this lets sequence run without the MEDUSA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ================= USER SPECIFIED SEQUENCE PARAMETERS ===================
freq = 1e6*psd.f0;     % set center frequency
te = psd.te*1e-3;         % set TE in sec
tr = psd.tr*1e-3;           % set TR is sec
tro = psd.tro*1e-3;        % set readout length in sec

%if psd.projection == 1
    %resolution = [ceil(tro*psd.grad.smpclk) psd.resolution(2) psd.resolution(3)];  % set resolution in [readout PE1 PE2] directions
%else % spin echo
    resolution = [ceil(tro*psd.grad.smpclk/2 + te*psd.grad.smpclk + psd.rftx_time_90/2) psd.resolution(2) psd.resolution(3)];  % set resolution in [readout PE1 PE2] directions
    resolution_gradient = [ceil(tro*psd.grad.smpclk) psd.resolution(2) psd.resolution(3)];  % set resolution in [readout PE1 PE2] directions
%end

FOV = psd.FOV;    % FOV in cm in [readout PE1 PE2]

% set to 'XY' for coronal (XY), 'XZ' for axial (XZ), 'YZ' for sagittal (YZ)
% or reverse these to change the readout direction.  Other dimension is SS/PE2
slice_orientation = psd.slice_orientation;

num_ave = psd.num_ave;         % set number of averages

% if psd.projection == 1
% projection = 1;  %%switch to choose projection versus image
% end
%% ================  END OF USER SPECIFIED PARAMETERS =====================
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Secondary pulse sequence parameters ====================================
tcr = 1e-3;   % crusher duration in sec
% scale crushers relative to readout gradient moment
scale_crushers = [0 0 1]*.8;    % set each channel: [RO PE1 PE2]
%scale_crushers = [1 0 0]*0;    % set each channel: [RO PE1 PE2]

% gradient channel pulse switches  for debugging
ro_switch  = psd.ro_switch;      % set to zero to turn off readout and rewinder gradient
pe1_switch = psd.pe1_switch;     % set to zero to turn off PE1 gradient
pe2_switch = psd.pe2_switch;     % set to zero to turn off PE2 gradient
% =========================================================================

%% hard-coded sequence parameters =========================================
rftx_time_90 = psd.rftx_time_90;			% set transmit pulse length for 90 deg pulse
rftx_time_180 = psd.rftx_time_180;         % set transmit pulse legnth for 180 deg pulse

tx_gating_time = 0e-6;         % this is the time needed for the gating pulse to enable the power amplifier
% NOTE: the actual pulse duration is shorter than rftx_time by the tx_gating delay

% set RF transmit pulse amplitudes
% CAREFUL DO NOT SET THIS LEVEL ABOVE 0.25 WHEN USING THE TOMCO TX AMPLIFIER!!!
rftx_amp_90 = psd.rftx_amp_90;   rftx_amp_180 = psd.rftx_amp_180;  % if rftx_amp_90 > .25 || rftx_amp_180 > .25, disp('transmit amplitude too high!'),crash, end
% rftx_amp_90 = .175;   rftx_amp_180 = .175*2; % when using Mini-Circuits 1W amp

psd.rfrx.gain = psd.RX_gain;     % adjust MEDUSA receiver gain if necessary
psd.rftx.gain = 0;      % set RF transmitter gain, NOT RELEVANT

tpe = 2e-3;             % set length of phase encode pulse
trew = 2e-3;           % set length of rewinder gradient lobe
pad_time_after_90 = 250e-6;  % set length of pad time after RF90

shims = [psd.shims];

%gradient_sensitivity_Hz_cm_M = [285000 424000 408300];  % gradient strength in gauss/cm/MEDUSA_unit
gradient_sensitivity_Hz_cm_M = [285000 285000 385000];  % gradient strength in gauss/cm/MEDUSA_unit


if psd.projection == 1
        grad_switch = [1 0 0];
% elseif resolution(2) == 16
%     gradient_sensitivity_G_cm = [3*.5 3/4*.08 3*.017];   %32 phase encodes
% elseif resolution(2) == 32
%     gradient_sensitivity_G_cm = [3*.5 3/2*.08 3*.017];   %32 phase encodes
% elseif resolution(2) == 64
%     gradient_sensitivity_G_cm = [3*.5 3*.08 3*.017];   %64 phase encodes
% elseif resolution(2) == 128
%      gradient_sensitivity_G_cm = [3*.5 6*.08 3*.017];   %64 phase encodes
else
    grad_switch = [1 1 1];
end
    
%gradient_sensitivity_G_cm = [283337.4 399633.5 408600.05];  % gradient strength in gauss/cm/MEDUSA_unit
%gradient_sensitivity_G_cm = [3*.5 3*.08 3*.005];   %64 phase encodes
%gradient_sensitivity_G_cm = [3*.5 3/2*.08 3*.005];   %32 phase encodes




G_max = 5;          % maximum allowable gradient strength in amps
gradient_ramp_time = 400e-6;  % gradient ramp time in ms
gradient_safety_threshold = 1;

% define slice orientation vector
if     slice_orientation == 'XY', slice_vec = [1 2 3]; ind_x = 1;  ind_y = 2;  ind_z = 3;
elseif slice_orientation == 'XZ', slice_vec = [1 3 2]; ind_x = 1;  ind_y = 3;  ind_z = 2;
elseif slice_orientation == 'YZ', slice_vec = [2 3 1]; ind_x = 3;  ind_y = 1;  ind_z = 2;
elseif slice_orientation == 'YX', slice_vec = [2 1 3]; ind_x = 2;  ind_y = 1;  ind_z = 3;
elseif slice_orientation == 'ZY', slice_vec = [3 2 1]; ind_x = 3;  ind_y = 2;  ind_z = 1; 
elseif slice_orientation == 'ZX', slice_vec = [3 1 2]; ind_x = 2;  ind_y = 3;  ind_z = 1;
end

%% calculated parameters ==================================================
groArea = 1.85*grad_switch(1)*resolution_gradient(1)*resolution_gradient(1)/(FOV(1)*gradient_sensitivity_Hz_cm_M(slice_vec(1))*tro);
gpeArea_1 = grad_switch(2)*psd.grad.smpclk*resolution_gradient(2)/(2*FOV(2)*gradient_sensitivity_Hz_cm_M(slice_vec(2)));
gpeArea_2 = grad_switch(3)*psd.grad.smpclk*resolution_gradient(3)/(2*FOV(3)*gradient_sensitivity_Hz_cm_M(slice_vec(3)));


gr_ramp = round((gradient_ramp_time/(1/psd.grad.smpclk))); % gradient trapezoid ramps (# samples to ramp)

% load sequence parameters into PSD structure
psd.rfrx.freq = freq;	  psd.rftx.freq = freq;
psd.ctrl.ntrs = 1;
psd.param.Nro = resolution(1);
psd.param.Npe = 1;
psd.param.tr = tr;
psd.ctrl.trlength = tr*psd.ctrl.smpclk;
psd.param.te = te;
psd.param.tpe = tpe;
psd.param.tro = tro;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initialize MEDUSA console


%medusaReset(psd.ctrl.nodeid);

%% Define pulses and readout

% define transmit pulses

pulse_RF_90 = [rftx_amp_90*ones(1, (rftx_time_90-tx_gating_time)*psd.rftx.smpclk)];  % define shape of 90 deg RF pulse
pulse_RF_180 = [1i*rftx_amp_180*ones(1, (rftx_time_180-tx_gating_time)*psd.rftx.smpclk)]; % define shape of 180 deg RF pulse

% define gradient pulses using gradient moments
gro_rewinder = [grLobeTrap(groArea/2, gr_ramp, trew, psd.grad.smpclk)]; % preparation windup for readout
gro_readout = [grLobeTrap(groArea,   gr_ramp, tro+2*gr_ramp/psd.grad.smpclk, psd.grad.smpclk)];  % readout gradient pulse

gpe1_delta = [grLobeTrap(gpeArea_1, gr_ramp, tpe, psd.grad.smpclk)];	% delta_k PE1 gradient pulse
gpe2_delta = [grLobeTrap(gpeArea_2, gr_ramp, tpe, psd.grad.smpclk)];  % delta_k PE2 gradient pulse

if resolution(3) == 1, gpe2 = 0; end

% define crusher gradient pulses
if psd.projection == 1 || psd.spin_echo == 1
    % hard code crusher amplitude for this case to avoid excessively large
    % crushers during long readouts
    crusher_RO = grLobeTrap(2*ceil(scale_crushers(1)), gr_ramp, tcr, psd.grad.smpclk);
    crusher_PE1 = grLobeTrap(2*ceil(scale_crushers(2)), gr_ramp, tcr, psd.grad.smpclk);
    crusher_PE2 = grLobeTrap(2*ceil(scale_crushers(3)), gr_ramp, tcr, psd.grad.smpclk);
else
    crusher_RO = grLobeTrap(abs(groArea)*scale_crushers(1), gr_ramp, tcr, psd.grad.smpclk);
    crusher_PE1 = grLobeTrap(abs(groArea)*scale_crushers(2), gr_ramp, tcr, psd.grad.smpclk);
    crusher_PE2 = grLobeTrap(abs(groArea)*scale_crushers(3), gr_ramp, tcr, psd.grad.smpclk);
end

% create empty vectors for each gradient waveform
gro = zeros(1,floor(tr*psd.grad.smpclk)-1);
gpe1 = zeros(1,floor(tr*psd.grad.smpclk)-1);
gpe2 = zeros(1,floor(tr*psd.grad.smpclk)-1);


% add ssi
ssi = 0*gro.'; ssi(1) = hex2dec('1000')/32767;	% create start-of-sequence flag
% add gating
gate = 0*gro.';




%% set sequence event timing

psd.rftx.data = [];
psd.rftx.data = [psd.rftx.data eps*ones(1,round(tx_gating_time*psd.rftx.smpclk))];
psd.rftx.data = [psd.rftx.data pulse_RF_90 1/4095 1/4095 0];
psd.rftx.data = [psd.rftx.data zeros(1,-3+round((te/2-rftx_time_90/2-rftx_time_180/2-tx_gating_time)*psd.rftx.smpclk))];
psd.rftx.data = [psd.rftx.data eps*ones(1,round(tx_gating_time*psd.rftx.smpclk))];
psd.rftx.data = [psd.rftx.data pulse_RF_180];
psd.rftx.data = [psd.rftx.data 1/4095 1/4095 0];


% if psd.projection == 1
%    % psd.rfrx.start = round( (te - .5*tro + rftx_time_90/2)*psd.rfrx.smpclk);
%         psd.rfrx.start = round((rftx_time_90/2 + 400e-6).*psd.rfrx.smpclk);
%         psd.rfrx.fft_start = round( (te - 4e-3 + rftx_time_90/2)*psd.rfrx.smpclk);
% 
%     psd.rfrx.length = resolution(1);
% else
    psd.rfrx.start = round((rftx_time_90/2 + 250e-6).*psd.rfrx.smpclk);
    psd.rfrx.fft_start = round( (te - 4e-3 + rftx_time_90/2 )*psd.rfrx.smpclk);
    psd.rfrx.length = resolution(1);
% end

psd.rfrx.data = zeros(1,psd.rfrx.length);
% transmitter
psd.rftx.start = 1;
psd.rftx.length = length(psd.rftx.data);

% define readout pulse start and end times
if psd.projection == 1
readout_start_ind = round((te-tro/2 + rftx_time_90/2 + rftx_time_180)*psd.grad.smpclk) - gr_ramp - 1;
readout_end_ind = readout_start_ind + numel(gro_readout) - 1;
% add readout gradient into sequence
gro(readout_start_ind:readout_end_ind) = gro_readout;
end



% define PE pulse start and end times
pe_start_ind = ceil((rftx_time_90 + pad_time_after_90)*psd.grad.smpclk);
pe_end_ind = pe_start_ind + numel(gpe1_delta) - 1;

% add PEs to sequence
gpe1(pe_start_ind:pe_end_ind) = gpe1_delta;
gpe2(pe_start_ind:pe_end_ind) = gpe2_delta;

% add rewinder to sequence
gro(pe_start_ind:pe_start_ind+numel(gro_rewinder)-1) = gro_rewinder;

% switches to disable (or scale) gradient pulses
gro = ro_switch*gro;
gpe1 = pe1_switch*gpe1;
gpe2 = pe2_switch*gpe2;

% set crusher start and end indices within gradient vector
crusher_pre_start_ind = ceil((rftx_time_90/2 + te/2 - tcr - tx_gating_time - 400e-6)*psd.grad.smpclk)-1;
crusher_pre_end_ind = crusher_pre_start_ind + numel(crusher_RO)-1;

crusher_post_start_ind = ceil((rftx_time_90/2 + te/2 + rftx_time_180 - tx_gating_time + 400e-6)*psd.grad.smpclk)-1;
crusher_post_end_ind = crusher_post_start_ind + numel(crusher_RO)-1;





%% check minimum TE and break out of sequence if timing is incorrect


data = zeros((resolution));
data_all = zeros(resolution(1),resolution(2),resolution(3),num_ave);
%data_running_ave = zeros(resolution(1),1);

% generate normalized phase encode steps
pe1_steps = [-1:2/(resolution(2)-1):1];
if resolution(3) == 1, pe2_steps = 0; else pe2_steps = [-1:2/(resolution(3)-1):1]; end


%%   LOOP THROUGH SEQUENCE CALLS (PHASE ENCODES, ETC.)
for vv = 1:num_ave
  if get(H.toggle_stop_button,'Value') == 0
   for aa=1:resolution(3)  % outer loop, PE2
    for bb=1:resolution(2),  % inner loop, PE1
      if aa==1 && bb==1, tic, end
        disp(['acquiring PE1=',num2str(bb), ', PE2=',num2str(aa)])

clear psd.grad.data        
        
% set up readout, PE, and PE2 directions
    gx_temp = gro';
    if resolution(2) > 1, gy_temp = gpe1' * pe1_steps(bb); else gy_temp = 0*gpe1'; end
    if resolution(3) > 1, gz_temp = gpe2' * pe2_steps(aa); else gz_temp = 0*gpe2'; end
    temp = [gx_temp.'; gy_temp.'; gz_temp.'];
    %psd.grad.data = [temp(ind_x,:); temp(ind_x,:); temp(ind_x,:); ssi.'; gate.']; 
     psd.grad.data = [temp(ind_x,:); temp(ind_y,:); temp(ind_z,:); ssi.'; gate.']; % working version of this line



% insert crushers into sequence
temp_crusher = [crusher_RO; crusher_PE1; crusher_PE2];
psd.grad.data(1,crusher_pre_start_ind:crusher_pre_end_ind) = psd.grad.data(1,crusher_pre_start_ind:crusher_pre_end_ind) + temp_crusher(ind_x,:)
psd.grad.data(2,crusher_pre_start_ind:crusher_pre_end_ind) = psd.grad.data(2,crusher_pre_start_ind:crusher_pre_end_ind) + temp_crusher(ind_y,:)
psd.grad.data(3,crusher_pre_start_ind:crusher_pre_end_ind) = psd.grad.data(3,crusher_pre_start_ind:crusher_pre_end_ind) + temp_crusher(ind_z,:)

psd.grad.data(1,crusher_post_start_ind:crusher_post_end_ind) = psd.grad.data(1,crusher_post_start_ind:crusher_post_end_ind) + temp_crusher(ind_x,:)
psd.grad.data(2,crusher_post_start_ind:crusher_post_end_ind) = psd.grad.data(2,crusher_post_start_ind:crusher_post_end_ind) + temp_crusher(ind_y,:)
psd.grad.data(3,crusher_post_start_ind:crusher_post_end_ind) = psd.grad.data(3,crusher_post_start_ind:crusher_post_end_ind) + temp_crusher(ind_z,:)





% add in shim settings -- does not depend on slice orientation
psd.grad.data(1,:) = psd.grad.data(1,:) + shims(1);
psd.grad.data(2,:) = psd.grad.data(2,:) + shims(2);
psd.grad.data(3,:) = psd.grad.data(3,:) + shims(3);

% define total number of gradient points
psd.grad.start = 1;
psd.grad.length = length(psd.grad.data);


if max(max(abs(psd.grad.data))) > gradient_safety_threshold  && psd.projection == 1
   fprintf(['Error: \tgradient strength too high\n'])
   set(H.system_status,'ForegroundColor',[1 0 0]);
   set(H.system_status,'String','ERROR: GRADIENT STRENGTH TOO HIGH.')
   pause(.1)
   return
end



% fill in zeros for remainder of rftx and rfrx

%dummy = zeros(1,round(tr*psd.rftx.smpclk)-1);
%dummy(1:numel(psd.rftx.data)) = psd.rftx.data;
%psd.rftx.data = dummy;





%% end pulse sequence specification


%% check sequence parameters for consistency ==============================

if te/2 < rftx_time_90/2 + tpe + rftx_time_180/2
  %  fprintf(['ERROR:\t TE = ',num2str(te),' is too short for the specified RF pulse and phase encode lobe durations\n']) 
  set(H.system_status,'ForegroundColor',[1 0 0]);
  set(H.system_status,'String',['ERROR: TE = ',num2str(te),' IS TOO SHORT.']);
    return
end

if te/2 < rftx_time_90/2 + trew + rftx_time_180/2
   % fprintf(['ERROR:\t TE = ',num2str(te),' is too short for the specified RF pulse and rewind gradient lobe durations\n']);
     set(H.system_status,'ForegroundColor',[1 0 0]);
     set(H.system_status,'String',['ERROR: TE = ',num2str(te),' IS TOO SHORT.']);
    return
end

% if te/2 < rftx_time_180/2 + tro/2 && psd.projection == 1
%   %  fprintf(['ERROR:\t TE = ',num2str(te),' is too short for the specified RF pulse and readout gradient lobe durations\n']);
%     set(H.system_status,'ForegroundColor',[1 0 0]);
%     set(H.system_status,'String',['ERROR: TE = ',num2str(te),' IS TOO SHORT.']);
%     return
% end

if tr < te + tro/2 + rftx_time_90/2
  % fprintf(['ERROR:\t TR = ',num2str(tr),' is too short for the specified TE\n']);
    set(H.system_status,'ForegroundColor',[1 0 0]);
    set(H.system_status,'String',['ERROR: TR = ',num2str(te),' IS TOO SHORT.']);
   return 
end

%% run sequence ===========================================================
if debug_switch == 0
medusaPsdConfigure(psd);
psd = medusaPsdRunStream(psd);  end_time = toc; pause((tr-end_time)), tic
else
    psd.rfrx.data(:) = 0;   psd.rfrx.data(round(numel(psd.rfrx.data)/2)) = 1;
     end_time = toc; pause((tr-end_time)), tic
end
% =========================================================================
 
data(:,bb,aa) = psd.rfrx.data;
data_all(:,bb,aa,vv) = data(:,bb,aa);


% compute parameters for plotting 
num_rfrx_points = numel(psd.rfrx.data(1,:));
rx_time = (0:1:num_rfrx_points-1)/psd.rfrx.smpclk;
freq_proj = (-floor(num_rfrx_points/2):1:ceil(num_rfrx_points/2)-1)*psd.rfrx.smpclk/num_rfrx_points;

grad_time = (0:1:numel(psd.grad.data(1,:))-1)/psd.grad.smpclk;
tx_time = (0:1:numel(psd.rftx.data)-1)/psd.rftx.smpclk;
% relevant_range_grad = grad_time(1:round(2*te/tr*numel(grad_time)));
% relevant_range_tx = tx_time(1:round(2*te/tr*numel(tx_time)));


           
    %    data_running_ave = data(:,bb,aa);

%    figure(10),subplot(2,3,2),plot(rx_time,abs(squeeze(data_all(:,bb,1,vv)))),hold on,plot(rx_time,real(squeeze(data_all(:,bb,1,vv))),'r'),hold off
%    axis([rx_time(1) rx_time(end) 0 1.5*max(max(abs(squeeze(data_all(:,bb,1,vv)))))])
if vv == 1
    data_running_ave = data(:,bb,aa);
    spec = fftshift(fft(data_running_ave));
    
else
       %data_running_ave = (data_running_ave*.5 + data(:,bb,aa)*.5);  %%  CZC 3/3/2015
       data_running_ave =  mean(data_all,4);  %%  CZC 3/3/2015
end

% on the first repetition, set the reference magnitudes in spin echo mode



% %%   PROJECTION MODE
% if psd.projection == 1
%     
%     data_mean = squeeze(sum(data_all,4))/(vv);
%     
%     if psd.ii == 0  && vv == 1
%         psd.first_data_mag_ref = max(abs(data_mean));
%         psd.first_spec_mag_ref = max(abs(fftshift(fft(data_mean))));
%     end
% 
%      
%      plot(H.readout_plot_short,1000*rx_time,abs(data_mean));
%      spec_mean = fftshift(fft(data_mean));
%      plot(H.projection_plot,freq_proj/1000,abs(spec_mean));
%    
%     if psd.auto_scale == 0
%         axis(H.readout_plot_short,[1000*rx_time(1) 1000*rx_time(end) 0 psd.first_data_mag_ref])
%         axis(H.projection_plot,[freq_proj(1)/1000 freq_proj(end)/1000 0 psd.first_spec_mag_ref])
%     elseif psd.auto_scale == 1 && vv == 1
%         axis(H.readout_plot_short,[1000*rx_time(1) 1000*rx_time(end) 0 1.1*max(abs(data_mean))])
%         axis(H.projection_plot,[freq_proj(1)/1000 freq_proj(end)/1000 0 1.1*max(abs(spec_mean))])
%     elseif psd.auto_scale == 1 && vv > 1
%         axis(H.readout_plot_short,[1000*rx_time(1) 1000*rx_time(end) 0 1.1*max(abs(data_mean))])
%         axis(H.projection_plot,[freq_proj(1)/1000 freq_proj(end)/1000 0 1.1*max(abs(spec_mean))])        
%     end
%     xlabel(H.projection_plot,'KHz'),  xlabel(H.readout_plot,'ms')
%     
%     
%     
%     
%        
%     data_block_2 = [abs(data) real(data)];
%     data_mean_long = squeeze(sum(data_all,4))/vv;
%     data_block_2_mean = [abs(data_mean_long) real(data_mean_long)];
%     
%     range_ind = [round(psd.te*1e-3*psd.rfrx.smpclk) - floor(1e-3*psd.tro/2*psd.rfrx.smpclk) + round(1e-3*psd.rftx_time_180/2*psd.rfrx.smpclk) : round(psd.te*1e-3*psd.rfrx.smpclk) + floor(1e-3*psd.tro/2*psd.grad.smpclk)];
% 
% %     spec_partial = fftshift(fft(data(range_ind))); 
% %     spec_partial_mean = fftshift(fft(data_mean_long(range_ind)));
% %     
% %     spec = spec_partial;
% % 
% %     freq_partial = linspace(-psd.rfrx.smpclk/2,psd.rfrx.smpclk/2,numel(spec_partial));
% 
% 
%         plot(H.readout_plot,1000*rx_time,data_block_2_mean)
%       %  plot(H.projection_plot,freq_partial/1000,abs(spec_partial_mean))
% 
%             xlabel(H.readout_plot,'time (ms)')
%             xlabel(H.projection_plot,'KHz')
%             
%     if psd.ii == 0 && vv == 1
%         psd.first_data_mag_ref = max(abs(data_mean(psd.rfrx.fft_start:end,bb,aa)));
%         psd.first_spec_mag_ref = max(abs(fftshift(fft(data_mean(psd.rfrx.fft_start:end)))));
%     end
%     
%      if psd.auto_scale == 0
%         axis(H.readout_plot,[0 1000*rx_time(end) -1.1*psd.first_data_mag_ref 1.1*psd.first_data_mag_ref])
%   %      axis(H.projection_plot,[freq_partial(1)/1000 freq_partial(end)/1000 0 1.25*psd.first_spec_mag_ref])
%      elseif psd.auto_scale == 1
%         axis(H.readout_plot,[0 1000*rx_time(end) -1.1*max(max(abs(data_mean(psd.rfrx.fft_start:end)))) 1.1*max(max(abs(data_mean(psd.rfrx.fft_start:end))))])
%  %       axis(H.projection_plot,[freq_partial(1)/1000 freq_partial(end)/1000 0 1.25*max(max(abs(spec_partial_mean)))])
%      end
% 
%     
%     
% end

%%   SPIN ECHO MODE
%if psd.projection == 0 , disp('projection = 0')
    
    data_block_2 = [abs(data) real(data)];
    data_mean = squeeze(sum(data_all,4))/vv;
    data_block_2_mean = [abs(data_mean) real(data_mean)];
    
    range_ind = [round(psd.te*1e-3*psd.rfrx.smpclk) - floor(1e-3*psd.tro/2*psd.rfrx.smpclk) + round(1e-3*psd.rftx_time_180/2*psd.rfrx.smpclk) : round(psd.te*1e-3*psd.rfrx.smpclk) + floor(1e-3*psd.tro/2*psd.grad.smpclk)];

    spec_partial = fftshift(fft(data(range_ind))); 
    spec_partial_mean = fftshift(fft(data_mean(range_ind)));
    
    spec = spec_partial;

    freq_partial = linspace(-psd.rfrx.smpclk/2,psd.rfrx.smpclk/2,numel(spec_partial));


        plot(H.readout_plot,1000*rx_time,data_block_2_mean)
        plot(H.projection_plot,freq_partial/1000,abs(spec_partial_mean))

            xlabel(H.readout_plot,'time (ms)')
            xlabel(H.projection_plot,'KHz')
            
    if psd.ii == 0 && vv == 1
        psd.first_data_mag_ref = max(abs(data_mean(psd.rfrx.fft_start:end,bb,aa)));
        psd.first_spec_mag_ref = max(abs(fftshift(fft(data_mean(psd.rfrx.fft_start:end)))));
    end
    
     if psd.auto_scale == 0
        axis(H.readout_plot,[0 1000*rx_time(end) -1.1*psd.first_data_mag_ref 1.1*psd.first_data_mag_ref])
        axis(H.projection_plot,[freq_partial(1)/1000 freq_partial(end)/1000 0 1.25*psd.first_spec_mag_ref])
     elseif psd.auto_scale == 1
        axis(H.readout_plot,[0 1000*rx_time(end) -1.1*max(max(abs(data_mean(psd.rfrx.fft_start:end)))) 1.1*max(max(abs(data_mean(psd.rfrx.fft_start:end))))])
        axis(H.projection_plot,[freq_partial(1)/1000 freq_partial(end)/1000 0 1.25*max(max(abs(spec_partial_mean)))])
     end

 
        plot(H.readout_plot_short,1000*(rx_time(range_ind)-mean(rx_time(range_ind))),data_block_2_mean(range_ind))
      %  plot(H.projection_plot,freq_partial/1000,abs(spec_partial_mean))
            xlabel(H.readout_plot_short,'time (ms) relative to echo center')

    
%end
   



    end  % end inner PE loop
    end      % end outer PE loop
    end
end      % end averaging loop

% 
% % output parameters to pass back to the GUI
SE.data = data;
SE.data_ave = mean(data_all,4);
% SE.data_running_ave = data_running_ave;  % JPS 05/02/2013  
SE.data_all = data_all;  % JPS 05/02/2013
SE.freq = 1000*freq_proj;
SE.time = rx_time;
SE.spec = spec;


psdPrintStats(psd);



% plots for 2-D acquisitions
% if resolution(3) == 1
% figure(10),subplot(2,2,1),plot(rx_time,abs(data)),hold on,plot(rx_time,real(data),'r')
% subplot(2,2,2),plot(freq_proj,abs(fftshift(fft(data,[],1),1)))
%        axis([freq_proj(1) freq_proj(end) 0 1.25*max(mean(abs(fftshift(fft(squeeze(data_all(:,bb,aa,vv)),[],1),1)),2))])
% 
% subplot(2,2,3),imagesc(flipdim(abs(data),1)),subplot(2,2,4),imagesc(flipdim(abs(fftshift(fft2(fftshift(data)))),1))
% end


% plots for 3-D acquisitions
if resolution(3) ~= 1, im = fftshift(fftn(fftshift(data))); 
%figure(12),for ss=1:resolution(3), imagesc(flipdim(abs(im(:,:,ss)),1)),pause(.75),end
end

if resolution(3) > 1
    

for ss = 1:resolution(3)
    if resolution(3) < 17
  %          subplot(4,4,ss),imagesc(flipdim(abs(im(:,:,ss)),1))
    elseif resolution(3) >= 17
  %          subplot(8,8),imagesc(flipdim(abs(im(:,:,ss)),1))
        end
end
end


if num_ave > 1 && resolution(3) == 1
    for vv=1:num_ave,temp_im(:,:,vv) = abs(fftshift(fft2(fftshift(squeeze(data_all(:,:,1,vv)))))); end
 %  figure(20),imagesc(flipdim(mean(temp_im,3),1)),colormap(gray)
 
   %axis image
end

% 
% 
% 
% fprintf('Plotting...\n')
% %psdPlotRG(100,psd);
% %psdPlotMD(100,psd,0,-0.1);
% psdPlotOV(100,psd,0,-0.1);
% fprintf('----------------------------------------\n')
% 
% 
% 
% 
% 







