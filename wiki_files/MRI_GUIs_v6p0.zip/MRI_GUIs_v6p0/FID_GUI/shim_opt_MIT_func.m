function [metric] = shim_opt_MIT(new_shim,dim,shims,freq_axis,time,psd)
global psd
global H

if get(H.toggle_stop_button,'Value') == 0
tic
shim_string = ['xyz'];
% update shim by test value
shims(dim) = shims(dim) + new_shim;

    psd.grad.data(1,:) = shims(1);
    psd.grad.data(2,:) = shims(2);
    psd.grad.data(3,:) = shims(3);

    
    % run sequence and acuire FID with new shim
    medusaPsdConfigure(psd);
    psd = medusaPsdRunStream(psd);

    
    
data = psd.rfrx.data;
spec = abs(fftshift(fft(fftshift(data))));

data_block = [abs(data).' real(data).']

plot(H.readout_plot,data_block)
plot(H.projection_plot,abs(spec))

% 
% subplot(1,2,1),plot(time,real(data));hold on,plot(time,abs(data),'r'),hold off
% %axis([time(1) time(end) -1.25*Y2 1.25*Y2])
% %xlim([0,time(points)])
% xlabel('time (s)');
% ylabel('?')'
% title('Medusa FID');
% 
% subplot(1,2,2), plot(freq_axis,spec);
[Y I] = max(spec);    
% %axis([freq_axis(1) freq_axis(end) 0 1.25*max_amp])
% xlabel('freq(Hz)')
% title(['FID spectrum, peak ',num2str(max(abs(spec))),', shim_',shim_string(dim), ' is ', num2str((1000*shims(dim))),'e-3'])
% axis([freq_axis(1) freq_axis(end) 0 1.25*Y])

    
    metric = 1/Y;
    
    
    toc, pause(psd.tr*1e-3 - toc)
   
else
    set(H.auto_shim_check_box,'Value',0);
end

    
    
    
    
    