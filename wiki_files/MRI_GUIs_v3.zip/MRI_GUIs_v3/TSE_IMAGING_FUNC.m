% turbo spin echo pulse sequence, MIT 6.02M class
% Dec 27, 2012 (update 1/2/2013)
function [TSE] = TSE_IMAGING_FUNC
global psd
global H

psd.grad.smpclk = 500e3/16;  BW = 500e3/16;  % readout BW must be 500e3/N for even N

debug_switch = 0;  % set to 1 for debugging mode.  this lets sequence run without the MEDUSA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ================= USER SPECIFIED SEQUENCE PARAMETERS ===================
freq = psd.f0;     % set center frequency
tr = psd.tr*1e-3;           % set TR is sec
te = psd.te_tse*1e-3;         % set TE in sec

tro = psd.tro_tse*1e-3;        % set readout length in sec

num_echoes = 72;
frac_ksp = 3/4;
full_pe = num_echoes / frac_ksp;

num_shots = 1;

resolution = [floor(tro*psd.grad.smpclk) full_pe 1];  % set resolution in [readout PE1 PE2] directions

FOV = [psd.FOV_ro psd.FOV_pe1 psd.FOV_pe2];    % FOV in cm in [readout PE1 PE2]

% set to 'XY' for coronal (XY), 'XZ' for axial (XZ), 'YZ' for sagittal (YZ)
% or reverse these to change the readout direction.  Other dimension is SS/PE2
slice_orientation = psd.slice_orientation;

num_ave = psd.num_ave;         % set number of averages

projection = 0;  %%switch to choose projection versus image
%% ================  END OF USER SPECIFIED PARAMETERS =====================
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Secondary pulse sequence parameters ====================================
tcr = .75e-3;   % crusher duration in sec
% scale crushers relative to readout gradient moment
scale_crushers = [0 0 1]*.2;    % set each channel: [RO PE1 PE2]
%scale_crushers = [1 0 0]*0;    % set each channel: [RO PE1 PE2]

% gradient channel pulse switches  for debugging
ro_switch  = 1;      % set to zero to turn off readout and rewinder gradient
pe1_switch = 1;     % set to zero to turn off PE1 gradient
pe2_switch = 1;     % set to zero to turn off PE2 gradient
% =========================================================================

%% hard-coded sequence parameters =========================================
rftx_time_90 = .16e-3;			% set transmit pulse length for 90 deg pulse
rftx_time_180 = .16e-3;         % set transmit pulse legnth for 180 deg pulse


tx_gating_time = 0;

%tx_gating_time = 75e-6;         % this is the time needed for the gating pulse to enable the power amplifier
% NOTE: the actual pulse duration is shorter than rftx_time by the tx_gating delay

% set RF transmit pulse amplitudes
% CAREFUL DO NOT SET THIS LEVEL ABOVE 0.25 WHEN USING THE TOMCO TX AMPLIFIER!!!
rftx_amp_90 = psd.rftx_amp_90;   rftx_amp_180 = psd.rftx_amp_180;  % if rftx_amp_90 > .25 || rftx_amp_180 > .25, disp('transmit amplitude too high!'),crash, end
% rftx_amp_90 = .175;   rftx_amp_180 = .175*2; % when using Mini-Circuits 1W amp

%psd.rftx.smpclk = 500e3/16;  % sampling clock for TX pulse
%psd.ctrl.smpclk = 500e3/16;  % sampling clock for control
%psd.rfrx.smpclk = BW;	% set Rx sample rate in Hz (must be 500kHz/(2^N))
psd.rfrx.gain = psd.RX_gain;     % adjust MEDUSA receiver gain if necessary
psd.rftx.gain = 0;      % set RF transmitter gain, NOT RELEVANT

tpe = 1e-3;             % set length of phase encode pulse
trew = 1.5e-3;           % set length of rewinder gradient lobe
pad_time_after_90 = 500e-6;  % set length of pad time after RF90

shims = [0.0005    0.00405   0.00355];
load shims.mat

gradient_sensitivity_Hz_cm_M = .5*[285000 285000 408300];  % gradient strength in gauss/cm/MEDUSA_unit


if projection == 1
        grad_switch = [1 0 0];
% elseif resolution(2) == 16
%     gradient_sensitivity_G_cm = [3*.5 3/4*.08 3*.017];   %32 phase encodes
% elseif resolution(2) == 32
%     gradient_sensitivity_G_cm = [3*.5 3/2*.08 3*.017];   %32 phase encodes
% elseif resolution(2) == 64
%     gradient_sensitivity_G_cm = [3*.5 3*.08 3*.017];   %64 phase encodes
% elseif resolution(2) == 128
%      gradient_sensitivity_G_cm = [3*.5 6*.08 3*.017];   %64 phase encodes
else
    grad_switch = [1 1 1];
end
    
%gradient_sensitivity_G_cm = [283337.4 399633.5 408600.05];  % gradient strength in gauss/cm/MEDUSA_unit
%gradient_sensitivity_G_cm = [3*.5 3*.08 3*.005];   %64 phase encodes
%gradient_sensitivity_G_cm = [3*.5 3/2*.08 3*.005];   %32 phase encodes




gamma = 4.25781e3;	% Hz/gauss
G_max = 5;          % maximum allowable gradient strength in amps
gradient_ramp_time = 300e-6;  % gradient ramp time in ms
gradient_safety_threshold = .6;

%% calculated parameters ==================================================
% groArea = gradient_sensitivity_G_cm(1)*(psd.grad.smpclk/(gamma*FOV(1)));	% readout area
% gpeArea_1 = gradient_sensitivity_G_cm(2)*(psd.grad.smpclk/(gamma*FOV(2)));  % delta_PE1 area
% gpeArea_2 = gradient_sensitivity_G_cm(3)*(psd.grad.smpclk/(gamma*FOV(3)));  % delta_PE2 area

% define slice orientation vector
if     slice_orientation == 'XY', slice_vec = [1 2 3]; ind_x = 1;  ind_y = 2;  ind_z = 3;
elseif slice_orientation == 'XZ', slice_vec = [1 3 2]; ind_x = 1;  ind_y = 3;  ind_z = 2;
elseif slice_orientation == 'YZ', slice_vec = [2 3 1]; ind_x = 3;  ind_y = 1;  ind_z = 2;
elseif slice_orientation == 'YX', slice_vec = [2 1 3]; ind_x = 2;  ind_y = 1;  ind_z = 3;
elseif slice_orientation == 'ZY', slice_vec = [3 2 1]; ind_x = 3;  ind_y = 2;  ind_z = 1; 
elseif slice_orientation == 'ZX', slice_vec = [3 1 2]; ind_x = 2;  ind_y = 3;  ind_z = 1;
end


groArea = grad_switch(1)*resolution(1)*resolution(1)/(FOV(1)*gradient_sensitivity_Hz_cm_M(slice_vec(1))*tro);
gpeArea_1 = grad_switch(2)*psd.grad.smpclk*resolution(2)/(2*FOV(2)*gradient_sensitivity_Hz_cm_M(slice_vec(2)));
gpeArea_2 = grad_switch(3)*psd.grad.smpclk*resolution(3)/(2*FOV(3)*gradient_sensitivity_Hz_cm_M(slice_vec(3)));



% groArea = 0;
% gpeArea_1 = 0;
% gpeArea_2 = 0;

gr_ramp = round((gradient_ramp_time/(1/psd.grad.smpclk))); % gradient trapezoid ramps (# samples to ramp)

% load sequence parameters into PSD structure
psd.rfrx.freq = freq;	  psd.rftx.freq = freq;
psd.ctrl.ntrs = 1;
psd.param.Nro = resolution(1);
psd.param.Npe = 1;
psd.param.tr = tr;
psd.ctrl.trlength = tr*psd.ctrl.smpclk;
psd.param.te = te;
psd.param.tpe = tpe;
psd.param.tro = tro;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initialize MEDUSA console
psd.id = 100;   psd.fid = 0;

% initialize console parameters
% setup NodeID addresses
psd.ctrl.nodeid = hex2dec('011000');	% Medusa Controller
psd.rfrx.nodeid = hex2dec('010000');	% Medusa RF module for Rx
psd.rftx.nodeid = hex2dec('010000');	% Medusa RF module for Tx
psd.grad.nodeid = hex2dec('010800');	% Medusa Gradient module

%% Define pulses and readout

% define transmit pulses

pulse_RF_90 = [rftx_amp_90*ones(1, (rftx_time_90-tx_gating_time)*psd.rftx.smpclk)];  % define shape of 90 deg RF pulse
pulse_RF_180 = [1i*rftx_amp_180*ones(1, (rftx_time_180-tx_gating_time)*psd.rftx.smpclk)]; % define shape of 180 deg RF pulse

% define gradient pulses using gradient moments
gro_rewinder = [grLobeTrap(1*groArea/2, gr_ramp, trew, psd.grad.smpclk)]; % preparation windup for readout
gro_readout = [grLobeTrap(groArea,   gr_ramp, tro+2*gr_ramp/psd.grad.smpclk, psd.grad.smpclk)];  % readout gradient pulse

gpe1_delta = [grLobeTrap(gpeArea_1, gr_ramp, tpe, psd.grad.smpclk)];	% delta_k PE1 gradient pulse
gpe2_delta = [grLobeTrap(gpeArea_2, gr_ramp, tpe, psd.grad.smpclk)];  % delta_k PE2 gradient pulse

if resolution(3) == 1, gpe2 = 0; end

% define crusher gradient pulses
crusher_RO = grLobeTrap(abs(groArea)*scale_crushers(1), gr_ramp, tcr, psd.grad.smpclk);
crusher_PE1 = grLobeTrap(abs(groArea)*scale_crushers(2), gr_ramp, tcr, psd.grad.smpclk);
crusher_PE2 = grLobeTrap(abs(groArea)*scale_crushers(3), gr_ramp, tcr, psd.grad.smpclk);

crusher_smplen = length(crusher_PE1);

% create empty vectors for each gradient waveform
gro = zeros(1,floor(tr*psd.grad.smpclk)-1);
gpe1 = zeros(1,floor(tr*psd.grad.smpclk)-1);
gpe2 = zeros(1,floor(tr*psd.grad.smpclk)-1);


% add ssi
ssi = 0*gro.'; ssi(1) = hex2dec('1000')/32767;	% create start-of-sequence flag
% add gating
gate = 0*gro.';




%% set sequence event timing

% TRANSMIT ====================================
psd.rftx.data = [];
psd.rftx.data = [psd.rftx.data eps*ones(1,round(tx_gating_time*psd.rftx.smpclk))];
psd.rftx.data = [psd.rftx.data pulse_RF_90];
psd.rftx.data = [psd.rftx.data zeros(1,round((te/2-rftx_time_90/2-rftx_time_180/2-tx_gating_time)*psd.rftx.smpclk))];
psd.rftx.data = [psd.rftx.data eps*ones(1,round(tx_gating_time*psd.rftx.smpclk))];
psd.rftx.data = [psd.rftx.data 0];

%
first_180_smp = round(tx_gating_time*psd.rftx.smpclk)+length(pulse_RF_90)+round((te/2-rftx_time_90/2-rftx_time_180/2-tx_gating_time)*psd.rftx.smpclk)+round(tx_gating_time*psd.rftx.smpclk)+1;
pulse_180_smplen = length(pulse_RF_180);
pulse_90_smplen = length(pulse_RF_90);
%

psd.rftx.data = [psd.rftx.data pulse_RF_180];
psd.rftx.data = [psd.rftx.data 0];
 
for echo_n = 1:num_echoes-1 % concatenation of subsequent transmit pulse (rftx.data) echo train
    psd.rftx.data = [psd.rftx.data zeros(1,round((te-rftx_time_180-tx_gating_time)*psd.rftx.smpclk))];
    psd.rftx.data = [psd.rftx.data eps*ones(1,round(tx_gating_time*psd.rftx.smpclk))];
    psd.rftx.data = [psd.rftx.data pulse_RF_180];
    psd.rftx.data = [psd.rftx.data 0];
end

psd.rftx.start = 1;
psd.rftx.length = length(psd.rftx.data);

echo_interval_smp = round((te-rftx_time_180-tx_gating_time)*psd.rftx.smpclk)+round(tx_gating_time*psd.rftx.smpclk)+length(pulse_RF_180)+1;

% RECIEVE BLOCK ====================================
% psd.rfrx.start = round( (te - .5*tro + rftx_time_90/2)*psd.rfrx.smpclk);
% psd.rfrx.length = resolution(1);
% psd.rfrx.data = zeros(1,psd.rfrx.length);

psd.rfrx.start = first_180_smp + pulse_180_smplen + 1;
psd.rfrx.length = tr*psd.rfrx.smpclk - psd.rfrx.start;
psd.rfrx.data = zeros(1,psd.rfrx.length);

% define PE pulse start and end times
pe_start_ind = first_180_smp + pulse_180_smplen + 1;
pe_end_ind = pe_start_ind + length(gpe1_delta) - 1;

pr_end_ind = first_180_smp + echo_interval_smp - 1;
pr_start_ind = pr_end_ind - length(gpe1_delta) + 1;

% generate normalized phase encode steps
pe1_steps = linspace(-(frac_ksp*2-1),1,num_echoes);
pe2_steps = 0;

% add PEs to sequence
gpe1(pe_start_ind:pe_end_ind) = gpe1_delta*pe1_steps(1);
gpe1(pr_start_ind:pr_end_ind) = -1*gpe1_delta*pe1_steps(1);
gpe2(pe_start_ind:pe_end_ind) = gpe2_delta*pe1_steps(1);
gpe2(pr_start_ind:pr_end_ind) = -1*gpe2_delta*pe1_steps(1);


for echo_n = 1:num_echoes-1 % concatenation of subsequent transmit pulse (rftx.data) echo train
    pe_start_ind = pe_start_ind + echo_interval_smp;
    pe_end_ind = pe_end_ind + echo_interval_smp;
    pr_start_ind = pr_start_ind + echo_interval_smp;
    pr_end_ind = pr_end_ind + echo_interval_smp;
    
    gpe1(pe_start_ind:pe_end_ind) = gpe1_delta*pe1_steps(1+echo_n);
    gpe1(pr_start_ind:pr_end_ind) = -1*gpe1_delta*pe1_steps(1+echo_n);
    gpe2(pe_start_ind:pe_end_ind) = gpe2_delta*pe1_steps(1+echo_n);
    gpe2(pr_start_ind:pr_end_ind) = -1*gpe2_delta*pe1_steps(1+echo_n);
    
end

% add rewinder to sequence
rw_start_ind =  round(tx_gating_time*psd.rftx.smpclk)+pulse_90_smplen + 3; %pad after 90
gro(rw_start_ind:rw_start_ind+numel(gro_rewinder)-1) = gro_rewinder;

% define readout pulse start and end times
readout_start_ind = round((te-tro/2 + rftx_time_90/2)*psd.grad.smpclk) - gr_ramp - 1;
readout_end_ind = readout_start_ind + numel(gro_readout) - 1;

% add readout gradient into sequence
gro(readout_start_ind:readout_end_ind) = gro_readout;


data_ro_ind = [readout_start_ind:readout_end_ind];
for echo_n = 1:num_echoes-1 % concatenation of readout gradients for echo train

    data_ro_ind = [data_ro_ind ; readout_start_ind:readout_end_ind];

    readout_start_ind = readout_start_ind + echo_interval_smp;
    readout_end_ind = readout_end_ind + echo_interval_smp;
    
    gro(readout_start_ind:readout_end_ind) = gro_readout;

end

% switches to disable (or scale) gradient pulses
gro = ro_switch*gro;
gpe1 = pe1_switch*gpe1;
gpe2 = pe2_switch*gpe2;

% set crusher start and end indices within gradient vector
crusher_pre_start_ind = ceil((rftx_time_90/2 + te/2 - tcr - tx_gating_time + 0*400e-6)*psd.grad.smpclk)-1;
crusher_pre_end_ind = crusher_pre_start_ind + numel(crusher_RO)-1;

crusher_post_start_ind = ceil((rftx_time_90/2 + te/2 + rftx_time_180 - tx_gating_time + 0*400e-6)*psd.grad.smpclk)-1;
crusher_post_end_ind = crusher_post_start_ind + numel(crusher_RO)-1;



%%
    % set up readout, PE, and PE2 directions

    %gx_temp = gro';
    gx_temp = gro';
    if resolution(2) > 1, gy_temp = gpe1' ; else gy_temp = 0*gpe1'; end
    if resolution(3) > 1, gz_temp = gpe2' * 0; else gz_temp = 0*gpe2'; end
    
    gy_temp = gpe1';
    gz_temp = gpe1'*0;
    
    temp = [gx_temp.'; gy_temp.'; gz_temp.'];
    %psd.grad.data = [temp(ind_x,:); temp(ind_x,:); temp(ind_x,:); ssi.'; gate.']; 
     psd.grad.data = [temp(ind_x,:); temp(ind_y,:); temp(ind_z,:); ssi.'; gate.']; % working version of this line




temp_crusher = [crusher_RO; crusher_PE1; crusher_PE2];
psd.grad.data(1,crusher_pre_start_ind:crusher_pre_end_ind) = psd.grad.data(1,crusher_pre_start_ind:crusher_pre_end_ind) + temp_crusher(ind_x,:);
psd.grad.data(2,crusher_pre_start_ind:crusher_pre_end_ind) = psd.grad.data(2,crusher_pre_start_ind:crusher_pre_end_ind) + temp_crusher(ind_y,:);
psd.grad.data(3,crusher_pre_start_ind:crusher_pre_end_ind) = psd.grad.data(3,crusher_pre_start_ind:crusher_pre_end_ind) + temp_crusher(ind_z,:);

psd.grad.data(1,crusher_post_start_ind:crusher_post_end_ind) = psd.grad.data(1,crusher_post_start_ind:crusher_post_end_ind) + temp_crusher(ind_x,:);
psd.grad.data(2,crusher_post_start_ind:crusher_post_end_ind) = psd.grad.data(2,crusher_post_start_ind:crusher_post_end_ind) + temp_crusher(ind_y,:);
psd.grad.data(3,crusher_post_start_ind:crusher_post_end_ind) = psd.grad.data(3,crusher_post_start_ind:crusher_post_end_ind) + temp_crusher(ind_z,:);


for echo_n = 1:num_echoes % concatenation of crusher gradients for echo train

    crusher_pre_start_ind = crusher_pre_start_ind  + echo_interval_smp;  
    crusher_pre_end_ind = crusher_pre_end_ind  + echo_interval_smp;  
    crusher_post_start_ind = crusher_post_start_ind  + echo_interval_smp;  
    crusher_post_end_ind = crusher_post_end_ind  + echo_interval_smp;  
    
    psd.grad.data(1,crusher_pre_start_ind:crusher_pre_end_ind) = psd.grad.data(1,crusher_pre_start_ind:crusher_pre_end_ind) + temp_crusher(ind_x,:);
    psd.grad.data(2,crusher_pre_start_ind:crusher_pre_end_ind) = psd.grad.data(2,crusher_pre_start_ind:crusher_pre_end_ind) + temp_crusher(ind_y,:);
    psd.grad.data(3,crusher_pre_start_ind:crusher_pre_end_ind) = psd.grad.data(3,crusher_pre_start_ind:crusher_pre_end_ind) + temp_crusher(ind_z,:);

    psd.grad.data(1,crusher_post_start_ind:crusher_post_end_ind) = psd.grad.data(1,crusher_post_start_ind:crusher_post_end_ind) + temp_crusher(ind_x,:);
    psd.grad.data(2,crusher_post_start_ind:crusher_post_end_ind) = psd.grad.data(2,crusher_post_start_ind:crusher_post_end_ind) + temp_crusher(ind_y,:);
    psd.grad.data(3,crusher_post_start_ind:crusher_post_end_ind) = psd.grad.data(3,crusher_post_start_ind:crusher_post_end_ind) + temp_crusher(ind_z,:);

end


    % add in shim settings -- does not depend on slice orientation
    psd.grad.data(1,:) = psd.grad.data(1,:) + shims(1);
    psd.grad.data(2,:) = psd.grad.data(2,:) + shims(2);
    psd.grad.data(3,:) = psd.grad.data(3,:) + shims(3);



%% check minimum TE and break out of sequence if timing is incorrect

data = zeros((resolution));
data_all = zeros(resolution(1),resolution(2),resolution(3),num_ave);


%%   LOOP THROUGH SEQUENCE CALLS (PHASE ENCODES, ETC.)
img_all = [];
img_complex_all = [];
for vv = 1:num_ave
for shot = 1:num_shots
        if get(H.toggle_stop_button,'Value') == 0


    
        if mod(vv,4)==1        
            ph_cycle = exp(1i*0);
        elseif mod(vv,4)==2
            ph_cycle = exp(1i*pi/2);
        elseif mod(vv,4)==3
            ph_cycle = exp(1i*pi);
        elseif mod(vv,4)==0
            ph_cycle = exp(1i*3*pi/2);
        end

        % TRANSMIT ====================================
        psd.rftx.data = [];
        psd.rftx.data = [psd.rftx.data eps*ones(1,round(tx_gating_time*psd.rftx.smpclk))];
        psd.rftx.data = [psd.rftx.data ph_cycle*pulse_RF_90];
        psd.rftx.data = [psd.rftx.data zeros(1,round((te/2-rftx_time_90/2-rftx_time_180/2-tx_gating_time)*psd.rftx.smpclk))];
        psd.rftx.data = [psd.rftx.data eps*ones(1,round(tx_gating_time*psd.rftx.smpclk))];


        psd.rftx.data = [psd.rftx.data ph_cycle*pulse_RF_180];
        psd.rftx.data = [psd.rftx.data 0];

        for echo_n = 1:num_echoes-1 % concatenation of subsequent transmit pulse (rftx.data) echo train
            psd.rftx.data = [psd.rftx.data zeros(1,round((te-rftx_time_180-tx_gating_time)*psd.rftx.smpclk))];
            psd.rftx.data = [psd.rftx.data eps*ones(1,round(tx_gating_time*psd.rftx.smpclk))];
            psd.rftx.data = [psd.rftx.data ph_cycle*pulse_RF_180];
            psd.rftx.data = [psd.rftx.data 0];
        end

        psd.rftx.start = 1;
        psd.rftx.length = length(psd.rftx.data);    


    % define total number of gradient points
    psd.grad.start = 1;
    psd.grad.length = length(psd.grad.data);


    if max(max(abs(psd.grad.data))) > gradient_safety_threshold
       fprintf(['Error: \tgradient strength too high\n'])
       crash
    end


    %% check sequence parameters for consistency ==============================

    if te/2 < rftx_time_90/2 + tpe + rftx_time_180/2
        fprintf(['ERROR:\t TE = ',num2str(te),' is too short for the specified RF pulse and phase encode lobe durations\n']) 
        crash
    end

    if te/2 < rftx_time_90/2 + trew + rftx_time_180/2
        fprintf(['ERROR:\t TE = ',num2str(te),' is too short for the specified RF pulse and rewind gradient lobe durations\n']);
        crash
    end

    if te/2 < rftx_time_180/2 + tro/2
        fprintf(['ERROR:\t TE = ',num2str(te),' is too short for the specified RF pulse and readout gradient lobe durations\n']);
        crash
    end

    if tr < te + tro/2 + rftx_time_90/2
       fprintf(['ERROR:\t TR = ',num2str(tr),' is too short for the specified TE\n']);
       crash 
    end

    % JPS ---> FOR DEBUGGING AND GPA TESTING!!!!! 02/13/2013
    if vv == 1  && shot == 1
     %   psd.grad.data = .1.*psd.grad.data;
    end
    
    %% run sequence ===========================================================
    if debug_switch == 0
        medusaPsdConfigure(psd);
        psd = medusaPsdRunStream(psd);  end_time = toc; pause((tr-end_time)), tic
    else
        %psd.rfrx.data(:) = 0;   %psd.rfrx.data(round(numel(psd.rfrx.data)/2)) = 1; 
        end_time = toc; pause((tr-end_time)), tic
    end
    % =========================================================================
    
    data = [zeros(1,psd.rfrx.start-1) psd.rfrx.data];
    
    plot(H.readout_plot,abs(data)),title(H.readout_plot,'readout')
    plot(H.projection_plot,abs(fftshift(fft(data)))),title(H.projection_plot,'1-D projection')
    
    
    
    data_size = size(data_ro_ind);
    kspace = zeros(full_pe,data_size(2));

    for pe_n = 1:full_pe
        if pe_n < full_pe - num_echoes + 2
            kspace(pe_n,:) = 0; % conj(data(data_ro_ind(64-pe_n+1-16,:)));x
        else
            kspace(pe_n,:) = data(data_ro_ind(pe_n-(full_pe-num_echoes),:));
        end
    end

    kspace = kspace(:,10:105);  % HARD CODED -->  MUST FIX THIS!!!
    %imagesc(abs(kspace));
    % JPS commented out on 02/13/2013
  %%  subplot(1,2,1);
  %%  imagesc(abs(kspace));
  %%  subplot(1,2,2);
  %%  imagesc(abs(fftshift(fft2(fftshift(kspace.'))))); colormap(gray);
    shot_img = abs(fftshift(fft2(fftshift(kspace.'))));
    shot_complex_img = fftshift(fft2(fftshift(kspace.')));
    kspace_all(:,:,vv) = kspace.';
    img_all(:,:,vv) = shot_img;
    img_complex_all(:,:,vv) = shot_complex_img;
    
    data = kspace.';
    data_all(:,:,1,vv) = kspace.';
    
        end
end


  if resolution(3) == 1
     avg_image = mean(img_all,3);
     avg_complex_image = mean(img_complex_all,3);
     
     imagesc(flipdim(mean(abs(kspace_all),3),1),'Parent',H.kspace_plot), axis(H.kspace_plot,'image'),pause(1e-9)
     title(H.kspace_plot,'kspace data')
     
     % removed 5/5/2013 so students can't see images on GUI
     imagesc(flipdim(abs(avg_image),1),'Parent',H.image_plot); axis(H.image_plot,'image')
     title(H.image_plot,'object image')
   
  end


end

% figure(10); plot(psd.grad.data'); hold on;
% plot(abs(psd.rftx.data'));
% plot(abs(data')/3,'k');
% hold off;

% JPS commented out 02/13/2013
%imagesc(flipdim(avg_image,1),'Parent',H.image_plot); axis(H.image_plot,'image');

% JPS commented out 02/13/2013


%psdPrintStats(psd);


psd.data = data;
psd.data_ave = mean(data_all,4);

TSE = psd;








