%% GUI for MIT 6.02M scanner control
%% 
%% Calls subroutines to acquire FIDs and create projections and images of
%% test objects.  Allows user to save data to a .dat file.  

function varargout = FID_gui_layout(varargin)
% FID_GUI_LAYOUT MATLAB code for FID_gui_layout.fig
%      FID_GUI_LAYOUT, by itself, creates a new FID_GUI_LAYOUT or raises the existing
%      singleton*.5
%
%      H = FID_GUI_LAYOUT returns the handle to a new FID_GUI_LAYOUT or the handle to
%      the existing singleton*.
%
%      FID_GUI_LAYOUT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FID_GUI_LAYOUT.M with the given input arguments.
%
%      FID_GUI_LAYOUT('Property','Value',...) creates a new FID_GUI_LAYOUT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before FID_gui_layout_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to FID_gui_layout_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help FID_gui_layout

% Last Modified by GUIDE v2.5 29-Dec-2012 02:47:14

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @FID_gui_layout_OpeningFcn, ...
                   'gui_OutputFcn',  @FID_gui_layout_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before FID_gui_layout is made visible.
function FID_gui_layout_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to FID_gui_layout (see VARARGIN)

% Choose default command line output for FID_gui_layout
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes FID_gui_layout wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = FID_gui_layout_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



% --- Executes during object creation, after setting all properties.
function psd_plot_CreateFcn(hObject, eventdata, handles)
% hObject    handle to psd_plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate psd_plot


% --- Executes on button press in run_scan_tag.
% Run FID sequence
function run_scan_tag_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to run_scan_tag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% disp(['psd.num_reps is ',num2str(psd.num_reps)])
debug_mode = isfield(psd,'debug_mode');
if debug_mode == 0
% for ii=1:psd.num_reps
% [FID] = FID_func; 
% time_block = [FID.time.' FID.time.'];
% data_block = [abs(FID.data) imag(FID.data)];
% hold on,plot(handles.readout_plot,time_block,data_block)
% xlabel(handles.readout_plot,'time (sec)'),hold off, title('FID / echo')
% plot(handles.projection_plot,FID.freq_axis,abs(FID.spec))
% xlabel('freq (Hz)'),pause(1e-6)
% max(max(abs(FID.data)))
% axis([FID.freq_axis(1) FID.freq_axis(end) 0 1.25*max(max(abs(FID.spec)))])
% title('spectrum / projection')
% end
end



function num_reps_box_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to num_reps_box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
psd.num_reps = str2num(get(handles.num_reps_box,'String'))

% Hints: get(hObject,'String') returns contents of num_reps_box as text
%        str2double(get(hObject,'String')) returns contents of num_reps_box as a double


% --- Executes during object creation, after setting all properties.
function num_reps_box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num_reps_box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




function f0_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to f0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of f0 as text
%        str2double(get(hObject,'String')) returns contents of f0 as a double
psd.f0 = str2num(get(handles.f0,'String'))



% --- Executes during object creation, after setting all properties.
function f0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to f0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function file_path_Callback(hObject, eventdata, handles)
% hObject    handle to file_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    
% Hints: get(hObject,'String') returns contents of file_path as text
%        str2double(get(hObject,'String')) returns contents of file_path as a double


% --- Executes during object creation, after setting all properties.
function file_path_CreateFcn(hObject, eventdata, handles)
% hObject    handle to file_path (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in save_button.
function save_button_Callback(hObject, eventdata, handles)
% hObject    handle to save_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function tr_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to tr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tr as text
%        str2double(get(hObject,'String')) returns contents of tr as a double
psd.tr = str2num(get(handles.tr,'String'))



% --- Executes during object creation, after setting all properties.
function tr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





% --- Executes on button press in FID_button.
function FID_button_Callback(hObject, eventdata, handles)
% hObject    handle to FID_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of FID_button


% --- Executes on button press in stop_button.
function stop_button_Callback(hObject, eventdata, handles)
% hObject    handle to stop_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




function tro_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to tro (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tro as text
%        str2double(get(hObject,'String')) returns contents of tro as a double
psd.tro = str2num(get(handles.tro,'String'))



% --- Executes during object creation, after setting all properties.
function tro_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tro (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in debug_mode.
function debug_mode_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to debug_mode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of debug_mode
psd.debug_mode = 1
