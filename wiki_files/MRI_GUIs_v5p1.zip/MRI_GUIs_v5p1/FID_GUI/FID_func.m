%% edited by Clarissa on 2/18/15   - moved averaging and repitition loops to func instead of GUI file
%% fixed bug:   saves averaged signal
%% edited by Jason in March 2015 -- added frequency finder feature

% This sequence is called by FID_GUI
% For use with the MIT 6.S02 laboratory imaging system
% Jan 3, 2013
%
% The PSD is rendered as a Matlab structure called 'psd'.
% Since this script uses only the RF Tx/Rx system (no gradients),
% it will not fill in the data tree for psd.grad.
%
% This PSD will generate a short hard pulse excitation,
% followed by a receive acquisition window to get the FID.

function [FID] = FID_func
global psd
global H

    
psd.rfrx.freq = 1e6*psd.f0;
rftx_amp = psd.rftx_amp;
rftx_time = psd.rftx_time(1);
%%%%CZC 2/18/15%%%%%%%%%%%%%%%%%%%
num_ave = psd.num_ave;
num_reps = psd.num_reps;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tr = psd.tr*1e-3;
psd.param.tr = tr;
rfrx_time = psd.tro*1e-3;			% set receive acquisition length (100ms)

psd.auto_shim         % 1 to re-run shim optimizer, 0 to load old shim value
shims = psd.shims;
shim_bound = 1000;   TolX = 1e-9;    % the smaller the tolerance, the longer the shim optimizer will run


% set RF transmitter gain -- not relevant for our hardware setup
psd.rftx.gain = 0;		% (0 * 3dB/step = 0dB -- has no effect unless external PGA amp is used)
% setup RF carrier frequencies (in Hz)




ff = 1;
num_flips = numel(rftx_amp);


% receive parameters
rfrx_delay = rftx_time + 600e-6;		% set receive acquisition to shortly after transmit pulse ends


% setup TR timing parameters
% controller
psd.ctrl.trlength = tr*psd.ctrl.smpclk;		% set overall TR length (measured in Controller samples)
psd.ctrl.ntrs = 1;						% set number of TRs in the scan
% RF receiver
psd.rfrx.start = 1+round( rfrx_delay*psd.rfrx.smpclk );			% start Rx acquire this many samples from start of TR
psd.rfrx.length = round( rfrx_time*psd.rfrx.smpclk );			% acquire this many Rx samples per TR
psd.rfrx.data = zeros(1,psd.ctrl.ntrs*psd.rfrx.length);		% preallocate the memory for the Rx data

psd.grad.data = zeros(5,rfrx_time*psd.rfrx.smpclk);
psd.grad.start = 1;
psd.grad.length = length(psd.grad.data);


smpperiod = 1/psd.rfrx.smpclk;
points =  psd.rfrx.length;
time = (smpperiod:smpperiod:points*smpperiod).';
freq_axis = .001*[-ceil(points/2):1:floor(points/2)-1]*psd.rfrx.smpclk/points;


shim_string = ['xyz'];


pulse_dur_ind = 1;


while(uint8(pulse_dur_ind) <= uint8(numel(psd.rftx_time))  && get(H.toggle_stop_button,'Value') == 0)  
    set(H.rftx_time_90,'String',num2str(round(1e6*psd.rftx_time(pulse_dur_ind))));
   
    
    
    clear psd.rftx.data
        psd.rftx.freq = psd.rfrx.freq;
        psd.rftx.data = rftx_amp(ff)*ones(1, psd.rftx_time(pulse_dur_ind)*psd.rftx.smpclk);
        % force terminate RF Tx to zero at end of pulse
        psd.rftx.data = [psd.rftx.data 1/4095 1/4095 0];  % account for one point quantization error, then force transmitter to zero
        % generate RF pulse array from single pulse
        % data should have the format:
        %   [[Tx-Ch1 for TR#0] [Tx-Ch1 for TR#1] ... [Tx-Ch1 for TR#N]]
        % replicate same RF pulse for each TR
        psd.rftx.data = psd.rftx.data';
        % reshape RF data back to 1 row
        psd.rftx.data = reshape(psd.rftx.data, 1, size(psd.rftx.data,1)*size(psd.rftx.data,2));
        % RF transmitter
        psd.rftx.start = 1;										% start Tx playback at first sample of TR
        psd.rftx.length = size(psd.rftx.data,2)/psd.ctrl.ntrs;	% play this many Tx samples per TR

        %%
        % print information about the sequence
        psdPrintStats(psd);



    
     if psd.find_center_freq_key == 1
         tic
     end
        %% create RF pulse pulses
        % make single hard pulse (containing rftx_time*psd.rftx.smpclk samples)
    
   
for ff = 1:num_flips
    if get(H.toggle_stop_button,'Value') == 0
        for  ii = 1:psd.num_reps
            if get(H.toggle_stop_button,'Value') == 0
                datablock = [];
                dataout = [];
                data_all = [];
                for aa = 1:psd.num_ave
                     if psd.find_center_freq_key == 0
                        tic
                     end
                    if get(H.toggle_stop_button,'Value') == 0
                        
                        if (get(H.find_center_freq_check_box,'Value') == get(H.find_center_freq_check_box,'Max'))
                            set(H.find_center_freq_check_box, 'Value', 0);
                        end
                        
                        
                        if num_flips > 1
                            psd.rftx.data = rftx_amp(ff)*ones(1, psd.rftx_time(1)*psd.rftx.smpclk);
                            % force terminate RF Tx to zero at end of pulse
                            psd.rftx.data = [psd.rftx.data 1/4095 1/4095 0];  % account for one point quantization error, then force transmitter to zero
                            % generate RF pulse array from single pulse
                            % data should have the format:
                            %   [[Tx-Ch1 for TR#0] [Tx-Ch1 for TR#1] ... [Tx-Ch1 for TR#N]]
                            % replicate same RF pulse for each TR
                            psd.rftx.data = psd.rftx.data';
                            % reshape RF data back to 1 row
                            psd.rftx.data = reshape(psd.rftx.data, 1, size(psd.rftx.data,1)*size(psd.rftx.data,2));
                            
                        end
                        
                        
                        
                        % update shims in real time while sequence is repeating
                        % scale the shim current from mA to units of GPA output control signal
                        psd.shims(1) = get(H.x_shim_slider,'Value');
                        psd.shims(2) = get(H.y_shim_slider,'Value');
                        psd.shims(3) = get(H.z_shim_slider,'Value');
                        
                        psd.shims_mA = round(psd.shims);
                        psd.shims = psd.shims_mA./psd.shim_scale_factor;
                        
                        set(H.x_shim_text,'String',num2str(psd.shims_mA(1)));
                        set(H.y_shim_text,'String',num2str(psd.shims_mA(2)));
                        set(H.z_shim_text,'String',num2str(psd.shims_mA(3)));
                        
                        if (get(H.auto_scale_check_box,'Value') == get(H.auto_scale_check_box,'Max'))
                            psd.auto_scale = 1;
                        else
                            psd.auto_scale = 0;
                        end
                        
                        if (get(H.auto_shim_check_box,'Value') == get(H.auto_shim_check_box,'Max'))
                            psd.auto_shim = 1;
                        %    set(H.auto_shim_check_box,'Value',0);
                        else
                            psd.auto_shim = 0;
                        end
                        
                        if (get(H.flip_angle_cal_check_box,'Value') == get(H.flip_angle_cal_check_box,'Max'))
                            psd.flip_angle_cal = 1;
                        else
                            psd.flip_angle_cal = 0;
                            
                        end
                        
                        if psd.auto_shim == 1 && psd.flip_angle_cal == 1
                            set(H.system_status,'ForegroundColor',[1 0 0])
                            set(H.system_status,'String','CAN NOT PERFORM AUTO SHIM AND FLIP ANGLE CAL AT THE SAME TIME')
                            crash
                        end
                        
                        if psd.find_center_freq_key ~= 1
                            set(H.system_status,'ForegroundColor',[0 1 0])
                            set(H.system_status,'String','SYSTEM STATUS: NORMAL')
                        end
                        
                        
                        
                        if psd.auto_shim == 1
                            freq_axis = .001.*[-ceil(psd.rfrx.length/2):1:floor(psd.rfrx.length/2)-1]*psd.rfrx.smpclk/psd.rfrx.length;  % freq in KHz
                            smpperiod = 1/psd.rfrx.smpclk;
                            time = (smpperiod:smpperiod:psd.rfrx.length*smpperiod);
                            
                            options = optimset('MaxIter',10000,'TolX',TolX);
                            for dd=1:3,disp(['shimming ',num2str(shim_string(dd))])
                                if get(H.toggle_stop_button,'Value') ~= 1
                                    [new_shim FVAL EXITFLAG] = fmincon(@(new_shim)shim_opt_MIT_func(new_shim,dd,shims,freq_axis,time,psd),...
                                        [-0.0001],[],[],[],[],[-shim_bound],[shim_bound],[],options);
                                end
                                shims(dd) = new_shim;
                                shims_mA(dd) = round(shims(dd).*H.shim_scale_factor);
                                string = 'xyz';
                                eval(['set(H.',string(dd),'_shim_text,''String'',shims_mA(',num2str(dd),'))'])
                                eval(['set(H.',string(dd),'_shim_slider,''Value'',shims_mA(',num2str(dd),'))'])
                                
                            end
                            FVAL,EXITFLAG
                            % save shims.mat shims
                            set(H.system_status,'ForegroundColor',[0 1 0])
                            set(H.system_status,'String','NEW SHIM SETTINGS SAVED TO FILE SHIMS.MAT')
                            
                            psd.grad.data(1,:) = shims(1);
                            psd.grad.data(2,:) = shims(2);
                            psd.grad.data(3,:) = shims(3);
                            
                            medusaPsdConfigure(psd);
                            psd = medusaPsdRunStream(psd);
                            psd.shims = shims;
                        else
                            psd.grad.data(1,:) = psd.shims(1);
                            psd.grad.data(2,:) = psd.shims(2);
                            psd.grad.data(3,:) = psd.shims(3);
                         %   figure(10),plot(psd.grad.data.'),title(num2str(size(psd.grad.data))),pause(.1)
                          %  shims
                            medusaPsdConfigure(psd);
                            psd = medusaPsdRunStream(psd);
                        end
                        
                        
                        
                        if (get(H.auto_shim_check_box,'Value') == get(H.auto_shim_check_box,'Max'))
                            set(H.auto_shim_check_box,'Value',0);
                            psd.auto_shim = 0;
                        end
                        
                        if (get(H.flip_angle_cal_check_box,'Value') == get(H.flip_angle_cal_check_box,'Max'))
                            set(H.flip_angle_cal_check_box,'Value',0);
                            psd.flip_angle_cal = 0;
                        end
                        
                        
                        %%%read data
                        data = psd.rfrx.data;   %%raw data
                        data_all(:,aa) = data;  %%all data from 1 repetition
                        
                        %%variables for plotting and saving data
                        FID_current = data;
                        FID_avg = mean(data_all,2);
                        SPEC_current = fftshift(fft(fftshift(FID_current)));
                        SPEC_avg = fftshift(fft(fftshift(FID_avg)));
                        
                        
                        %%plot FID%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        plot(H.readout_plot,[time time],[abs(FID_avg) real(FID_avg)]);
                        title(H.readout_plot, 'free induction decay');
                        xlabel(H.readout_plot,'time (sec)');
                        %%%set axis limits for FID plot
                        if ii == 1 && aa == 1
                            psd.first_FID_mag_ref = 1.05*max(max(abs(FID_current)));
                        end
                        if psd.auto_scale == 0 && psd.find_center_freq_key == 0
                            axis(H.readout_plot,[0  time(end)  -psd.first_FID_mag_ref  psd.first_FID_mag_ref])
                        elseif psd.find_center_freq_key == 0
                            axis(H.readout_plot,[0  time(end)  -1.05*max(max(abs(FID_avg)))  1.05*max(max(abs(FID_avg)))])
                        end
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        
                        
                        %%plot spectrum%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        plot(H.projection_plot,freq_axis,abs(SPEC_avg));
                        xlabel(H.projection_plot,'freq (KHz)')
                        %%%set axis limits for spectrum plot
                        if ii == 1 && aa == 1
                            psd.first_spec_mag_ref = 1.05*max(max(abs(SPEC_current)));
                        end
                        
                        if psd.auto_scale == 0
                            axis(H.projection_plot,[freq_axis(1) freq_axis(end) 0 psd.first_spec_mag_ref])
                        else
                            axis(H.projection_plot,[freq_axis(1) freq_axis(end) 0 1.05*max(abs(SPEC_avg))])
                        end
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        
                        %%SPECTRUM SNR CALC%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        noise = (SPEC_avg(10:round(numel(SPEC_avg)./6)));
                        noisestd = std(abs(noise));
                        SNR = max(abs(SPEC_avg))/noisestd;
                        title(H.projection_plot,['frequency spectrum, SNR = ', num2str(SNR)]);  %label SNR in title of spectrum plot
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        
                        
                        datacursormode on;
                        
                        
                         if psd.find_center_freq_key ~= 1
                            set(H.system_status,'ForegroundColor',[0 1 0])
                            set(H.system_status,'String','SYSTEM STATUS: NORMAL')
                        end
                        
                        
                        if aa < psd.num_ave
                            toc, pause(psd.tr*1e-3 - toc)  %%% sets TR
                        end
                        
                    end   %%end if stop button is pushed (inside average loop)
                end  % average loop
                
                
                if ii < psd.num_reps
                    toc, pause(psd.tr*1e-3 - toc)  %%% sets TR
                end
                
            end    %%end if stop button is pushed (inside rep loop)
        end     %reps loops
        
        
        if num_flips > 1
            
            [Y I] = max(abs(SPEC_avg));   freq_peak = freq_axis(I);  Y_all(ff) = Y;  I_all(ff) = I;
            
            if I_all(ff) < 10, I_all(ff) = I_all(ff)+20; end
            if I_all(ff) > numel(SPEC_avg)-10, I_all(ff) = I_all(ff)-20; end
            int_spec(ff) = sum(abs(SPEC_avg(I_all(ff)-3:I_all(ff)+3)));
            
            plot(H.flip_angle_plot,rftx_amp(1:ff),int_spec,'o')
            title(H.flip_angle_plot,['pulse length is ',num2str((rftx_time*1000)),' ms']),pause(1e-6)
            xlabel(H.flip_angle_plot,'transmit amplitude')
            ylabel(H.flip_angle_plot,'relative signal amplitude')
            
            datacursormode on;
            toc, pause(tr - toc);   %%% sets TR
            
        end
        
    end  %%end if stop button is pushed (inside flip angle loop)
end  % flip angle loop


if psd.find_center_freq_key ~= 1
    pulse_dur_ind = 2;   % break while loop
      
end

if psd.find_center_freq_key == 1
    [Y,I] = max(abs(SPEC_avg));
   if Y > 5*mean(abs(SPEC_avg))  % frequency finder is considered successful if the 
     psd.new_f0 = (psd.f0 + .001*freq_axis(I));    
         set(H.system_status,'ForegroundColor',[0 1 0])
         set(H.system_status,'String',['UPDATED CENTER FREQUENCY TO ',num2str(psd.new_f0),' MHz'])  
         pulse_dur_ind = numel(psd.rftx_time) + 1;   % break while loop
   elseif pulse_dur_ind < numel(psd.rftx_time)
       pulse_dur_ind = pulse_dur_ind + 1;
   else
      psd.new_f0 = psd.f0;
         set(H.system_status,'ForegroundColor',[1 0 0])
         set(H.system_status,'String',['UNABLED TO FIND CENTER FREQ.  PLEASE RESET MEDUSA AND CHECK SAMPLE AND COIL POSITIONS IN SCANNER.'])        
      pulse_dur_ind = pulse_dur_ind + 1;
   end    
end


     if psd.find_center_freq_key == 1
          toc, pause(2 - toc)  %%% repeat every 2 seconds
     end
end

FID.data_ave = FID_avg;
FID.data = FID_current;
FID.time = time;
FID.spec = SPEC_avg;
FID.freq_axis = freq_axis;





