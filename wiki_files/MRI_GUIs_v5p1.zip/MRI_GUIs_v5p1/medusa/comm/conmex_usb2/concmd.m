function concmd(sock,nodeid,cmd,args)
% function concmd(sock,nodeid,cmd,[args])
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

conmex('write', nodeid, cmd, 2, args);
