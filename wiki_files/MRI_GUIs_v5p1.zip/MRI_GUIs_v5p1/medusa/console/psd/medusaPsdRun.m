function psd = medusaPsdRun(psd)
% function psd = medusaPsdRun(psd)
%
% Runs a scan using the provided PSD by performing these steps:
% - Validate the pulse sequence (medusaPsdValidate)
% - Upload the pulse sequence data to the console (medusaPsdUpload)
% - Start the sequence, run the scan (medusaPsdStart)
% - Monitor for scan completion (medusaPsdMonitor)
% - Download the RF received data, if any (medusaPsdRxDownload)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% setup output fid
global MEDUSA
fid = MEDUSA.FID;

err_warn = medusaPsdValidate(psd);

fprintf(fid, 'MEDUSA: ----- PSD Run (ID# %1.0f) -----\n', psd.id);

if(err_warn(1) ~= 0)
	fprintf(fid, 'Error in PSD. Run cancelled.\n');
	return
end

medusaPsdUpload(psd);
fprintf(fid, 'MEDUSA: Starting Scan.\n');
psd = medusaPsdStart(psd);
medusaPsdMonitor(psd);
medusaPsdStop(psd);
psd = medusaPsdRxDownload(psd);

fprintf(fid, 'MEDUSA: Scan Complete.\n');
