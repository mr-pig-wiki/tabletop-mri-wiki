function dfilter = medusaRfRxFilterGen(taps,wc,mfactor,type)
% function dfilter = medusaRfRxFilterGen(taps,wc,mfactor,type)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% default parameters
if(~exist('taps','var')) taps = 50; end;
if(~exist('wc','var')) wc = 1/10; end;
if(~exist('mfactor','var')) mfactor = 1; end;
if(~exist('type','var')) type = 1; end;

% make filter
switch(type)
	case 1
		filter = fir1(taps-1,wc)*mfactor;
	case 2
		filter = fir2(taps-1,[0 wc 1.2*wc 1],[1 1 0 0],blackman(taps))*mfactor;
	otherwise
		filter = fir1(taps-1,wc)*mfactor;
end
% report
fprintf('medusaRfRxFilterGen: Taps=%1.0f, Wc=%1.2f, Mfactor=%1.2f, Type=%1.0f\n', taps, wc, mfactor, type);

% reformat filter to int16
dfilter = floor(filter*2^15);
fprintf('medusaRfRxFilterGen: Filter reaches %1.0f%% of integer bounds.\n', 100*max(abs(dfilter))/32767)
if((max(dfilter) > 32767) || (min(dfilter) < -32767))
	fprintf('medusaRfRxFilterGen: WARNING: Generated filter is clipped by 16-bit bounds!\n')
end

% reformat filter to int32
dfilter32 = round(filter*2^31);

% format output for C-language style array
fid = fopen('rcfcoeffs.h', 'w');
% write filter attributes
fprintf(fid,'// RF Rx RCF Filter\r\n');
fprintf(fid,'// Taps=%1.0f Wc=%1.2f Mfactor=%1.2f Type=%1.0f\r\n', taps, wc, mfactor, type);
% write filter length
fprintf(fid,'#define RCF_FILTER_LENGTH %d\r\n', length(filter));
% select number of columns
cols = 8;
% determine number of rows
rows = floor(length(filter)/cols);
% open array
fprintf(fid,'const long RcfFilter[] = {\r\n');
% print elements
for(row=0:rows-1)
	fprintf(fid,'%10d,\t', dfilter32(1+ ((row*cols):((row+1)*cols)-1)) );
    % finish line
    fprintf(fid,'\r\n');
end
% anything left
if(rows*cols < length(filter))
	fprintf(fid,'%10d,\t', dfilter32(((rows*cols)+1):end));
    fprintf(fid,'\r\n');
end
% close array
fprintf(fid,'};\r\n');
% close file
fclose(fid);


% do fft to see response
filtresp = (fftshift(fft(fftshift(filter))));
filtrespMag = abs(filtresp);
filtrespPhs = unwrap(angle(filtresp))*180/pi;
filtrespMagdB = 10*log(filtrespMag([2 2:end])); % skip first sample
f = ((0:length(filter)-1)/length(filter))-0.5;

% plot output
figure(1)
subplot(4,1,1)
plot(0:length(filter)-1,filter,'b.-'); grid on;
title(sprintf('Filter (wc=%1.2f, %d taps, type %d)', wc, taps, type));
axis([0 length(filter)-1 min(filter) max(filter)])

subplot(4,1,2)
plot(f,filtrespMag,'b.-'); grid on;
title('Filter response (lin)');
ylabel('Magn [lin]');
%axis([0,length(filtresp),-A,+A]);

subplot(4,1,3)
plot(f,filtrespPhs,'b.-'); grid on;
title('Filter response (Phase Degrees)');
ylabel('Phase [Deg]');
axis([min(f) max(f) min(filtrespPhs) max(filtrespPhs)]);

subplot(4,1,4)
plot(f,filtrespMagdB,'b.-'); grid on;
title('Filter response (dB)');
ylabel('Magn [dB]');
axis([min(f) max(f) filtrespMagdB(end) max(filtrespMagdB)]);

