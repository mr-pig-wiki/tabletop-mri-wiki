function medusaRfTxSetFreq(nodeid, freqHz)
%function medusaRfTxSetFreq(nodeid, freqHz)
% sets RF Tx output frequency immediately
%  - frequency value must be in Hertz
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA
concmd32(sock, nodeid, MEDUSA.CMD.DDSFREQ, freqHz);
