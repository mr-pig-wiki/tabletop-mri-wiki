function medusaVmodSetDirectGate(nodeid,channel,txgate,coilon,msynct)
% function medusaVmodSetDirectGate(nodeid,channel,txgate,coilon,[msynct])
%
% Loads digital gate data into phase module channel immediately
% txgate   - 0/1 indicating desired action of txgate signal
% coilon   - 0/1 indicating desired action of coil enable signal
% msynct   - 0/1 indicating whether MSYNC should gate the other signals
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global MEDUSA

if(~exist('msynct','var'))
	msynct = 0;
end

setbits = 0;
clrbits = 0;

% process coil-on
if(coilon)
	setbits = bitor(setbits, bitshift(1, 4+2+channel));
else
	clrbits = bitor(clrbits, bitshift(1, 4+2+channel));
end

% process tx gate
if(txgate)
	setbits = bitor(setbits, bitshift(1, 2+channel));
else
	clrbits = bitor(clrbits, bitshift(1, 2+channel));
end

% clear gate bits
medusaRegBitClr(nodeid, MEDUSA.REG.MAIN.GATE, clrbits);
% set gate bits
medusaRegBitSet(nodeid, MEDUSA.REG.MAIN.GATE, setbits);

if(msynct)
	% set MSYNC gating to enabled in conf register
	medusaRegBitSet(nodeid, MEDUSA.REG.MAIN.CONF, MEDUSA.REG.VMOD.CONF_MSYNC_GATE);
else
	% clear MSYNC gating to disabled in conf register
	medusaRegBitClr(nodeid, MEDUSA.REG.MAIN.CONF, MEDUSA.REG.VMOD.CONF_MSYNC_GATE);
end

% enable logic output-enable
medusaRegBitClr(nodeid, MEDUSA.REG.MAIN.GATE, MEDUSA.REG.VMOD.GATE_OUTDISABLE);
