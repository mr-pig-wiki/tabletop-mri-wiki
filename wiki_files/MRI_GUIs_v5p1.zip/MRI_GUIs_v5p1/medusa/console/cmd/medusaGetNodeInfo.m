function nodeinfo = medusaGetNodeInfo(nodeid)
% function medusaGetNodeInfo(nodeid)
%   Prints node information for the Medusa Controller at address [nodeid].
%   Also returns node information as array.
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock;
global MEDUSA

%nodeid = hex2dec('011000');
nodeid = bitand(nodeid,hex2dec('00FF0000'));
nodeid = bitor(nodeid,hex2dec('00001000'));

% issue command
nodeinfo = concmd32Read(sock, nodeid, MEDUSA.CMD.ID, []);
nodeinfo = reshape(nodeinfo,5,length(nodeinfo)/5);
nodeinfo = permute(nodeinfo, [2 1]);
% is now nodeinfo(nModule,attribute)
% attribute 1 = nodeid
% attribute 2 = devtype
% attribute 3 = features
% attribute 4 = version
% attribute 5 = buffersize

% print node info
fprintf('----- DEVICE LIST -----------------------------------------------\n');
for module = 1:size(nodeinfo,1)
	if(nodeinfo(module,1))
		switch(nodeinfo(module,2))
			case MEDUSA.ID.CONTROLLER
				devdesc = 'Medusa Controller';
			case MEDUSA.ID.RFMODULE
				devdesc = 'RF Module        ';
			case MEDUSA.ID.GRADIENTMODULE
				devdesc = 'Gradient Module  ';
			case MEDUSA.ID.VECTORMODULE
				devdesc = 'VectorMod Module ';
			case MEDUSA.ID.GRGEMODULE
				devdesc = 'Grad GE Module   ';
			case MEDUSA.ID.GRVRMODULE
				devdesc = 'GradVarian Module';
			otherwise
				devdesc = 'Unknown Module   ';
		end
		fprintf('%02d: NodeID=%06X: %s (Ver=%08X, Buf=%8X)\n', ...
			module, nodeinfo(module,1), devdesc, nodeinfo(module,4), nodeinfo(module,5));
	end
end
fprintf('-----------------------------------------------------------------\n');

% -- raw dump --
%fprintf('\n');
%fprintf('NodeID=%8X | DevT=%8X | Feat=%8X | Ver=%8X | Buf=%8X\n', nodeinfo );
% --------------
