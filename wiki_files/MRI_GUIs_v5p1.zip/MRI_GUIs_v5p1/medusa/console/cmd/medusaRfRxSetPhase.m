function medusaRfRxSetPhase(nodeid, phase)
% function medusaRfRxSetPhase(nodeid, phase)
% sets RF Rx LO phase immediately
%  - phase value is treated as normalized on 0 to 1 for 0-360 degrees phase shift
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% phase value is unsigned 16-bit
phase = phase * 65536;

global sock
global MEDUSA
concmd(sock, nodeid, MEDUSA.CMD.DDRPHASE, [phase]);
