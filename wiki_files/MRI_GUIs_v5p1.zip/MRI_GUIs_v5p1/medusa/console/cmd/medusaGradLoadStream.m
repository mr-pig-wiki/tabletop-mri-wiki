function time = medusaGradLoadStream(nodeid,Gx,Gy,Gz,Ga,gate)
%function time = medusaGradLoadStream(nodeid,Gx,Gy,Gz,Ga,gate)
% Gx,Gy,Gz,Ga,gate are expected in row vectors
% 'Ga/SSI' may be 0 if no extra channel is needed
% 'gate' may be 0 if no extended gating needed
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

fid = MEDUSA.FID;

% mask subchannel bits of NODEID
nodeid = bitand(nodeid, hex2dec('FFFFFF00'));

% fill Ga data if user didn't provide
if(~exist('Ga','var'))
	Ga = 0;
end
if(Ga == 0)
	Ga = zeros(1,length(Gx));
end
% fill gating data if user didn't provide
if(~exist('gate','var'))
	gate = 0;
end
if(gate == 0)
	% no gating signal specified - we can do whatever we want!
	%gate = zeros(1,length(Gx));
	% make gate signal to flash status LEDs on DAC modules
	gate = hex2dec('F000')*[ ones(1,floor(length(Gx)/2)) zeros(1,ceil(length(Gx)/2)) ];
	%gate = hex2dec('0000')*[ ones(1,floor(length(Gx)/2)) zeros(1,ceil(length(Gx)/2)) ];
end

% make sure inputs are row vectors
Gx = reshape(Gx,1,length(Gx));
Gy = reshape(Gy,1,length(Gy));
Gz = reshape(Gz,1,length(Gz));
Ga = reshape(Ga,1,length(Ga));
gate = reshape(gate,1,length(gate));

% prep gradient data interleave format and scaling
grdata = [Gx;Gy;Gz;Ga];
if( max(max(abs(grdata))) <= 1.0 )
	% assume input normalized to +/-1.0
	% grdata = (32767*grdata)+32768;	% unsigned 16-bit coding used for old gradient boards - do not use
	grdata = (32767*grdata)+65536;		% universal signed 16-bit coding
else
	% assume input normalized to signed 16-bit value
	% grdata = (1*grdata)+32768;
	grdata = (1*grdata)+65536;
end
% clamp grdata to 16bit range
grdata = round(grdata);
grdata = bitand(grdata, 65535);
% rescale gating if needed
if( max(max(abs(gate))) <= 1.0 )
	% assume input normalized to +/-1.0 like gradient waveforms
	% discourage this encoding method
	gate = (32767*gate)+65536;
	fprintf(fid,'\n\n##### WARNING #####\n');
	fprintf(fid,'MedusaGradLoadStream: Gate is coded with +/-1.0 normalization. Please use unsigned 16-bit coding (integers 0-65535)\n');
else
	% assume input normalized to unsigned 16-bit value
	if( min(min(gate)) < 0 )
		fprintf(fid,'\n\n##### WARNING #####\n');
		fprintf(fid,'MedusaGradLoadStream: Gate coding has negative values! Please use unsigned 16-bit coding (integers 0-65535)\n');
	end
	gate = (1*gate)+65536;
end
gate = round(gate);
gate = bitand(gate, 65535);
% add gating and reshape
grdata = [grdata; gate];
grdata = reshape(grdata,1,size(grdata,1)*size(grdata,2));

% load gradient data
tic;
% which is correct?
concmd(sock, nodeid+MEDUSA.SUB.GRAD.MEM_CH, MEDUSA.CMD.RAWDATA, grdata);
%concmd(sock, nodeid+MEDUSA.SUB.GRAD.CH, MEDUSA.CMD.RAWDATA, grdata);
time = toc;
