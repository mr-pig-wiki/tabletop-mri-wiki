function medusaPgaGainSet(nodeid, addr, gain)
% function medusaPgaGainSet(nodeid, addr, gain)
%  addr    = device address of PGA submodule
%  gain    = 0=off
%			 1-16 selects gain in 3dB steps over range -10dB to +35dB
%                   (i.e. 1=-10dB, 2=-7dB, 3=-4dB ... 15=+35dB)
%			 17=manual gain (by rotary switch)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global MEDUSA
global sock

%cmdlinkcmd(cmdlinksock, nodeid, 'p', ['g' addr gain]);
concmd32(sock, nodeid, MEDUSA.CMD.PGA, [addr gain]);
