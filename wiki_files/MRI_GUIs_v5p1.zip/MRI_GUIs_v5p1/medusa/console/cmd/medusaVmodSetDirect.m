function medudaVmodSetDirect(nodeid,channel,dcos,dsin)
% function medudaVmodSetDirect(nodeid,channel,dcos,dsin)
%
% Directly write VM DACs for one channel (effective immediately)
% nodeid - module/device node ID as reported upon connection
% dcos   - cosine dac value (-1 to 1)
% dsin   - sine dac value (-1 to 1)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global MEDUSA

%offset = 0.002308 + -0.000307*i;
offset = 0;

icos = 32768+round(32767*(dcos+real(offset)));
isin = 32768+round(32767*(dsin+imag(offset)));
medusaRegWrite(nodeid, MEDUSA.REG.VMOD.DAC0I+channel*2, icos);
medusaRegWrite(nodeid, MEDUSA.REG.VMOD.DAC0Q+channel*2, isin);
%pmcmd32(nodeid+channel,MEDUSA.CMD.GRADDIRWRITE,[channel*2+0 icos]);
%pmcmd32(nodeid+channel,MEDUSA.CMD.GRADDIRWRITE,[channel*2+1 isin]);
