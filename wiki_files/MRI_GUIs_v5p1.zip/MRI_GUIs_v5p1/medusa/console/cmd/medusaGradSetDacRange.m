function medusaGradSetDacRange(nodeid, range)
%function medusaGradSetDacRange(nodeid, range)
% supported ranges =  2.5 ==> +/-2.5V
%                     5.0 ==> +/-5V
%          (default) 10.0 ==> +/-10V
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% select new range word
dacrange = 0;
if(range == 2.5)
	dacrange = hex2dec('C000');
end
if(range == 5.0)
	dacrange = hex2dec('A000');
end
if(range == 10.0)
	dacrange = hex2dec('B000');
end

if(dacrange == 0)
	fprintf('WARNING: Gradient DAC Range of +/-%1.1fV is unsupported\n', range);
end

% clear previous range setting
medusaRegBitClr(nodeid, MEDUSA.REG.MAIN.CONF, hex2dec('F000'));
% apply new range
medusaRegBitSet(nodeid, MEDUSA.REG.MAIN.CONF, dacrange);
