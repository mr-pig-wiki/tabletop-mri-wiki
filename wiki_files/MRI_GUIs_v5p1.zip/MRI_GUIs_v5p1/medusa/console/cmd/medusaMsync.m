function medusaMsync(nodeid)
% function medusaMsync(nodeid)
%   Triggers an Msync immediately on selected controller
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% do MSYNC
concmd(sock, nodeid, MEDUSA.CMD.MSYNC, [0]);
%medusaRegBitSet(hex2dec('11000'), hex2dec('30'), hex2dec('2000'));
%medusaRegBitSet(hex2dec('11000'), hex2dec('30'), hex2dec('0002'));
