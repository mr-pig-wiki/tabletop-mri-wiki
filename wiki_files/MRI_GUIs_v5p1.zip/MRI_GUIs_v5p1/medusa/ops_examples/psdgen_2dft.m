
fprintf('---------- 2DFT PSD Generator ----------\n')

psd.id = 102;
psd.fid = 0;

% initialize console parameters
% setup NodeID addresses (this selects which hardware is involved in this PSD)
psd.ctrl.nodeid = medusaNode(1);	% Medusa Controller #1
psd.rfrx.nodeid = medusaNode(1,0);	% Medusa RF module for Rx (module address 0)
psd.rftx.nodeid = medusaNode(1,0);	% Medusa RF module for Tx (module address 0)
psd.grad.nodeid = medusaNode(1,8);	% Medusa Gradient module  (module address 8)

% setup sample rates
%psd.rfrx.smpclk = 500e3/8;	% set Rx sample rate in Hz (must be 500kHz/(2^N))
psd.rfrx.smpclk = 500e3/16;	% set Rx sample rate in Hz (must be 500kHz/(2^N))
%psd.rfrx.smpclk = 500e3/32;	% set Rx sample rate in Hz (must be 500kHz/(2^N))
psd.rftx.smpclk = psd.rfrx.smpclk;
psd.grad.smpclk = psd.rfrx.smpclk;
psd.ctrl.smpclk = psd.rfrx.smpclk;
% switch gradients and controller back to 250KHz to make GP3 happy
psd.grad.smpclk = 500e3/2;
psd.ctrl.smpclk = psd.grad.smpclk;

% set RF receiver gain
psd.rfrx.gain = 4;
% set RF transmitter gain
psd.rftx.gain = 0;

% setup frequencies
freq = 63.858550e6 - 1900;
psd.rfrx.freq = freq;	% carrier frequency in Hz
psd.rftx.freq = freq;	% carrier frequency in Hz


% magnet parameters/constants
% 4G/cm on GE: X = 22792, Y = -23110, Z = 22832
gauss_cm = ([22792 23110 22832]/4)/32767;
gamma = 4.25781e3;	% hz/gauss
% constants
%rftx_90_area = 50e-6;	% rf units * seconds
rftx_90_area = 1.0*135e-6;	% rf units * seconds
%rftx_90_area = 900e-6;	% rf units * seconds
G_max = 200;		% Amps full-scale

% initialize pulse sequence parameters
FOV = [10 10 1];
Nro = 256;
%Npe = 220;
Npe = 50;

Ntr = Npe;
tss = 4e-3;					% slice select time
tbwss = 4;					% slice select TBW
tref = tss/2;				% excite reference time
%tr = 750e-3;					% repeat time
tr = 50e-3;					% repeat time
tr = 1000e-3;					% repeat time
tro = Nro/psd.rfrx.smpclk;	% readout time (length)
tpe = tro/8;				% phase encode time (length)
te = 0e-3+tss+tro/2;	% echo time

groArea = (psd.grad.smpclk/(gamma*FOV(1)))*gauss_cm(1);	% readout area
groArea = 145;				% readout area
gpeArea = groArea;			% phase encode select area
gssArea = tss * gauss_cm(3) * (tbwss/tss)/(gamma*FOV(3));
gssArea = 40;				% slice select area
gr_ramp = 60;				% gradient trapezoid ramps (# samples to ramp)

% ------------- slice select ------------
%gss_ampl = gauss_cm(3) * (tbw/tslice)/(gamma*FOV(3));
%Gs = 10000;			% hz/meter/amp
%G_max = 200;			% Amps full-scale
%Gz_slice = (tbw/tslice)/(Gs*th_slice)/G_max;

% make RF
% make single RF pulse
psd.rftx.data = psd.rftx.smpclk*rftx_90_area*wsinc(tbwss, tss*psd.rftx.smpclk);
%psd.rftx.data = psd.rftx.smpclk*rftx_90_area*wsinc(tbw, tslice*psd.rftx.smpclk)+(1/4095);
%psd.rftx.data = rftx_90_area*ones(1,tss*psd.rftx.smpclk);  % hard pulse
%psd.rftx.data = 0.1 * ones(1,tss*psd.rftx.smpclk);  % hard pulse

% make gradients
% generate the pulse sequence pieces
% readout gradient
gro = [];
gro = [gro, zeros(1,round((tref+te-((tro/2)+(tpe)))*psd.grad.smpclk) )];	% dead time
gro = [gro, grLobeTrap(-groArea/2, gr_ramp, tpe, psd.grad.smpclk)];			% windup
gro = [gro, grLobeTrap(+groArea,   gr_ramp, tro, psd.grad.smpclk)];			% readout
gro = [gro, grLobeTrap(-groArea/2, gr_ramp, tpe, psd.grad.smpclk)];			% rewind
gro = [gro, 0 0 0 0];														% terminate with zero
% phase encode gradient
gpe = [];
gpe = [gpe, zeros(1,round((tref+te-((tro/2)+(tpe)))*psd.grad.smpclk) )];	% dead time
gpe = [gpe, grLobeTrap(-gpeArea/2, gr_ramp, tpe, psd.grad.smpclk)];			% windup
gpe = [gpe, grLobeTrap(+0,         gr_ramp, tro, psd.grad.smpclk)];			% readout
gpe = [gpe, grLobeTrap(+gpeArea/2, gr_ramp, tpe, psd.grad.smpclk)];			% rewind
gpe = [gpe, 0 0 0 0];														% terminate with zero
% snap phase encode to DAC units
%gpe = round( gpe*32767*(2/(Ntr-1)) ) / (32767*(2/(Ntr-1)));
dacref = 32767;
maxgpe1 = max(( gpe*dacref*(2/(Ntr-1)) ));
gpe = round( gpe*dacref*(2/(Ntr-1)) ) / (dacref*(2/(Ntr-1)));
maxgpe2 = max(( gpe*dacref*(2/(Ntr-1)) ));
%fprintf('GPE before/after: %1.3f / %1.3f\n', maxgpe1, maxgpe2);

% slice select gradient
gss = [];
gss = [gss, grLobeTrap(+gssArea,   gr_ramp, tss,   psd.grad.smpclk)];	% windup
gss = [gss, grLobeTrap(-gssArea/2, gr_ramp, tss/2, psd.grad.smpclk)];	% rewind
gss = [gss, 0 0 0 0];														% terminate with zero

% extend to longest waveform
gr_full_len = max([length(gro) length(gpe) length(gss)]);
if(length(gro) < gr_full_len) gro = [gro 0*ones(1,gr_full_len-length(gro))]; end
if(length(gpe) < gr_full_len) gpe = [gpe 0*ones(1,gr_full_len-length(gpe))]; end
if(length(gss) < gr_full_len) gss = [gss 0*ones(1,gr_full_len-length(gss))]; end

% make rf pulse array
psd.rftx.data = [psd.rftx.data, 0];						% force terminate with zero
psd.rftx.data = psd.rftx.data' * ones(1,Ntr);
psd.rftx.data = reshape(psd.rftx.data, 1, size(psd.rftx.data,1)*Ntr);
%psd.rftx.data = psd.rftx.data+2/4095;
% make gradient array
gx = gro' * [ones(1,Ntr)];
gy = gpe' * [-1:2/(Ntr-1):1];
gz = gss' * [ones(1,Ntr)];
% add ssi
ssi = 0*gro; ssi(1) = hex2dec('1000')/32767;	% create start-of-sequence flag
ssi = ssi' * [ones(1,Ntr)];
% add gating
gate = 0*gro;
gate = gate' * [ones(1,Ntr)];
%figure(1); plot(gy);
% re-orient
gx = reshape(gx, 1, size(gx,1)*size(gx,2));
gy = reshape(gy, 1, size(gy,1)*size(gy,2));
gz = reshape(gz, 1, size(gz,1)*size(gz,2));
ssi = reshape(ssi, 1, size(ssi,1)*size(ssi,2));
gate = reshape(gate, 1, size(gate,1)*size(gate,2));
% combine
psd.grad.data = [gx; gy; gz; ssi; gate];
% rotate plane
%ra = [0 0 0];
%psd.grad.data(:,1:3) = Rxyz(psd.grad.data(:,1:3),ra,'degrees');

% setup TR parameters
% controller
psd.ctrl.trlength = tr*psd.ctrl.smpclk;
psd.ctrl.ntrs = Ntr;
% receiver
psd.rfrx.start = round( (tref+te-(tro/2))*psd.rfrx.smpclk );
%psd.rfrx.start = 200;
psd.rfrx.length = 1*Nro;
psd.rfrx.data = zeros(1,Ntr * psd.rfrx.length);
% transmitter
psd.rftx.start = 1;
psd.rftx.length = length(psd.rftx.data)/Ntr;
% gradients
psd.grad.start = 1;
psd.grad.length = length(psd.grad.data)/Ntr;


psd.param.Nro = Nro;
psd.param.Npe = Npe;
psd.param.tr = tr;
psd.param.te = te;
psd.param.tpe = tpe;
psd.param.tro = tro;


psdPrintStats(psd);
if(0)
% PSD stats
fprintf('PSD ID#  : %1.0f\n', psd.id);
fprintf('Nro x Npe: %1.0f x %1.0f\n', Nro, Npe);
fprintf('Scan time: %8.2f sec\n', Ntr*tr);
fprintf('RFTx data: %8.0f samples (%4.0f Kb)\n', size(psd.rftx.data,2), 2*2*size(psd.rftx.data,2)/1024 );
fprintf('RFRx data: %8.0f samples (%4.0f Kb)\n', size(psd.rfrx.data,2), 2*2*size(psd.rfrx.data,2)/1024 );
fprintf('Grad data: %8.0f samples (%4.0f Kb)\n', length(psd.grad.data), 2*5*length(psd.grad.data)/1024 );
fprintf('----------------------------------------\n')
% PSD info
fprintf('TR=  %7.2fms  (%7.0f samples)\n', tr*1000,  tr*psd.rfrx.smpclk );
fprintf('TE=  %7.2fms  (%7.0f samples)\n', te*1000,  te*psd.rfrx.smpclk );
fprintf('Tro= %7.2fms  (%7.0f samples)\n', tro*1000, tro*psd.rfrx.smpclk);
fprintf('Tpe= %7.2fms  (%7.0f samples)\n', tpe*1000, tpe*psd.rfrx.smpclk);
fprintf('----------------------------------------\n')
% print gradient stats
fprintf('Gx Level: %6.2f Amps (%5.3f full scale)\n', max(abs(gx*G_max)), max(abs(gx)))
fprintf('Gy Level: %6.2f Amps (%5.3f full scale)\n', max(abs(gy*G_max)), max(abs(gy)))
fprintf('Gz Level: %6.2f Amps (%5.3f full scale)\n', max(abs(gz*G_max)), max(abs(gz)))
fprintf('----------------------------------------\n')
end


% plot the sequence
fprintf('Plotting...\n')
%psdPlotRG(100,psd);
%psdPlotMD(100,psd,0,-0.1);
psdPlotOV(100,psd,0,-0.1);
fprintf('----------------------------------------\n')

