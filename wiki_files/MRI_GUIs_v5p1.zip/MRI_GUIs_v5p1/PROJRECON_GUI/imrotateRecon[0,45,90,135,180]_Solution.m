% This code loads readout data for projections at angles from 0 to 180 (each column holds data for
% projection at a new angle), and reconstructs it using Erica Mason & Jeff
% Stout's "Imrotate Reconstruction" technique:

% Load readout data:
load('ideal_readout.mat') % This is the ideal readout data

% Take FFT just down the columns: 
imdom_projcol=fftshift(fft(fftshift(readout,1),[],1),1); 

% Define a vector of the angles at which the data is projected:
deg = [0,45,90,135,180];

% Loop through all angles and back project each data indiually so you can
% see the 2D representation of the projection for each angle:
for j=1:length(imdom_projcol(1,:))
    individ_backprojections(:,:,j)=ones(numel(imdom_projcol(:,1)),numel(imdom_projcol(:,2)))*diag(imdom_projcol(:,j));
    figure, imagesc(abs(individ_backprojections(:,:,j))), axis square, axis tight, xlabel('FOV [pixels]'), colormap gray;
end

% angular different between two adjacent projections:
dtheta = deg(2)-deg(1);

% Create empty matrix for the image domain 2D reconstruction:
imdom_projrecon = zeros(numel(imdom_projcol(:,1)),numel(imdom_projcol(:,2)),numel(deg));

% Back project 1st projection (0 degree projection):
imdom_projrecon(:,:,1)=ones(numel(imdom_projcol(:,1)),numel(imdom_projcol(:,2)))*diag(imdom_projcol(:,1));
figure, imagesc(abs(imdom_projrecon(:,:,1))), axis square, colormap gray;

% Rotate first back projection by angular difference, crop it to original
% matrix size, back project next angle's projection onto the rotated and
% cropped image. Loop through all angles to repeat. Plot each cumulative
% iteration:
for a = 2:numel(deg)
    projrot = imrotate(imdom_projrecon(:,:,a-1),dtheta);
    cropamt = round((length(projrot(:,1)) - length(imdom_projrecon(:,:,1)))/2);
    projrotcrop = projrot(cropamt:cropamt+length(imdom_projrecon(:,:,1))-1,cropamt:cropamt+length(imdom_projrecon(:,:,1))-1);

    imdom_projrecon(:,:,a) = projrotcrop*diag(imdom_projcol(:,a));
    figure, imagesc(abs(imdom_projrecon(:,:,a))), axis square, colormap gray;
end
