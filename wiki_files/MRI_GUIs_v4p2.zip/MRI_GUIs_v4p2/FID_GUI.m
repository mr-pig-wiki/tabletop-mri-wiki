function varargout = FID_GUI(varargin)
%
%  VERSION NOTES
%  V4.0 RELEASED FEBRUARY, 2014 BY JASON STOCKMANN
%  EMAIL JAYSTOCK@NMR.MGH.HARVARD.EDU WITH QUESTIONS
%
%  FOR RELEASE NOTES AND FEATURES/BUG FIXES, PLEASE SEE:
%  https://gate.nmr.mgh.harvard.edu/wiki/Tabletop_MRI/index.php/Hardware:SourceCode
% 
clear psd
% Edit the above text to modify the response to help FID_GUI

% Last Modified by GUIDE v2.5 07-May-2013 16:51:18

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @FID_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @FID_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

global psd
% psd.debug_mode = 0;
% psd.f0 = 8.115e6;
% psd.tr = 1000;
% psd.tro = 50;
% psd.num_reps = 10;


% --- Executes just before FID_GUI is made visible.
function FID_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to FID_GUI (see VARARGIN)
global psd

% Choose default command line output for FID_GUI
handles.output = hObject;


% shim scaling factor from GPA output signal to mA
psd.shim_scale_factor = 10500;

% set frequency to value saved in text file by FID_GUI
psd.f0_setting_path = fileparts(which('FID_GUI.m'));


fid = fopen([psd.f0_setting_path,'\f0_setting.mat']);
if fid == -1,
    psd.f0 = 8.15;  % choose some arbitrary value in case f0_setting file doesn't exist
    save([psd.f0_setting_path,'\f0_setting.mat'],'f0')
    disp(['Couldn''t find f0_setting.mat... Defaulting frequency to ',num2str(psd.f0)])
else
    load([psd.f0_setting_path,'\f0_setting.mat'])
    psd.f0 = f0;
    set(handles.f0,'String',num2str(psd.f0));
    disp(['Frequency of last scan was ',num2str(f0)])
end

fclose(fid)


% Update handles structure
guidata(hObject, handles);

% This sets up the initial plot - only do when we are invisible
% so window can get raised using FID_GUI.
if strcmp(get(hObject,'Visible'),'off')
  %  plot(rand(5));
end

% UIWAIT makes FID_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = FID_GUI_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% 
% % --- Executes on button press in pushbutton1.
% function pushbutton1_Callback(hObject, eventdata, handles)
% % hObject    handle to pushbutton1 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% axes(handles.axes1);
% cla;
% 
% popup_sel_index = get(handles.popupmenu1, 'Value');
% switch popup_sel_index
%     case 1
%         plot(rand(5));
%     case 2
%         plot(sin(1:0.01:25.99));
%     case 3
%         bar(1:.5:10);
%     case 4
%         plot(membrane);
%     case 5
%         surf(peaks);
% end


% % --------------------------------------------------------------------
% function FileMenu_Callback(hObject, eventdata, handles)
% % hObject    handle to FileMenu (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% 
% % --------------------------------------------------------------------
% function OpenMenuItem_Callback(hObject, eventdata, handles)
% % hObject    handle to OpenMenuItem (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% file = uigetfile('*.fig');
% if ~isequal(file, 0)
%     open(file);
% end
% 
% % --------------------------------------------------------------------
% function PrintMenuItem_Callback(hObject, eventdata, handles)
% % hObject    handle to PrintMenuItem (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% printdlg(handles.figure1)
% 
% % --------------------------------------------------------------------
% function CloseMenuItem_Callback(hObject, eventdata, handles)
% % hObject    handle to CloseMenuItem (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% selection = questdlg(['Close ' get(handles.figure1,'Name') '?'],...
%                      ['Close ' get(handles.figure1,'Name') '...'],...
%                      'Yes','No','Yes');
% if strcmp(selection,'No')
%     return;
% end
% 
% delete(handles.figure1)


% % --- Executes on selection change in popupmenu1.
% function popupmenu1_Callback(hObject, eventdata, handles)
% % hObject    handle to popupmenu1 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% % Hints: contents = get(hObject,'String') returns popupmenu1 contents as cell array
% %        contents{get(hObject,'Value')} returns selected item from popupmenu1
% 
% 
% % --- Executes during object creation, after setting all properties.
% function popupmenu1_CreateFcn(hObject, eventdata, handles)
% % hObject    handle to popupmenu1 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    empty - handles not created until after all CreateFcns called
% 
% % Hint: popupmenu controls usually have a white background on Windows.
% %       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%      set(hObject,'BackgroundColor','white');
% end
% 
% set(hObject, 'String', {'plot(rand(5))', 'plot(sin(1:0.01:25))', 'bar(1:.5:10)', 'plot(membrane)', 'surf(peaks)'});
% 


%%%%%%  debug box has been removed from the GUI -- JPS 1/16/2013 
% 
% % --- Executes on selection change in debug_listbox.
% function debug_listbox_Callback(hObject, eventdata, handles)
% global psd
% % hObject    handle to debug_listbox (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% % Hints: contents = cellstr(get(hObject,'String')) returns debug_listbox contents as cell array
% %        contents{get(hObject,'Value')} returns selected item from debug_listbox
%    a = get(handles.debug_listbox,'Value')
%   % if strcmp(a, 'Debug mode OFF'), psd.debug_mode = 0; elseif strcmp(a,'Debug mode ON'), psd.debug_mode = 1; end
% if a == 1, psd.debug_mode = 0;  elseif a == 2, psd.debug_mode = 1; end
% 
% 
% % --- Executes during object creation, after setting all properties.
% function debug_listbox_CreateFcn(hObject, eventdata, handles)
% % hObject    handle to debug_listbox (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    empty - handles not created until after all CreateFcns called
% 
% % Hint: listbox controls usually have a white background on Windows.
% %       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end



function f0_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to f0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of f0 as text
%        str2double(get(hObject,'String')) returns contents of f0 as a double

psd.f0 = str2num(get(handles.f0,'String'));  f0 = psd.f0;

psd.fid = 0;
psd.ctrl.nodeid = medusaNode(1);	% Medusa Controller #1
psd.rfrx.nodeid = medusaNode(1,0);	% Medusa RF module for Rx (module address 0)
psd.rftx.nodeid = medusaNode(1,0);	% Medusa RF module for Tx (module address 0)

psd.grad.nodeid = hex2dec('010800');	% Medusa Gradient module
medusaConnect
medusaReset(psd.ctrl.nodeid)
concmd32(sock, hex2dec('011000'), hex2dec('42'), hex2dec('4'));

%psd.f0_setting_path = regexprep(temp_path,'.\gui','')
%f0_setting = fullfile(psd.f0_setting_path,'.\f0_setting.mat')

save([psd.f0_setting_path,'\f0_setting.mat'],'f0')



% --- Executes during object creation, after setting all properties.
function f0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to f0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tr_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to tr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tr as text
%        str2double(get(hObject,'String')) returns contents of tr as a double
psd.tr = str2num(get(handles.tr,'String'))



% --- Executes during object creation, after setting all properties.
function tr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end






function tro_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to tro (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tro as text
%        str2double(get(hObject,'String')) returns contents of tro as a double
psd.tro = str2num(get(handles.tro,'String'))


% --- Executes during object creation, after setting all properties.
function tro_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tro (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function num_reps_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to num_reps (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of num_reps as text
%        str2double(get(hObject,'String')) returns contents of num_reps as a double
psd.num_reps = str2num(get(handles.num_reps,'String'))
if psd.num_reps < 1, psd.num_reps = 1; set(handles.num_reps,'String',1); end

% --- Executes during object creation, after setting all properties.
function num_reps_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num_reps (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function num_ave_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to num_ave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of num_ave as text
%        str2double(get(hObject,'String')) returns contents of num_ave as a double
psd.num_ave = str2num(get(handles.num_ave,'String'))
if psd.num_ave < 1, psd.num_ave = 1; set(handles.num_ave,'String',1); end

% --- Executes during object creation, after setting all properties.
function num_ave_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num_ave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in toggle_stop_button.
function toggle_stop_button_Callback(hObject, eventdata, handles)
% hObject    handle to toggle_stop_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of toggle_stop_button





% --- Executes on slider movement.
function x_shim_slider_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to x_shim_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global psd
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
psd.shims_mA(1) = get(handles.x_shim_slider,'Value');
set(handles.x_shim_text,'String',num2str(round(psd.shims_mA(1))));
psd.shims(1) = psd.shims(1)/psd.shim_scale_factor;

% --- Executes during object creation, after setting all properties.
function x_shim_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to x_shim_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function y_shim_slider_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to y_shim_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
psd.shims_mA(2) = get(handles.y_shim_slider,'Value');
set(handles.y_shim_text,'String',num2str(round(psd.shims_mA(2))));
psd.shims(2) = psd.shims(2)/psd.shim_scale_factor;


% --- Executes during object creation, after setting all properties.
function y_shim_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to y_shim_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function z_shim_slider_Callback(hObject, eventdata, handles)
% hObject    handle to z_shim_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global psd
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
psd.shims_mA(3) = get(handles.z_shim_slider,'Value');
set(handles.z_shim_text,'String',num2str(round(psd.shims_mA(3))));
psd.shims(3) = psd.shims(3)/psd.shim_scale_factor;

% --- Executes during object creation, after setting all properties.
function z_shim_slider_CreateFcn(hObject, eventdata, handles)
global psd
% hObject    handle to z_shim_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in auto_shim_check_box.
function auto_shim_check_box_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to auto_shim_check_box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if (get(handles.auto_shim_check_box,'Value') == get(handles.auto_shim_check_box,'Max'))
    psd.auto_shim = 1;
else
    psd.auto_shim = 0;

end


% --- Executes on button press in flip_angle_cal_check_box.
function flip_angle_cal_check_box_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to flip_angle_cal_check_box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of flip_angle_cal_check_box
if (get(handles.flip_angle_cal_check_box,'Value') == get(handles.flip_angle_cal_check_box,'Max'))
    psd.flip_angle_cal = 1;
else
    psd.flip_angle_cal = 0;

end


function rftx_amp_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to rftx_amp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of rftx_amp as text
%        str2double(get(hObject,'String')) returns contents of rftx_amp as a double
psd.rftx_amp = str2num(get(handles.rftx_amp,'String'))


% --- Executes during object creation, after setting all properties.
function rftx_amp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rftx_amp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function file_path_string_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to file_path_string (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of file_path_string as text
%        str2double(get(hObject,'String')) returns contents of file_path_string as a double


% --- Executes during object creation, after setting all properties.
function file_path_string_CreateFcn(hObject, eventdata, handles)
% hObject    handle to file_path_string (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in save_button.
function save_button_Callback(hObject, eventdata, handles)
global psd
global FID
% hObject    handle to save_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
readout = FID.data;
time = FID.time.';
spec = FID.spec;
freq_axis = FID.freq_axis.';
readout_ave = FID.data_ave.';

%output = [readout time spec freq_axis];

% browse to folder where shim settings are saved

% browse to folder where shim settings are saved
temp_path = get(handles.file_path_string,'String');

if strcmp(temp_path(end),'\') == 1
     set(handles.system_status,'ForegroundColor',[1 0 0])
     set(handles.system_status,'String','PLEASE APPEND OUTPUT FILE NAME TO END OF SAVE PATH')
else
    save([get(handles.file_path_string,'String')],'readout','time','readout_ave','psd')
    set(handles.system_status,'ForegroundColor',[0 1 0])
    set(handles.system_status,'String','OUTPUT DATA SAVED')
end


% --- Executes on button press in auto_scale_check_box.
function auto_scale_check_box_Callback(hObject, eventdata, handles)
% hObject    handle to auto_scale_check_box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of auto_scale_check_box
global psd



% --- Executes on button press in zero_shims.
function zero_shims_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to zero_shims (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
psd.shims = [0 0 0];
set(handles.x_shim_slider,'Value',psd.shim_scale_factor*psd.shims(1));
set(handles.y_shim_slider,'Value',psd.shim_scale_factor*psd.shims(2));
set(handles.z_shim_slider,'Value',psd.shim_scale_factor*psd.shims(3));

psd.shims_mA = round(psd.shims.*psd.shim_scale_factor);
 set(handles.x_shim_text,'String',num2str(psd.shims_mA(1)));
 set(handles.y_shim_text,'String',num2str(psd.shims_mA(2)));
 set(handles.z_shim_text,'String',num2str(psd.shims_mA(3)));


function RX_gain_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to RX_gain (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of RX_gain as text
%        str2double(get(hObject,'String')) returns contents of RX_gain as a double
psd.rfrx.gain = str2num(get(handles.RX_gain,'String'));
psd.rfrx.gain

set(handles.system_status,'ForegroundColor',[0 1 0]);
set(handles.system_status,'String','SYSTEM STATUS: NORMAL');


if psd.rfrx.gain  < -9, psd.rfrx.gain = -9; set(handles.RX_gain,'String',num2str(psd.rfrx.gain)); 
  set(handles.system_status,'ForegroundColor',[1 0 0])
  set(handles.system_status,'String','ERROR: RECEIVE GAIN MUST BE BETWEEN -9 and +6 DB')
end
if psd.rfrx.gain > 6, psd.rfrx.gain = 6; set(handles.RX_gain,'String',num2str(psd.rfrx.gain));
  set(handles.system_status,'ForegroundColor',[1 0 0])
  set(handles.system_status,'String','ERROR: RECEIVE GAIN MUST BE BETWEEN -9 and +6 DB')
end

% --- Executes during object creation, after setting all properties.
function RX_gain_CreateFcn(hObject, eventdata, handles)
% hObject    handle to RX_gain (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in load_shims.
function load_shims_Callback(hObject, eventdata, handles)
% hObject    handle to load_shims (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global psd
%cd('C:\Users\wald2\Dropbox\MIT_lab_6.02M\MRI Lab\medusa\matlab');

%load shims.mat
shim_settings_path = fileparts(mfilename('fullpath'));
% temp_path = fileparts(which('SE_PROJ_GUI.m'))
%shim_settings_path = regexprep(temp_path,'.\gui','')
shim_settings = fullfile(shim_settings_path, 'shims.mat');

load(shim_settings);


psd.shims = shims;

psd.shims_mA = round(psd.shims.*psd.shim_scale_factor);

set(handles.x_shim_slider,'Value',psd.shims_mA(1));
set(handles.y_shim_slider,'Value',psd.shims_mA(2));
set(handles.z_shim_slider,'Value',psd.shims_mA(3));


 set(handles.x_shim_text,'String',num2str(psd.shims_mA(1)));
 set(handles.y_shim_text,'String',num2str(psd.shims_mA(2)));
 set(handles.z_shim_text,'String',num2str(psd.shims_mA(3)));
 


function x_shim_text_Callback(hObject, eventdata, handles)
global psd;
% hObject    handle to x_shim_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of x_shim_text as text
%        str2double(get(hObject,'String')) returns contents of x_shim_text as a double
%psd.shims(1) = str2num(get(handles.x_shim_text, 'String'));
%set(handles.x_shim_slider, 'Value', psd.shims(1));
psd.shims_mA(1) = str2num(get(handles.x_shim_text,'String'));
psd.shims(1) = psd.shims_mA(1)/psd.shim_scale_factor;
set(handles.x_shim_slider,'Value',psd.shims_mA(1));



function y_shim_text_Callback(hObject, eventdata, handles)
global psd;
% hObject    handle to y_shim_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of y_shim_text as text
%        str2double(get(hObject,'String')) returns contents of y_shim_text as a double
%psd.shims(2) = str2num(get(handles.y_shim_text, 'String'));
%set(handles.y_shim_slider, 'Value', psd.shims(2));

psd.shims_mA(2) = str2num(get(handles.y_shim_text,'String'));
psd.shims(2) = psd.shims_mA(2)/psd.shim_scale_factor;
set(handles.y_shim_slider,'Value',psd.shims_mA(2));


function z_shim_text_Callback(hObject, eventdata, handles)
global psd;
% hObject    handle to z_shim_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of z_shim_text as text
%        str2double(get(hObject,'String')) returns contents of z_shim_text as a double
%psd.shims(3) = str2num(get(handles.z_shim_text, 'String'));
%set(handles.z_shim_slider, 'Value', psd.shims(3));

psd.shims_mA(3) = str2num(get(handles.z_shim_text,'String'));
psd.shims(3) = psd.shims_mA(3)/psd.shim_scale_factor;
set(handles.z_shim_slider,'Value',psd.shims_mA(3));




% --- Executes on button press in save_shim_settings.
function save_shim_settings_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to save_shim_settings (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%cd('C:\Users\wald2\Dropbox\MIT_lab_6.02M\MRI Lab\medusa\matlab');



psd.shims(1) = str2num(get(handles.x_shim_text, 'String'))/psd.shim_scale_factor;
psd.shims(2) = str2num(get(handles.y_shim_text, 'String'))/psd.shim_scale_factor;
psd.shims(3) = str2num(get(handles.z_shim_text, 'String'))/psd.shim_scale_factor;
shims = psd.shims;


shim_settings_path = fileparts(mfilename('fullpath'))
% temp_path = fileparts(which('SE_PROJ_GUI.m'))
%shim_settings_path = regexprep(temp_path,'.\gui','')
shim_settings = fullfile(shim_settings_path);

cd(shim_settings);

save shims.mat shims

set(handles.system_status,'ForegroundColor',[0 1 0])
set(handles.system_status,'String','SHIM SETTINGS SAVED')











% --- Executes on button press in run_scan_button.
function run_scan_button_Callback(hObject, eventdata, handles)
global psd
global H
global FID

medusaConnect
concmd32(sock, hex2dec('011000'), hex2dec('42'), hex2dec('4'));


% set the numeric ID of this PSD (this is used various places to identify the PSD)
psd.id = 101;
% set the text message output of Medusa scripts to stdout
psd.fid = 0;
psd.ctrl.nodeid = medusaNode(1);	% Medusa Controller #1
psd.rfrx.nodeid = medusaNode(1,0);	% Medusa RF module for Rx (module address 0)
psd.rftx.nodeid = medusaNode(1,0);	% Medusa RF module for Tx (module address 0)
% set up shim currents
psd.grad.nodeid = hex2dec('010800');	% Medusa Gradient module

medusaConnect



H.projection_plot = handles.projection_plot;
H.readout_plot = handles.readout_plot;
H.flip_angle_plot = handles.flip_angle_plot;
H.system_status = handles.system_status;
H.x_shim_slider = handles.x_shim_slider;
H.x_shim_text = handles.x_shim_text;
H.y_shim_slider = handles.y_shim_slider;
H.y_shim_text = handles.y_shim_text;
H.z_shim_slider = handles.z_shim_slider;
H.z_shim_text = handles.z_shim_text;
H.toggle_stop_button = handles.toggle_stop_button;
H.shim_scale_factor = psd.shim_scale_factor;



set(handles.toggle_stop_button,'Value',0)
% hObject    handle to run_scan_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
psd.rftx_time = 160e-6;  set(handles.rftx_time_90,'String',num2str(psd.rftx_time*1e6));

psd.num_reps = str2num(get(handles.num_reps,'String'));
psd.f0 = str2num(get(handles.f0,'String'));  
psd.tr = str2num(get(handles.tr,'String'));
psd.tro = str2num(get(handles.tro,'String'));  
psd.num_ave = str2num(get(handles.num_ave,'String'))
 psd.shims(1) = get(handles.x_shim_slider,'Value')/psd.shim_scale_factor;
 psd.shims(2) = get(handles.y_shim_slider,'Value')/psd.shim_scale_factor;
 psd.shims(3) = get(handles.z_shim_slider,'Value')/psd.shim_scale_factor;
 psd.shims_mA = round(psd.shims.*psd.shim_scale_factor);
 set(handles.x_shim_text,'String',num2str(psd.shims_mA(1)));
 set(handles.y_shim_text,'String',num2str(psd.shims_mA(2)));
 set(handles.z_shim_text,'String',num2str(psd.shims_mA(3)));
 
 
 psd.rfrx.smpclk = 500e3/16;    set(handles.RX_BW,'String',num2str(psd.rfrx.smpclk));
 psd.rftx.smpclk = 500e3/16;	% set RF Tx sample rate to same as Rx
 psd.ctrl.smpclk = 500e3/16;  % set Controller sample rate to same as everything else
 psd.grad.smpclk = 500e3/16;
 
 
 psd.rfrx.gain = str2num(get(handles.RX_gain,'String'));

 
 
 if psd.tr < psd.tro
    set(H.system_status,'ForegroundColor',[1 0 0]);
    set(H.system_status,'String',['ERROR: TR IS TOO SHORT FOR CHOSEN READOUT DURATION']); 
    return
end
 
 
 
%psd.shims(1) = str2num(get(handles.x_shim_text,'String'));
%psd.shims(2) = str2num(get(handles.y_shim_text,'String'));
%psd.shims(3) = str2num(get(handles.z_shim_text,'String'));
psd.rftx_amp = str2num(get(handles.rftx_amp,'String'));
if isfield(psd,'auto_shim') == 0, psd.auto_shim = 0; end
if psd.auto_shim == 1, psd.num_reps = 1;  psd.num_ave = 1; end

if isfield(psd,'debug_mode') == 0, psd.debug_mode = 0; end
if isfield(psd,'flip_angle_cal') == 0,psd.flip_angle_cal = 0; end

% conditional to prepare for flip angle calibration
if psd.flip_angle_cal == 1, psd.rftx_amp = [.01:.01:1]; psd.num_flips = numel(psd.rftx_amp); psd.num_reps = 1;  psd.num_ave = 1; end
if psd.flip_angle_cal == 0, psd.num_flips = 1; datacursormode off; end

if psd.flip_angle_cal == 0, plot(handles.flip_angle_plot,0,0), end

ii=0; aa=0;
if psd.rftx_amp <= 1
while  ii < psd.num_reps  && get(handles.toggle_stop_button,'Value') == 0   || aa < psd.num_ave && get(handles.toggle_stop_button,'Value') == 0

 % update shims in real time while sequence is repeating
 % scale the shim current from mA to units of GPA output control signal
 psd.shims(1) = get(handles.x_shim_slider,'Value');
 psd.shims(2) = get(handles.y_shim_slider,'Value');
 psd.shims(3) = get(handles.z_shim_slider,'Value');
  
 psd.shims_mA = round(psd.shims);

 psd.shims = psd.shims_mA./psd.shim_scale_factor;

 set(handles.x_shim_text,'String',num2str(psd.shims_mA(1)));
 set(handles.y_shim_text,'String',num2str(psd.shims_mA(2)));
 set(handles.z_shim_text,'String',num2str(psd.shims_mA(3)));
 
 if (get(handles.auto_scale_check_box,'Value') == get(handles.auto_scale_check_box,'Max'))
     psd.auto_scale = 1;
 else
     psd.auto_scale = 0;
 end
  
if (get(handles.auto_shim_check_box,'Value') == get(handles.auto_shim_check_box,'Max'))
    psd.auto_shim = 1;
else
    psd.auto_shim = 0;
end


if (get(handles.flip_angle_cal_check_box,'Value') == get(handles.flip_angle_cal_check_box,'Max'))
    psd.flip_angle_cal = 1;
else
    psd.flip_angle_cal = 0;

end

 
 if psd.auto_shim == 1 && psd.flip_angle_cal == 1
     set(handles.system_status,'ForegroundColor',[1 0 0])
     set(handles.system_status,'String','CAN NOT PERFORM AUTO SHIM AND FLIP ANGLE CAL AT THE SAME TIME')
     crash
 end
    
     set(handles.system_status,'ForegroundColor',[0 1 0])
     set(handles.system_status,'String','SYSTEM STATUS: NORMAL')
   
   
    
% call the FID function
FID = FID_func;
  
     if (get(handles.auto_shim_check_box,'Value') == get(handles.auto_shim_check_box,'Max'))
         set(handles.auto_shim_check_box,'Value',0);
         psd.auto_shim = 0;
     end

     if (get(handles.flip_angle_cal_check_box,'Value') == get(handles.flip_angle_cal_check_box,'Max'))
         set(handles.flip_angle_cal_check_box,'Value',0);
         psd.flip_angle_cal = 0;
     end
     
%% averaging routine
if psd.num_ave > 1 && aa == 0 
    data_block_all = [FID.data real(FID.data)]; 
    data_block = [abs(data_block_all(:,1)) data_block_all(:,2)];
    data_block_complex(:,aa+1) = FID.data;
    spec_all(:,1) = (FID.spec);
elseif psd.num_ave > 1 && aa > 0
    data_block_all(:,1,aa+1) = (FID.data); data_block_all(:,2,aa+1) = real(FID.data);
    data_block(:,1) = abs(mean(squeeze(data_block_all(:,1,:)),2));
    data_block(:,2) = real(mean(squeeze(data_block_all(:,1,:)),2));
    data_block_complex(:,aa+1) = FID.data;
    spec_all(:,aa+1) = (FID.spec);
end
%%

time_block = [FID.time.' FID.time.'];
if psd.num_ave == 1
data_block = [abs(FID.data) real(FID.data)];
end

if ii == 0 && aa == 0
    psd.first_spec_mag_ref = 1.05*max(max(abs(FID.spec)));
end

if psd.num_flips == 1  &&  psd.num_ave == 1
    plot(handles.projection_plot,FID.freq_axis,abs(FID.spec))
elseif psd.num_flips == 1  &&  psd.num_ave > 1
    disp('test test test test test \n test test test test test test test \n test test test')
    plot(handles.projection_plot,FID.freq_axis,abs(mean(spec_all,2)))
end
  if psd.auto_scale == 0
      axis(handles.projection_plot,[FID.freq_axis(1) FID.freq_axis(end) 0 psd.first_spec_mag_ref])
  else
      axis(handles.projection_plot,[FID.freq_axis(1) FID.freq_axis(end) 0 1.05*max(abs(FID.spec))])
  end
   xlabel(handles.projection_plot,'freq (KHz)')

   
if psd.num_ave == 1
    plot(handles.readout_plot,time_block,data_block)
else
    plot(handles.readout_plot,time_block,data_block)
end

if ii == 0 || aa == 0
    psd.first_FID_mag_ref = 1.05*max(max(abs(data_block)));
end
 if psd.auto_scale == 0
      axis(handles.readout_plot,[0  FID.time(end)  -psd.first_FID_mag_ref  psd.first_FID_mag_ref])
 else
      axis(handles.readout_plot,[0  FID.time(end)  -1.05*max(max(abs(data_block)))  1.05*max(max(abs(data_block)))])
  end

title(handles.readout_plot, 'free induction decay')
xlabel(handles.readout_plot,'time (sec)'),
% xlim(handles.readout_plot,[0,numel(FID.time)])


if psd.num_ave == 1
    complex_spec = (fftshift(fft(fftshift(FID.data))));
else
    complex_spec = fftshift(fft(mean(squeeze(data_block_all(:,1,:)),2)));
end


 noise = (complex_spec(10:round(numel(complex_spec)./6)));
 noisestd = std(abs(noise));
 SNR = max(abs(FID.spec))/noisestd;

title(handles.projection_plot,['frequency spectrum, SNR = ', num2str(SNR)]);

datacursormode on;






ii=ii+1;  aa=aa+1;


% 
% set(handles.x_shim_slider,'Value',psd.shims(1));
% set(handles.y_shim_slider,'Value',psd.shims(2));
% set(handles.z_shim_slider,'Value',psd.shims(3));


toc, pause(psd.tr*1e-3 - toc)

set(handles.system_status,'ForegroundColor',[0 1 0])
set(handles.system_status,'String','SYSTEM STATUS: NORMAL')



end
else
    disp('ERROR: RF TX amplitude is too high!  RF coil could be damaged')
end


% reset stop toggle button before existing function
set(handles.toggle_stop_button,'Value',0);
