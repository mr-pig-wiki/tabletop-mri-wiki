function varargout = SE_PROJ_GUI(varargin)
%
%  VERSION NOTES
%  V4.0 RELEASED FEBRUARY, 2014 BY JASON STOCKMANN
%  EMAIL JAYSTOCK@NMR.MGH.HARVARD.EDU WITH QUESTIONS
%
%  FOR RELEASE NOTES AND FEATURES/BUG FIXES, PLEASE SEE:
%  https://gate.nmr.mgh.harvard.edu/wiki/Tabletop_MRI/index.php/Hardware:SourceCode
% 
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SE_PROJ_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @SE_PROJ_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

global psd


% --- Executes just before SE_PROJ_GUI is made visible.
function SE_PROJ_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to SE_PROJ_GUI (see VARARGIN)

% Choose default command line output for SE_PROJ_GUI
handles.output = hObject;

global psd
% shim scaling factor from GPA output signal to mA
psd.shim_scale_factor = 10500;
datacursormode on
% set frequency to value saved in text file by FID_GUI
psd.f0_setting_path = fileparts(which('FID_GUI.m'));


fid = fopen([psd.f0_setting_path,'\f0_setting.mat']);
if fid == -1,
    psd.f0 = 8.15e6;  % choose some arbitrary value in case f0_setting file doesn't exist
    save([psd.f0_setting_path,'\f0_setting.mat'],'f0')
    disp(['Couldn''t find f0_setting.mat... Defaulting frequency to ',num2str(psd.f0)])
else
    load([psd.f0_setting_path,'\f0_setting.mat'])
    psd.f0 = f0;
    set(handles.f0,'String',num2str(psd.f0));
    disp(['Frequency of last scan was ',num2str(f0)])
end

fclose(fid)


% Update handles structure
guidata(hObject, handles);

% UIWAIT makes SE_PROJ_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = SE_PROJ_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function f0_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to f0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of f0 as text
%        str2double(get(hObject,'String')) returns contents of f0 as a double
psd.f0 = str2num(get(handles.f0,'String'));


% --- Executes during object creation, after setting all properties.
function f0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to f0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tr_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to tr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tr as text
%        str2double(get(hObject,'String')) returns contents of tr as a double
psd.tr = str2num(get(handles.tr,'String'));


% --- Executes during object creation, after setting all properties.
function tr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tro_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to tro (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tro as text
%        str2double(get(hObject,'String')) returns contents of tro as a double
psd.tro = str2num(get(handles.tro,'String'));


% --- Executes during object creation, after setting all properties.
function tro_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tro (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function te_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to te (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of te as text
%        str2double(get(hObject,'String')) returns contents of te as a double
psd.te = str2num(get(handles.te,'String'));


% --- Executes during object creation, after setting all properties.
function te_CreateFcn(hObject, eventdata, handles)
% hObject    handle to te (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function num_reps_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to num_reps (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of num_reps as text
%        str2double(get(hObject,'String')) returns contents of num_reps as a double
psd.num_reps = str2num(get(handles.num_reps,'String'));


% --- Executes during object creation, after setting all properties.
function num_reps_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num_reps (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function num_ave_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to num_ave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of num_ave as text
%        str2double(get(hObject,'String')) returns contents of num_ave as a double
psd.num_ave = str2num(get(handles.num_ave,'String'));


% --- Executes during object creation, after setting all properties.
function num_ave_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num_ave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




function rftx_amp_90_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to rftx_amp_90 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of rftx_amp_90 as text
%        str2double(get(hObject,'String')) returns contents of rftx_amp_90 as a double
psd.rftx_amp_90 = str2num(get(handles.rftx_amp_90,'String'))


% --- Executes during object creation, after setting all properties.
function rftx_amp_90_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rftx_amp_90 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function file_path_string_Callback(hObject, eventdata, handles)
global psd
global SE
% hObject    handle to file_path_string (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of file_path_string as text
%        str2double(get(hObject,'String')) returns contents of file_path_string as a double


% --- Executes during object creation, after setting all properties.
function file_path_string_CreateFcn(hObject, eventdata, handles)
% hObject    handle to file_path_string (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in save_button.
function save_button_Callback(hObject, eventdata, handles)
global psd
global SE
% hObject    handle to save_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
readout = SE.data;
readout_ave = SE.data_ave;
if psd.projection == 0
        readout_ave = SE.data_running_ave;
elseif psd.projection == 1
        readout_ave = mean(squeeze(SE.data_all),2);
end
time = SE.time.';
spec = SE.spec;
freq_axis = SE.freq.';
%readout_ave = FID.data_ave.';

% browse to folder where shim settings are saved
temp_path = get(handles.file_path_string,'String');

if strcmp(temp_path(end),'\') == 1
     set(handles.system_status,'ForegroundColor',[1 0 0])
     set(handles.system_status,'String','PLEASE APPEND OUTPUT FILE NAME TO END OF SAVE PATH')
else
    save([get(handles.file_path_string,'String')],'readout','readout_ave','time','psd')
    set(handles.system_status,'ForegroundColor',[0 1 0])
    set(handles.system_status,'String','OUTPUT DATA SAVED')
end





% --- Executes on button press in toggle_stop_button.
function toggle_stop_button_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to toggle_stop_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
psd.stop = 1;



% --- Executes on selection change in projection_popupmenu.
function projection_popupmenu_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to projection_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns projection_popupmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from projection_popupmenu

popup_sel_index = get(handles.projection_popupmenu, 'Value')
switch popup_sel_index
     case 1
         psd.ro_switch = 0;  psd.pe1_switch = 0;  psd.pe2_switch = 0;  psd.slice_orientation = 'XZ';  
         psd.te = str2num(get(handles.te,'String'));
         set(handles.tro,'String',num2str(round(2/3*psd.te)));
    
     case 2
         psd.ro_switch = 1;  psd.pe1_switch = 0;  psd.pe2_switch = 0;  psd.slice_orientation = 'XZ'
         psd.te = str2num(get(handles.te,'String'));
         set(handles.tro,'String',num2str(round(psd.te/3)));
     case 3
         psd.ro_switch = 1;  psd.pe1_switch = 0;  psd.pe2_switch = 0;  psd.slice_orientation = 'YZ'
         psd.te = str2num(get(handles.te,'String'));
         set(handles.tro,'String',num2str(round(psd.te/3)));
     case 4
         psd.ro_switch = 1;  psd.pe1_switch = 0;  psd.pe2_switch = 0;  psd.slice_orientation = 'ZX'
         psd.te = str2num(get(handles.te,'String'));
         set(handles.tro,'String',num2str(round(psd.te/3)));
 end


% --- Executes during object creation, after setting all properties.
function projection_popupmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to projection_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end






% --- Executes on button press in load_shims_button.
function load_shims_button_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to load_shims_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% browse to folder where shim settings are saved
% cd('C:\Users\wald2\Dropbox\MIT_lab_6.02M\MRI Lab\medusa\matlab');
shim_settings_path = fileparts(mfilename('fullpath'));
% temp_path = fileparts(which('SE_PROJ_GUI.m'))
%shim_settings_path = regexprep(temp_path,'.\gui','')
shim_settings = fullfile(shim_settings_path, 'shims.mat');

load(shim_settings);

psd.shims = shims;
set(handles.x_shim_setting,'String',num2str(round(psd.shim_scale_factor*psd.shims(1))));
set(handles.y_shim_setting,'String',num2str(round(psd.shim_scale_factor*psd.shims(2))));
set(handles.z_shim_setting,'String',num2str(round(psd.shim_scale_factor*psd.shims(3))));




% --- Executes on button press in zero_shims.
function zero_shims_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to zero_shims (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
psd.shims = [0 0 0];
set(handles.x_shim_setting,'String',num2str(psd.shims(1)))
set(handles.y_shim_setting,'String',num2str(psd.shims(2)))
set(handles.z_shim_setting,'String',num2str(psd.shims(3)))



function rftx_amp_180_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to rftx_amp_180 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of rftx_amp_180 as text
%        str2double(get(hObject,'String')) returns contents of rftx_amp_180 as a double

psd.rftx_amp_180 = str2num(get(handles.rftx_amp_180,'String'));


% --- Executes during object creation, after setting all properties.
function rftx_amp_180_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rftx_amp_180 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on button press in auto_scale_check_box.
function auto_scale_check_box_Callback(hObject, eventdata, handles)
% hObject    handle to auto_scale_check_box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of auto_scale_check_box




function FOV_Callback(hObject, eventdata, handles)
global psd
% hObject    handle to FOV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of FOV as text
%        str2double(get(hObject,'String')) returns contents of FOV as a double
psd.FOV = repmat(str2num(get(handles.FOV,'String')),[1 3])


% --- Executes during object creation, after setting all properties.
function FOV_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FOV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function RX_gain_Callback(hObject, eventdata, handles)
% hObject    handle to RX_gain (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of RX_gain as text
%        str2double(get(hObject,'String')) returns contents of RX_gain as a double
global psd
% hObject    handle to RX_gain (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of RX_gain as text
%        str2double(get(hObject,'String')) returns contents of RX_gain as a double
psd.rfrx.gain = str2num(get(handles.RX_gain,'String'));
psd.rfrx.gain

set(handles.system_status,'ForegroundColor',[0 1 0]);
set(handles.system_status,'String','SYSTEM STATUS: NORMAL');


if psd.rfrx.gain  < -9, psd.rfrx.gain = -9; set(handles.RX_gain,'String',num2str(psd.rfrx.gain)); 
  set(handles.system_status,'ForegroundColor',[1 0 0])
  set(handles.system_status,'String','ERROR: RECEIVE GAIN MUST BE BETWEEN -9 and +6 DB')
end
if psd.rfrx.gain > 6, psd.rfrx.gain = 6; set(handles.RX_gain,'String',num2str(psd.rfrx.gain));
  set(handles.system_status,'ForegroundColor',[1 0 0])
  set(handles.system_status,'String','ERROR: RECEIVE GAIN MUST BE BETWEEN -9 and +6 DB')
end



% --- Executes during object creation, after setting all properties.
function RX_gain_CreateFcn(hObject, eventdata, handles)
% hObject    handle to RX_gain (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end










% --- Executes on button press in run_scan_button.
function run_scan_button_Callback(hObject, eventdata, handles)
% hObject    handle to run_scan_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global psd
global H
global SE


% initialize console parameters
% setup NodeID addresses
psd.id = 100;   psd.fid = 0;
psd.ctrl.nodeid = hex2dec('011000');	% Medusa Controller
psd.rfrx.nodeid = hex2dec('010000');	% Medusa RF module for Rx
psd.rftx.nodeid = hex2dec('010000');	% Medusa RF module for Tx
psd.grad.nodeid = hex2dec('010800');	% Medusa Gradient module
medusaConnect


psd.rftx.smpclk = 500e3/16;
psd.rfrx.smpclk = 500e3/16;
psd.grad.smpclk = 500e3/16;
psd.ctrl.smpclk = 500e3/16;

set(handles.toggle_stop_button,'Value',0);

H.projection_plot = handles.projection_plot;
H.readout_plot = handles.readout_plot;
H.system_status = handles.system_status;
H.stop_button = handles.toggle_stop_button;
H.toggle_stop_button = handles.toggle_stop_button;

set(handles.RX_BW,'String',num2str(psd.rfrx.smpclk));
psd.RX_gain = str2num(get(handles.RX_gain,'String'));
psd.rftx_time_90 = 160e-6;  set(handles.rftx_time_90,'String',num2str(psd.rftx_time_90*1e6));
psd.rftx_time_180 = 160e-6;  set(handles.rftx_time_180,'String',num2str(psd.rftx_time_180*1e6));

psd.num_reps = str2num(get(handles.num_reps,'String'));

set(handles.system_status,'ForegroundColor',[0 1 0])
set(handles.system_status,'String','SYSTEM STATUS: NORMAL')

psd.num_reps = str2num(get(handles.num_reps,'String'));
psd.f0 = str2num(get(handles.f0,'String'));
psd.tr = str2num(get(handles.tr,'String'));
psd.te = str2num(get(handles.te,'String'));
psd.tro = str2num(get(handles.tro,'String'))
psd.FOV = repmat(str2num(get(handles.FOV,'String')),[1 3]);
psd.num_ave = str2num(get(handles.num_ave,'String'));
psd.resolution(2) = 1;
psd.resolution(3) = 1;


psd.rftx_amp_90 = str2num(get(handles.rftx_amp_90,'String'));
psd.rftx_amp_180 = str2num(get(handles.rftx_amp_180,'String'));
psd.projection = 0;  



% % browse to folder where shim settings are saved
% cd('C:\Users\wald2\Dropbox\MIT_lab_6.02M\MRI Lab\medusa\matlab');


psd.shims(1) = str2num(get(handles.x_shim_setting,'String'));
psd.shims(2) = str2num(get(handles.y_shim_setting,'String'));
psd.shims(3) = str2num(get(handles.z_shim_setting,'String'));

psd.shims = psd.shims./psd.shim_scale_factor;

 if (get(handles.auto_scale_check_box,'Value') == get(handles.auto_scale_check_box,'Max'))
     psd.auto_scale = 1;
 else
     psd.auto_scale = 0;
 end
  

popup_sel_index = get(handles.projection_popupmenu, 'Value')
switch popup_sel_index
     case 1
         psd.ro_switch = 0;  psd.pe1_switch = 0;  psd.pe2_switch = 0;  psd.slice_orientation = 'XZ';   psd.projection = 0;  psd.spin_echo = 1;
     case 2
         psd.ro_switch = 1;  psd.pe1_switch = 0;  psd.pe2_switch = 0;  psd.slice_orientation = 'XZ';   psd.projection = 1;  psd.spin_echo = 0;
     case 3
         psd.ro_switch = 1;  psd.pe1_switch = 0;  psd.pe2_switch = 0;  psd.slice_orientation = 'YZ';   psd.projection = 1;  psd.spin_echo = 0;
     case 4
         psd.ro_switch = 1;  psd.pe1_switch = 0;  psd.pe2_switch = 0;  psd.slice_orientation = 'ZX';   psd.projection = 1;  psd.spin_echo = 0;
 end

ii=0;
while get(handles.toggle_stop_button,'Value') ~= 1  && ii < psd.num_reps 
    psd.ii = ii;
%% check sequence parameters for consistency ==============================
if psd.te/2 < psd.tro/2 && psd.projection == 1
  %  fprintf(['ERROR:\t TE = ',num2str(te),' is too short for the specified RF pulse and readout gradient lobe durations\n']);
    set(H.system_status,'ForegroundColor',[1 0 0]);
    set(H.system_status,'String',['ERROR: TE = ',num2str(psd.te),' ms IS TOO SHORT']);
    return
end
if psd.tr < psd.te + psd.tro/2  && psd.projection == 1
  % fprintf(['ERROR:\t TR = ',num2str(tr),' is too short for the specified TE\n']);
    set(H.system_status,'ForegroundColor',[1 0 0]);
    set(H.system_status,'String',['ERROR: TR = ',num2str(psd.te),' ms IS TOO SHORT FOR THE CHOSEN TE AND READOUT TIME']);
   return 
end
if psd.tro > psd.te && psd.projection == 1
    set(H.system_status,'ForegroundColor',[1 0 0]);
    set(H.system_status,'String',['ERROR: READOUT DURATION IS LONGER THAN ECHO TIME']); 
    return
end

if psd.tr < psd.te + psd.tro/2  && psd.projection == 0
  % fprintf(['ERROR:\t TR = ',num2str(tr),' is too short for the specified TE\n']);
    set(H.system_status,'ForegroundColor',[1 0 0]);
    set(H.system_status,'String',['ERROR: TR = ',num2str(psd.te),' ms IS TOO SHORT FOR THE CHOSEN TE AND READOUT TIME']);
   return 
end
if psd.te < psd.tro && psd.projection == 0
  %  fprintf(['ERROR:\t TE = ',num2str(te),' is too short for the specified RF pulse and readout gradient lobe durations\n']);
    set(H.system_status,'ForegroundColor',[1 0 0]);
    set(H.system_status,'String',['ERROR: TE = ',num2str(psd.te),' ms IS TOO SHORT FOR CHOSEN READOUT DURATION']);
    return
end

 
% call spin echo / projection function
    SE = SE_PROJ_func;
    

% plot results
time_block = [SE.time.' SE.time.'];

if psd.num_ave == 1
data_block = [abs(SE.data) imag(SE.data)];
else
data_block = [abs(mean(SE.data_ave,2)) imag(mean(SE.data_ave,2))];
SE.spec = abs(fftshift(fft(fftshift(mean(SE.data_ave,2))))).';
end


% if psd.num_ave == 1,
%     %max(max(abs(FID.data)))
%     if psd.projection == 1
%         plot(handles.projection_plot,SE.freq,abs(SE.spec))
%     axis(handles.projection_plot,[SE.freq(1) SE.freq(end) 0 1.25*max(max(abs(SE.spec)))])
%     else
%         plot(handles.projection_plot,0,0)
%      %   plot(handles.projection_plot,SE.freq_spin_echo,abs(SE.spec_spin_echo))
%     %axis(handles.projection_plot,[SE.freq_spin_echo(1) SE.freq_spin_echo(end) 0 1.25*max(max(abs(SE.spec_spin_echo)))])
%     end
%     title(handles.projection_plot,'frequency spectrum')
%     xlabel(handles.projection_plot,'freq (KHz)')
% 
%     plot(handles.readout_plot,time_block,data_block)
%     if psd.projection == 1
%     axis(handles.readout_plot,[0 SE.time(end) 1.25*min(min(data_block)) 1.25*max(max(data_block))])
%     else
%     axis(handles.readout_plot,[0 SE.time(end) -1.1*max(max(abs(SE.data(psd.rfrx.fft_start:end)))) 1.1*max(max(abs(SE.data(psd.rfrx.fft_start:end))))])
%     end
%     title(handles.readout_plot, 'free induction decay')
%     xlabel(handles.readout_plot,'time (sec)'),
%     
%  %   datacursormode on;
% end

   ii=ii+1;

   
end

set(handles.toggle_stop_button,'Value',0);

% make students recalculate variables
clear SE.freq
clear SE.time
clear SE.spec



function rftx_time_90_Callback(hObject, eventdata, handles)
% hObject    handle to rftx_time_90 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of rftx_time_90 as text
%        str2double(get(hObject,'String')) returns contents of rftx_time_90 as a double


% --- Executes during object creation, after setting all properties.
function rftx_time_90_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rftx_time_90 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function rftx_time_180_Callback(hObject, eventdata, handles)
% hObject    handle to rftx_time_180 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of rftx_time_180 as text
%        str2double(get(hObject,'String')) returns contents of rftx_time_180 as a double


% --- Executes during object creation, after setting all properties.
function rftx_time_180_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rftx_time_180 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
