
fprintf('---------- RF Test PSD Generator ----------\n')

clear psd

psd.id = 100;
psd.fid = 0;

% initialize console parameters
% setup NodeID addresses
psd.ctrl.nodeid = hex2dec('011000');	% Medusa Controller
psd.rfrx.nodeid = hex2dec('010000');	% Medusa RF module for Rx
psd.rftx.nodeid = hex2dec('010000');	% Medusa RF module for Tx
psd.grad.nodeid = hex2dec('010800');	% Medusa Gradient module

% setup sample rates
psd.rfrx.smpclk = 500e3/2;	% set Rx sample rate in Hz (must be 500kHz/(2^N))
psd.rftx.smpclk = psd.rfrx.smpclk;
psd.grad.smpclk = psd.rfrx.smpclk;
psd.ctrl.smpclk = psd.rfrx.smpclk;
% force gradients and controller to 250kHz
%psd.grad.smpclk = 500e3/2;
%psd.ctrl.smpclk = psd.grad.smpclk;

% set RF receiver gain
psd.rfrx.gain = 3;
% set RF transmitter gain
psd.rftx.gain = 0;

% setup frequencies
freq = 63.855062e6 + 3900;
psd.rfrx.freq = freq;	% carrier frequency in Hz
psd.rftx.freq = freq;	% carrier frequency in Hz


% constants
rf_ch = 1;
% setup pulse sequence parameters
Ntr = 80;
tr = 25e-3;					% repeat time
Nro = 2050;
% transmit
Npe = Ntr;
rftx_amp = 400.0;
rftx_time = Nro/psd.rftx.smpclk;
tbwss = 4;					% slice select TBW
%rftx_time = 4e-3;
% receive
rfrx_delay = 0e-3;
rfrx_time = Nro/psd.rfrx.smpclk;

% make RF
% make sinc RF pulse
psd.rftx.data = rftx_amp*wsinc(tbwss, rftx_time*psd.rftx.smpclk);
% make ramp RF pulse
%psd.rftx.data = [ rftx_amp*(1:(rftx_time*psd.rftx.smpclk))/(rftx_time*psd.rftx.smpclk)];
% make hard RF pulse
%psd.rftx.data = [ rftx_amp*ones(1,(rftx_time*psd.rftx.smpclk))];

% make gradients
% generate the pulse sequence pieces
% readout gradient
gro = [];
gro = [gro, 0 0 0 0];														% terminate with zero
% phase encode gradient
gpe = [];
gpe = [gpe, 0 0 0 0];														% terminate with zero
% slice select gradient
gss = [];
gss = [gss, 0 0 0 0];														% terminate with zero
% extend to longest waveform
gr_full_len = max([length(gro) length(gpe) length(gss)]);
if(length(gro) < gr_full_len) gro = [gro 0*ones(1,gr_full_len-length(gro))]; end
if(length(gpe) < gr_full_len) gpe = [gpe 0*ones(1,gr_full_len-length(gpe))]; end
if(length(gss) < gr_full_len) gss = [gss 0*ones(1,gr_full_len-length(gss))]; end

% make rf pulse array
psd.rftx.data = [psd.rftx.data, 0];						% force terminate with zero
psd.rftx.data = psd.rftx.data' * ones(1,Ntr);
psd.rftx.data = reshape(psd.rftx.data, 1, size(psd.rftx.data,1)*size(psd.rftx.data,2));
%psd.rftx.data = psd.rftx.data+2/4095;
%psd.rftx.data = [psd.rftx.data; psd.rftx.data; psd.rftx.data; psd.rftx.data];
psd.rftx.data = (psd.rftx.data' * ones(1,rf_ch)).';

% make gradient array
gx = gro' * [ones(1,Ntr)];
gy = gpe' * [-1:2/(Ntr-1):1];
gz = gss' * [ones(1,Ntr)];
% add ssi
ssi = 0*gro; ssi(1) = hex2dec('1000')/32767;	% create start-of-sequence flag
ssi = ssi' * [ones(1,Ntr)];
% add gating
gate = 0*gro;
gate = gate' * [ones(1,Ntr)];
% re-orient
gx = reshape(gx, 1, size(gx,1)*size(gx,2));
gy = reshape(gy, 1, size(gy,1)*size(gy,2));
gz = reshape(gz, 1, size(gz,1)*size(gz,2));
ssi = reshape(ssi, 1, size(ssi,1)*size(ssi,2));
gate = reshape(gate, 1, size(gate,1)*size(gate,2));
% combine
psd.grad.data = [gx; gy; gz; ssi; gate];
% rotate plane
%ra = [0 0 0];
%psd.grad.data(:,1:3) = Rxyz(psd.grad.data(:,1:3),ra,'degrees');

% setup TR parameters
% controller
psd.ctrl.trlength = tr*psd.ctrl.smpclk;
psd.ctrl.ntrs = Ntr;
% receiver
psd.rfrx.start = round( rfrx_delay*psd.rfrx.smpclk );
psd.rfrx.length = round( rfrx_time*psd.rfrx.smpclk );
psd.rfrx.data = zeros(rf_ch,psd.ctrl.ntrs*psd.rfrx.length);
% transmitter
psd.rftx.start = 1;
psd.rftx.length = size(psd.rftx.data,2)/psd.ctrl.ntrs;
% gradients
psd.grad.start = 1;
psd.grad.length = size(psd.grad.data,2)/psd.ctrl.ntrs;

psd.param.Ntr = Ntr;
psd.param.Nro = Nro;
psd.param.Npe = Ntr;
psd.param.tr = tr;
psd.param.tro = rfrx_time;

psdPrintStats(psd);

% plot the sequence
fprintf('Plotting...\n')
%psdPlotRG(100,psd);
%psdPlotMD(100,psd,0,-0.1);
psdPlotOV(100,psd,0,-0.1);
fprintf('----------------------------------------\n')

%psdBinWrite(psd, 'scan_rftest');
