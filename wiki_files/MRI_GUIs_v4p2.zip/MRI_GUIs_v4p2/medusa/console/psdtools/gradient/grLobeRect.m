function data = grLobeRect(area, samples, fs)
% function data = grLobeRect(area, samples, fs)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

if((nargin > 2) & (fs>0))
	% sample rate has been specified
	% translate time to samples
	samples = round(samples*fs);
end

% generate rectangular gradient lobe with amplitude and sample length
data(1:samples) = area/samples;
