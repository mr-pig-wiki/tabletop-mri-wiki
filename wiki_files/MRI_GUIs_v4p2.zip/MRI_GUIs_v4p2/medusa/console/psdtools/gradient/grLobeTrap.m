function data = grLobeTrap(area, ramplen, samples, fs)
% function data = grLobeTrap(area, slopesmp, samples, fs)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

if((nargin > 3) & (fs>0))
	% sample rate has been specified
	% translate time to samples
	samples = round(samples*fs);
end

if(samples <= 0)
	fprintf('grLobeTrap: WARNING: %1.0f samples requested\n', samples);
	data = [];
	return
end

% first generate rectangular gradient lobe
% - lobe is shorter because it will be convolved
% - amplitude increased to maintain net area
data(1:samples-ramplen) = area/samples*(1+(ramplen/(samples-ramplen)));
data(samples-ramplen+1) = 0;
% now apply convolution smoothing to spread lobe
data = conv(data,ones(ramplen,1)/ramplen);

% make sure output is row vector
data = reshape(data,1,length(data));
