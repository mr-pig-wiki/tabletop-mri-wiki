function h = wsinc(tbw, ns)
% function rf = wsinc(tbw, ns)
%
%   tbw --  time bandwidth product
%   ns  --  number of samples
%   h   -- windowed sinc function, normalized so that sum(h) = 1
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

xm = (ns-1)/2;
x = [-xm:xm]/xm;
h = sinc(x*tbw/2).*(0.54+0.46*cos(pi*x));

h = h/sum(h);
