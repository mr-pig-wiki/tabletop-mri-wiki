function psd = medusaPsdRunStream(psd)
% function psd = medusaPsdRunStream(psd)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% setup output fid
fid = MEDUSA.FID;

err_warn = medusaPsdValidate(psd, 'streaming');

fprintf(fid,'MEDUSA: ----- PSD Run Stream (ID# %1.0f) -----\n', psd.id);

if(err_warn(1) ~= 0)
	fprintf(fid,'Error in PSD. Run cancelled.\n');
	return
end

% determine number of channels
if(isfield(psd,'rftx')) rftx_nch = size(psd.rftx.data,1); else rftx_nch=0; end;
if(isfield(psd,'rfrx')) rfrx_nch = size(psd.rfrx.data,1); else rfrx_nch=0; end;
if(isfield(psd,'grad')) grad_nch = floor(size(psd.grad.data,1)/5); else grad_nch=0; end;
if(isfield(psd,'vmod')) vmod_nch =  ceil(size(psd.vmod.data,1)/5); else vmod_nch=0; end;
% configure all boards
for ch = 1:rftx_nch
	nodeid = psd.rftx.nodeid + hex2dec('100')*(ch-1);
	% reset data pointers
	medusaDataSetPtr(nodeid+MEDUSA.SUB.RFTX.DMA_CH, 0);	% subchannel for playback (used internally by module)
	medusaDataSetPtr(nodeid+MEDUSA.SUB.RFTX.MEM_CH, 0);	% subchannel for data loading (used by us to put data into module memory)
	% clear memory
	samples = psd.ctrl.ntrs*psd.rftx.length;
%	fprintf(fid,'MEDUSA: RFTx Ch#%1.0f: Clearing %7.0f samples', ch, samples );
%	time = medusaRfTxLoadStream(nodeid, zeros(1,psd.ctrl.ntrs*psd.rftx.length));
%	if(time==0) time=0.001; end
%	fprintf(fid,' in %1.3f seconds (%1.0f ksps)\n', time, samples/(time*1000) );
	% reset data pointers
	medusaDataSetPtr(nodeid+MEDUSA.SUB.RFTX.DMA_CH, 0);	% subchannel for playback (used internally by module)
	medusaDataSetPtr(nodeid+MEDUSA.SUB.RFTX.MEM_CH, 0);	% subchannel for data loading (used by us to put data into module memory)
	% set buffer handling for Rf Tx
	if(size(psd.rftx.data,2) == psd.rftx.length)
		% if only 1 TR, set for buffer looping
		medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM1_RESET);
	else
		% if more than 1 TR, set for buffer streaming
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM1_RESET);
	end
	% set TR counter
	medusaSetTrCount(nodeid, psd.ctrl.ntrs);
end
for ch = 1:rfrx_nch
	nodeid = psd.rfrx.nodeid + hex2dec('100')*(ch-1);
	% reset data pointers
	medusaDataSetPtr(nodeid+MEDUSA.SUB.RFRX.DMA_CH, 0);	% subchannel for playback (used internally by module)
	medusaDataSetPtr(nodeid+MEDUSA.SUB.RFRX.MEM_CH, 0);	% subchannel for data loading (used by us to put data into module memory)
	% clear memory
	samples = psd.ctrl.ntrs*psd.rfrx.length;
%	fprintf(fid,'MEDUSA: RFRx Ch#%1.0f: Clearing %7.0f samples', ch, samples );
%	time = medusaRfRxLoad(nodeid, zeros(1,psd.ctrl.ntrs*psd.rfrx.length));
%	if(time==0) time=0.001; end
%	fprintf(fid,' in %1.3f seconds (%1.0f ksps)\n', time, samples/(time*1000) );
	% reset data pointers
	medusaDataSetPtr(nodeid+MEDUSA.SUB.RFRX.DMA_CH, 0);	% subchannel for playback (used internally by module)
	medusaDataSetPtr(nodeid+MEDUSA.SUB.RFRX.MEM_CH, 0);	% subchannel for data loading (used by us to put data into module memory)
	% set buffer handling for RF Rx (always streaming mode)
	medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM0_RESET);
	% set TR counter
	medusaSetTrCount(nodeid, psd.ctrl.ntrs);
end
for ch = 1:grad_nch
	nodeid = psd.grad.nodeid + hex2dec('100')*(ch-1);
	% reset data pointers
	medusaDataSetPtr(nodeid+MEDUSA.SUB.GRAD.DMA_CH, 0);	% subchannel for playback (used internally by module)
	medusaDataSetPtr(nodeid+MEDUSA.SUB.GRAD.MEM_CH, 0);	% subchannel for data loading (used by us to put data into module memory)
	% write data into buffer
	samples = size(psd.grad.data,1)*size(psd.grad.data,2);
%	fprintf(fid,'MEDUSA: Grad Brd%1.0f: Sending  %7.0f samples', ch, samples );
%	% handle gating as needed
%	if(isfield(psd.grad,'gate'))
%		time = medusaGradLoadStream(nodeid, psd.grad.data(1,:), psd.grad.data(2,:), psd.grad.data(3,:), psd.grad.data(4,:), psd.grad.gate);
%	elseif(size(psd.grad.data,1) > 4)
%		time = medusaGradLoadStream(nodeid, psd.grad.data(1,:), psd.grad.data(2,:), psd.grad.data(3,:), psd.grad.data(4,:), psd.grad.data(5,:));
%	else
%		time = medusaGradLoadStream(nodeid, psd.grad.data(1,:), psd.grad.data(2,:), psd.grad.data(3,:), psd.grad.data(4,:), 0);
%	end
%	if(time==0) time=0.001; end
%	fprintf(fid,' in %1.3f seconds (%1.0f ksps)\n', time, samples/(time*1000) );
	% reset data pointers
	medusaDataSetPtr(nodeid+MEDUSA.SUB.GRAD.DMA_CH, 0);	% subchannel for playback (used internally by module)
	medusaDataSetPtr(nodeid+MEDUSA.SUB.GRAD.MEM_CH, 0);	% subchannel for data loading (used by us to put data into module memory)
	% set buffer handling for gradients
	if(size(psd.grad.data,2) == psd.grad.length)
		% if only 1 TR, set for buffer looping
		medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM0_RESET);
		medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM1_RESET);
	else
		% if more than 1 TR, set for buffer streaming
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM0_RESET);
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM1_RESET);
	end
	% set TR counter
	medusaSetTrCount(nodeid, psd.ctrl.ntrs);
end
for ch = 1:vmod_nch
	nodeid = psd.vmod.nodeid + hex2dec('100')*(ch-1);
	% reset data pointers
	medusaDataSetPtr(nodeid+MEDUSA.SUB.VMOD.DMA_CH, 0);	% subchannel for playback (used internally by module)
	medusaDataSetPtr(nodeid+MEDUSA.SUB.VMOD.MEM_CH, 0);	% subchannel for data loading (used by us to put data into module memory)
	% write data into buffer
	samples = size(psd.vmod.data,1)*size(psd.vmod.data,2);
%	fprintf(fid,'MEDUSA: Vmod Brd%1.0f: Sending  %7.0f samples', ch, samples );
%	% handle gating as needed
%	if(isfield(psd.vmod,'gate'))
%		time = medusaVmodLoadStream(nodeid, psd.vmod.data(1:4,:), psd.vmod.gate);
%	elseif(size(psd.vmod.data,1) > 4)
%		time = medusaVmodLoadStream(nodeid, psd.vmod.data(1:4,:), psd.vmod.data(5,:));
%	else
%		time = medusaVmodLoadStream(nodeid, psd.vmod.data(1:4,:), 0);
%	end
%	if(time==0) time=0.001; end
%	fprintf(fid,' in %1.3f seconds (%1.0f ksps)\n', time, samples/(time*1000) );
	% reset data pointers
	medusaDataSetPtr(nodeid+MEDUSA.SUB.VMOD.DMA_CH, 0);	% subchannel for playback (used internally by module)
	medusaDataSetPtr(nodeid+MEDUSA.SUB.VMOD.MEM_CH, 0);	% subchannel for data loading (used by us to put data into module memory)
	% set buffer handling for gradients
	if(size(psd.vmod.data,2) == psd.vmod.length)
		% if only 1 TR, set for buffer looping
		medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM0_RESET);
		medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM1_RESET);
	else
		% if more than 1 TR, set for buffer streaming
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM0_RESET);
		medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MEM1_RESET);
	end
	% set TR counter
	medusaSetTrCount(nodeid, psd.ctrl.ntrs);
end

% figure out how many TRs will fit into memory
% (this determines which module's buffer is the limiting one based on the current pulse sequence)
if(rftx_nch) ntrs_buf_rftx = floor( ( 512*1024)/(psd.rftx.length*2) ); else ntrs_buf_rftx = 1e6; end;
if(rfrx_nch) ntrs_buf_rfrx = floor( ( 512*1024)/(psd.rfrx.length*2) ); else ntrs_buf_rfrx = 1e6; end;
if(grad_nch) ntrs_buf_grad = floor( (1024*1024)/(psd.grad.length*5) ); else ntrs_buf_grad = 1e6; end;
if(vmod_nch) ntrs_buf_vmod = floor( (1024*1024)/(psd.vmod.length*9) ); else ntrs_buf_vmod = 1e6; end;
ntrs_buf = floor(min([psd.ctrl.ntrs ntrs_buf_rftx ntrs_buf_rfrx ntrs_buf_grad ntrs_buf_vmod]));

% figure load range
ntr = 0;
ntrload = ntrs_buf;
if(rftx_nch) rftx_ldrange = ((ntr-0)*psd.rftx.length) + (1:(psd.rftx.length*ntrload)); else rftx_ldrange = 0; end;
if(grad_nch) grad_ldrange = ((ntr-0)*psd.grad.length) + (1:(psd.grad.length*ntrload)); else grad_ldrange = 0; end;
if(vmod_nch) vmod_ldrange = ((ntr-0)*psd.vmod.length) + (1:(psd.vmod.length*ntrload)); else vmod_ldrange = 0; end;
% fill buffers
if(rftx_nch)
	fprintf(fid,'MEDUSA: RFTx: TR=%4.0f-%4.0f: Pre-loading', 1,ntrload);
	samples = size(psd.rftx.data,1)*length(rftx_ldrange)*2;
	time = medusaRfTxLoadStream(psd.rftx.nodeid, psd.rftx.data(rftx_ldrange));
	if(time==0) time=1e-3; end
	fprintf(fid,'  (%4.0f ms / %5.0f ksps)\n', (time*1000), (samples)/(time*1000) );
end
if(grad_nch)
	fprintf(fid,'MEDUSA: GRAD: TR=%4.0f-%4.0f: Pre-loading', 1,ntrload);
	samples = size(psd.grad.data,1)*length(grad_ldrange);
	time = medusaGradLoadStream(psd.grad.nodeid, psd.grad.data(1,grad_ldrange), psd.grad.data(2,grad_ldrange), psd.grad.data(3,grad_ldrange), psd.grad.data(4,grad_ldrange), psd.grad.data(5,grad_ldrange));
	if(time==0) time=1e-3; end
	fprintf(fid,'  (%4.0f ms / %5.0f ksps)\n', (time*1000), (samples)/(time*1000) );
end
if(vmod_nch)
	fprintf(fid,'MEDUSA: VMOD: TR=%4.0f-%4.0f: Pre-loading', 1,ntrload);
	samples = size(psd.vmod.data,1)*length(vmod_ldrange);
	% load data (handle gating as needed)
	if(isfield(psd.vmod,'gate'))
		time = medusaVmodLoadStream(nodeid, psd.vmod.data(1:4,vmod_ldrange), psd.vmod.gate(vmod_ldrange));
	elseif(size(psd.vmod.data,1) > 4)
		time = medusaVmodLoadStream(nodeid, psd.vmod.data(1:4,vmod_ldrange), psd.vmod.data(5,vmod_ldrange));
	else
		time = medusaVmodLoadStream(nodeid, psd.vmod.data(1:4,vmod_ldrange), 0);
	end
	if(time==0) time=1e-3; end
	fprintf(fid,'  (%4.0f ms / %5.0f ksps)\n', (time*1000), (samples)/(time*1000) );
end

% set number of TRs loaded
ntr = ntr+ntrload;

% reset controller TR counter
medusaSetTrCount(psd.ctrl.nodeid, ntrs_buf);
% reset CPU TR counter
concmd32(sock, psd.ctrl.nodeid, MEDUSA.CMD.TRCOUNT, [0]);

if(1)
	% "modern" start command
	psd = medusaPsdStart(psd);
else
	% old start command
	% arm the triggers
	medusaRegBitSet(psd.rfrx.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
	medusaRegBitSet(psd.rftx.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
	medusaRegBitSet(psd.grad.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
	medusaRegBitSet(psd.vmod.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
	% run
	fprintf(fid,'MEDUSA: Starting Scan.\n');
	medusaRegBitClr(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
	medusaRegBitSet(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MSYNC_OE);
	medusaRegBitSet(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TR_REPEAT);
	medusaRegBitSet(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_ENABLE);
	medusaRegBitSet(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_SW);
end

if(1)
psd.rfrx.data = [];
rfrx_trcount = 0;
while(ntr < psd.ctrl.ntrs)
	% outgoing data
	% check the TR/buffer count to see if we need to refill	
	trcount = medusaRegRead(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.TRCOUNT);
	% do we have TRs to load?
	if(trcount < (ntrs_buf-1))
		% figure load range
		ntrload = (ntrs_buf-1) - trcount;
		ntrload = min(ntrload, psd.ctrl.ntrs-ntr);	% no more TRs loaded than we have left in the scan
		ntrload = min(ntrload, 20);					% no more than 20 TRs loaded at a time
		if(rftx_nch) rftx_ldrange = ((ntr-0)*psd.rftx.length) + (1:(psd.rftx.length*ntrload)); else rftx_ldrange = 0; end;
		if(grad_nch) grad_ldrange = ((ntr-0)*psd.grad.length) + (1:(psd.grad.length*ntrload)); else grad_ldrange = 0; end;
		if(vmod_nch) vmod_ldrange = ((ntr-0)*psd.vmod.length) + (1:(psd.vmod.length*ntrload)); else vmod_ldrange = 0; end;
		
		% load more data
		fprintf(fid,'MEDUSA: TR=%4.0f-%4.0f: Streaming Data Out', ntr, ntr+ntrload);
		time = 0;
		samples = 0;
		if(rftx_nch)
			samples = samples + 2*size(psd.rftx.data,1)*length(rftx_ldrange);
			time = time + medusaRfTxLoadStream(psd.rftx.nodeid, psd.rftx.data(rftx_ldrange));
		end
		if(grad_nch)
			samples = samples + 5*ceil(size(psd.grad.data,1)/5)*length(grad_ldrange);
			% load data (handle gating as needed)
			if(isfield(psd.grad,'gate'))
				time = medusaGradLoadStream(nodeid, psd.grad.data(1,grad_ldrange), psd.grad.data(2,grad_ldrange), psd.grad.data(3,grad_ldrange), psd.grad.data(4,grad_ldrange), psd.grad.gate(grad_ldrange));
			elseif(size(psd.grad.data,1) > 4)
				time = medusaGradLoadStream(nodeid, psd.grad.data(1,grad_ldrange), psd.grad.data(2,grad_ldrange), psd.grad.data(3,grad_ldrange), psd.grad.data(4,grad_ldrange), psd.grad.data(5,grad_ldrange));
			else
				time = medusaGradLoadStream(nodeid, psd.grad.data(1,grad_ldrange), psd.grad.data(2,grad_ldrange), psd.grad.data(3,grad_ldrange), psd.grad.data(4,grad_ldrange), 0);
			end
		end
		if(vmod_nch)
			samples = samples + 9*ceil(size(psd.vmod.data,1)/5)*length(vmod_ldrange);
			% load data (handle gating as needed)
			if(isfield(psd.vmod,'gate'))
				time = medusaVmodLoadStream(nodeid, psd.vmod.data(1:4,vmod_ldrange), psd.vmod.gate(vmod_ldrange));
			elseif(size(psd.vmod.data,1) > 4)
				time = medusaVmodLoadStream(nodeid, psd.vmod.data(1:4,vmod_ldrange), psd.vmod.data(5,vmod_ldrange));
			else
				time = medusaVmodLoadStream(nodeid, psd.vmod.data(1:4,vmod_ldrange), 0);
			end
		end
		if(time==0) time=1e-3; end
		fprintf(fid,' (%4.0f ms / %5.0f ksps)\n', (time*1000), (samples)/(time*1000) );
		ntr = ntr+ntrload;
		% increment TR/buffer counter
		for(inc = 1:ntrload)
			medusaRegBitSet(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRCOUNT_INC);	% setting this bit safely (atomically) increments the TR counter
		end
		
		% incoming data
		% for every TR sent, we read one in
		if(rfrx_nch)
			fprintf(fid,'MEDUSA: TR=%4.0f-%4.0f: Streaming Data In  (RF Rx)\n', rfrx_trcount, rfrx_trcount+ntrload);
			psd.rfrx.data = [psd.rfrx.data medusaRfRxReadStream(psd.rfrx.nodeid, ntrload*psd.rfrx.length) ];
			rfrx_trcount = rfrx_trcount + ntrload;
		end
	else
		% no TRs to load, so we wait
		pause(0.005);
	end
end
end

tr_remain = 1;
while(tr_remain)
	tr_remain = medusaRegRead(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.TRCOUNT);
	fprintf(fid,'MEDUSA: TRs remaining: %1.0f\n', tr_remain);
	pause(0.25);
end

% stop scan (disable triggers)
medusaPsdStop(psd);

% get the rest of data
if(rfrx_nch)
	fprintf(fid,'MEDUSA: TR=%1.0f-%1.0f: Streaming Data In  (RF Rx)\n', rfrx_trcount, psd.ctrl.ntrs);
	% read remaining TRs
	%psd.rfrx.data = [psd.rfrx.data medusaRfRxReadStream(psd.rfrx.nodeid, (psd.ctrl.ntrs-rfrx_trcount)*psd.rfrx.length) ];
	% read tr-by-tr because of medusa buffering issue
	for n = 1:(psd.ctrl.ntrs-rfrx_trcount)
		psd.rfrx.data = [psd.rfrx.data medusaRfRxReadStream(psd.rfrx.nodeid, psd.rfrx.length) ];
	end
end

fprintf(fid,'MEDUSA: Scan Done.\n', ntr);
