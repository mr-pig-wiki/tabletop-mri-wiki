function medusaPsdMonitor(psd)
% function medusaPsdMonitor(psd)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global MEDUSA

% setup output fid
fid = MEDUSA.FID;

tr_remain = 1;
while(tr_remain) 
	tr_remain = medusaRegRead(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.TRCOUNT);
	fprintf(fid, 'MEDUSA: TRs remaining: %1.0f\n', tr_remain);
	pause(0.25);
end
