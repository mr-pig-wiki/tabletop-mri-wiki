function medusaPsdStop(psd)
% function medusaPsdStop(psd)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% setup output fid
fid = MEDUSA.FID;

fprintf(fid,'MEDUSA: ----- PSD Stop (ID# %1.0f) -----\n', psd.id);

% using broadcast address (see below)
if(0)
% determine number of channels
if(isfield(psd,'rftx')) rftx_nch = size(psd.rftx.data,1); else rftx_nch=0; end;
if(isfield(psd,'rfrx')) rfrx_nch = size(psd.rfrx.data,1); else rfrx_nch=0; end;
if(isfield(psd,'grad')) grad_nch = floor(size(psd.grad.data,1)/5); else grad_nch=0; end;
if(isfield(psd,'vmod')) vmod_nch =  ceil(size(psd.vmod.data,1)/5); else vmod_nch=0; end;
% disable MSYNC trigger on all boards
for ch = 1:rftx_nch
	nodeid = psd.rftx.nodeid + hex2dec('100')*(ch-1);
	medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
end
for ch = 1:rfrx_nch
	nodeid = psd.rfrx.nodeid + hex2dec('100')*(ch-1);
	medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
end
for ch = 1:grad_nch
	nodeid = psd.grad.nodeid + hex2dec('100')*(ch-1);
	medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
end
for ch = 1:vmod_nch
	nodeid = psd.vmod.nodeid + hex2dec('100')*(ch-1);
	medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
end
end

% use broadcast address to disable modules
nodeid = bitor(psd.ctrl.nodeid, hex2dec('FF00'));
medusaRegBitClr(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);

% configure controller to stop
medusaRegBitClr(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
% disable MSYNC_OE drive
medusaRegBitClr(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MSYNC_OE);
