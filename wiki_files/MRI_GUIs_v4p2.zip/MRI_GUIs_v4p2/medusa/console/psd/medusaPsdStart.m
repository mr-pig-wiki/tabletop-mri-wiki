function psd = medusaPsdStart(psd)
% function psd = medusaPsdStart(psd)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% setup output fid
fid = MEDUSA.FID;

fprintf(fid,'MEDUSA: ----- PSD Start (ID# %1.0f) -----\n', psd.id);

% using broadcast address (see below)
if(0)
% determine number of channels
if(isfield(psd,'rftx')) rftx_nch = size(psd.rftx.data,1); else rftx_nch=0; end;
if(isfield(psd,'rfrx')) rfrx_nch = size(psd.rfrx.data,1); else rfrx_nch=0; end;
if(isfield(psd,'grad')) grad_nch = floor(size(psd.grad.data,1)/5); else grad_nch=0; end;
if(isfield(psd,'vmod')) vmod_nch =  ceil(size(psd.vmod.data,1)/5); else vmod_nch=0; end;
% enable MSYNC trigger on all boards
for ch = 1:rftx_nch
	nodeid = psd.rftx.nodeid + hex2dec('100')*(ch-1);
	medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
end
for ch = 1:rfrx_nch
	nodeid = psd.rfrx.nodeid + hex2dec('100')*(ch-1);
	medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
end
for ch = 1:grad_nch
	nodeid = psd.grad.nodeid + hex2dec('100')*(ch-1);
	medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
end
for ch = 1:vmod_nch
	nodeid = psd.vmod.nodeid + hex2dec('100')*(ch-1);
	medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
end
end

% set timestamp
psd.timestamp = fix(clock);
fprintf(fid,'MEDUSA: TimeStamp = %04d-%02d-%02d %02d:%02d:%02d\n',fix(psd.timestamp));

% check trigger configuration
if(isfield(psd.ctrl,'trig')); trig = psd.ctrl.trig; else; trig = 0; end;

if(trig == 0)
	% use broadcast address to enable modules
	nodeid = bitor(psd.ctrl.nodeid, hex2dec('FF00'));
	medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);

	% configure controller for run, self-triggered
	medusaRegBitClr(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
	medusaRegBitSet(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MSYNC_OE);
	medusaRegBitSet(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TR_REPEAT);
	medusaRegBitSet(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_ENABLE);
	% start scan
	medusaRegBitSet(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_SW);
else
	% use broadcast address to enable modules
	nodeid = bitor(psd.ctrl.nodeid, hex2dec('FF00'));
	medusaRegBitSet(nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);

	% configure controller for run, external-trigger
	medusaRegBitSet(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC);
	medusaRegBitClr(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_MSYNC_OE);
	medusaRegBitClr(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_TR_REPEAT);
	medusaRegBitSet(psd.ctrl.nodeid, MEDUSA.REG.TRCTRL.CTRL, MEDUSA.REG.TRCTRL.CTRL_ENABLE);
	% TRs start on external trigger
end
