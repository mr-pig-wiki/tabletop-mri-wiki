function value = medusaRegWrite(nodeid, regaddr, value)
% function value = medusaRegWrite(nodeid, regaddr, value)
%  > nodeid = address of controller/module
%  > regaddr = address of register
%  > value = value to write
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% issue command
concmd32(sock, nodeid, MEDUSA.CMD.RAWREG, [regaddr value]);
