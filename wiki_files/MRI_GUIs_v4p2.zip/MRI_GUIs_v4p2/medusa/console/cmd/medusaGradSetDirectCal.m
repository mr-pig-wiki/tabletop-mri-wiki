function gradientSetDirectCal(nodeid, Gn, voltage)
% function gradientSetDirectCal(nodeid, Gn, voltage)
%   this function employs the calibration set by 'gradientDacParams'
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

medusaGradDacParams
medusaGradSetDirect(nodeid, Gn, voltage/Gscale(Gn+1) + Gzero(Gn+1) );
