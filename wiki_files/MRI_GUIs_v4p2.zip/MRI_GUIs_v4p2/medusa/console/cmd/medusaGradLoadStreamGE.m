function time = medusaGradLoadStreamGE(nodeid,Gx,Gy,Gz,Ga,gate)
%function time = medusaGradLoadStreamGE(nodeid,Gx,Gy,Gz,Ga,gate)
% Gx,Gy,Gz,Ga,gate are expected in row vectors
% 'gate' may be 0 if no extended gating needed
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% discourage use of this function
fprintf(fid,'\n\n##### WARNING #####\nMedusaGradLoadStreamGE: This function is deprecated. Please use ''medusaGradLoadStream''\n\n');

% mask subchannel bits of NODEID
nodeid = bitand(nodeid, hex2dec('FFFFFF00'));

% fill gating data if user didn't provide
if(gate == 0)
	%gate = zeros(1,length(Gx));
	% make gate signal to flash status LEDs on DAC modules
	gate = hex2dec('0000')*[ ones(1,floor(length(Gx)/2)) zeros(1,ceil(length(Gx)/2)) ];
end

% make sure inputs are row vectors
Gx = reshape(Gx,1,length(Gx));
Gy = reshape(Gy,1,length(Gy));
Gz = reshape(Gz,1,length(Gz));
Ga = reshape(Ga,1,length(Ga));
gate = reshape(gate,1,length(gate));

% prep gradient data interleave format
grdata = [Gx;Gy;Gz;Ga];
if( max(max(abs(grdata))) <= 1.0 )
	% assume input normalized to 1.0
	grdata = (32767*grdata)+65536;
else
	% assume input normalized to 16-bit value
	grdata = (1*grdata)+65536;
end
% clamp grdata to 16bit range
grdata = round(grdata);
grdata = bitand(grdata, 65535);
% add gating and reshape
grdata = [grdata; gate];
grdata = reshape(grdata,1,size(grdata,1)*size(grdata,2));

% load gradient data
tic;
concmd(sock, nodeid+MEDUSA.SUB.GRAD.CH, MEDUSA.CMD.RAWDATA, grdata);
time = toc;
