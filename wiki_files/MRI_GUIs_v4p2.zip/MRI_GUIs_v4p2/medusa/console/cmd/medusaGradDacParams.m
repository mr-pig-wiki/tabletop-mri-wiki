% set DAC parameters for DAC outputs
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% params for original DAC boards (gscott)
% zero offsets
%Gzero = [88/32767 -41/32767 116/32767]; 
% scale factors
%Gscale = ([9.749 9.843 9.779]/9.0)*10;

% params for new DAC boards (pstang)
% S/N: 0001A 0002A 0003A
% zero offsets
Gzero(1:4) = [+26   +28   +24  0]/32767; 
% scale factors
Gscale(1:4) = ([19.519/2   19.501/2   19.595/2  0/2]/9.0)*10;

% params for new DAC boards (pstang)
% S/N: 0004A 0005A 0006A 0008A
% zero offsets
%Gzero(1:4) = [+14   +18   +13   +17]/32767; 
% scale factors
%Gscale(1:4) = ([19.662   19.643   19.623  19.595]/(2*9.0))*10.0;

% params for new DAC boards (pstang)
% S/N: 0009A 0010A 0011A 0012A
% zero offsets
%Gzero(1:4) = [+24   +20   +19   +39]/32767;
% scale factors
%Gscale(1:4) = ([19.564   19.550   19.597  19.569]/(2*9.0))*10.0;

% params for new DAC boards (pstang)
% S/N: 0013A 0014A 0015A 0016A
% zero offsets
%Gzero(1:4) = [+16   +15   +18   +15]/32767;
% scale factors
%Gscale(1:4) = ([19.606   19.602   19.575  19.603]/(2*9.0))*10.0;

% params for new DAC boards (pstang)
% S/N: 0017A 0018A 0019A
% zero offsets
Gzero(1:4) = [+24   +16   +0   +0]/32767;
% scale factors
Gscale(1:4) = ([19.627   19.620   18.000  18.000]/(2*9.0))*10.0;

