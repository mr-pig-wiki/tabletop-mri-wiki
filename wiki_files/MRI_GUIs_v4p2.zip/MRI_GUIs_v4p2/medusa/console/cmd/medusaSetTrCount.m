function medusaSetTrCount(nodeid, count)
% function medusaSetTrCount(nodeid, count)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

%concmd32(sock, nodeid, MEDUSA.CMD.TRCOUNT, count);
medusaRegWrite(nodeid, MEDUSA.REG.TRCTRL.TRCOUNT, count);
