function data = medusaRfRxRead(nodeid, nsamples)
% function data = medusaRfRxRead(nodeid, nsamples)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% mask subchannel bits of NODEID
nodeid = bitand(nodeid, hex2dec('FFFFFF00'));

% reset address back to start
medusaDataSetPtr(nodeid+MEDUSA.SUB.RFRX.MEM_CH, 0*1024);
% read data
data = medusaRfRxReadStream(nodeid+MEDUSA.SUB.RFRX.MEM_CH, nsamples);
% reset address back to start
medusaDataSetPtr(nodeid+MEDUSA.SUB.RFRX.MEM_CH, 0*1024);
