function medusaRfRxSetGate(nodeid, state)
% function medusaRfRxSetGate(nodeid, state)
% sets RF Rx output gating immediately
%  - state value is 0=gate off, 1=gate on
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

if(state)
	medusaRegBitSet(nodeid, MEDUSA.REG.MAIN.GATE, MEDUSA.REG.MAIN.GATE_RFRX)
else
	medusaRegBitClr(nodeid, MEDUSA.REG.MAIN.GATE, MEDUSA.REG.MAIN.GATE_RFRX)
end

