function nodeid = medusaNode(controller, module, subchannel)
% function nodeid = medusaNode(controller, [module], [subchannel])
% build Medusa NodeID from values
%  - controller = Medusa controller number (1-16)
%  - module     = Medusa module (board) number (0-15)
%  - subchannel = Medusa subchannel (0-255) used by some modules to direct data
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

if(nargin == 1)
	module = hex2dec('10');
	subchannel = 0;
elseif(nargin == 2)
	subchannel = 0;
end	

% build nodeid
nodeid = bitshift(controller,16)+bitshift(module,8)+bitshift(subchannel,0);
