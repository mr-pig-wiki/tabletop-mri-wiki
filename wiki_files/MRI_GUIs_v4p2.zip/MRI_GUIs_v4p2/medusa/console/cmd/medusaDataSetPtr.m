function medusaDataSetPtr(nodeid,addr)
% function medusaDataSetPtr(nodeid,addr)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% set current pointer address
concmd32(sock, nodeid, MEDUSA.CMD.RAWADDR, addr);
