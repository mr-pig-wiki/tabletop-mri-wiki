function medusaVmodSetDirectVec(nodeid,channel,magn,phase)
% function medusaVmodSetDirectVec(nodeid,channel,magn,phase)
%
% Directly write VM DACs for one channel (effective immediately)
% nodeid - module/device node ID as reported upon connection
% magn   - signal magnitude (normalized -1 to 1)
% phase  - signal phase (degrees)
%
% Magn & phase values match original VB GUI result
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

dcos = magn * cos(((90+phase)/180)*pi); % polarity of phaseval and 90-deg shift is to match original VB GUI result
dsin = magn * sin(((90+phase)/180)*pi); % polarity of phaseval and 90-deg shift is to match original VB GUI result
medusaVmodSetDirect(nodeid,channel,dcos,dsin);
