function gradientSetDirect(nodeid, Gn, value)
%function gradientSetDirect(nodeid, Gn, value)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA
% why does this crash the Medusa Controller
%concmd(sock, nodeid, MEDUSA.CMD.GRADDIRWRITE, [Gn value*32767]);

% do this for now
medusaRegWrite(nodeid, MEDUSA.REG.GRAD.DAC0+Gn, (value*32767));
