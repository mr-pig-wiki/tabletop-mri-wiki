function data = medusaBufRead(nodeid, nwords)
% function data = medusaBufRead(nodeid, nwords)
%   nodeid = address of controller/module
%   nwords = number of words to read
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% read data
if( bitand(nodeid,hex2dec('001000')) )
	% nodeid points to controller
	tic;
	%data = concmdRead(sock, nodeid, MEDUSA.CMD.SAMPLEBUFFER, [mod(nwords,65536) nwords/65536]);
	data = concmdRead(sock, nodeid, MEDUSA.CMD.RAWDATA, [mod(nwords,65536) nwords/65536]);
	time = toc;
else
	% nodeid points to module
	tic;
	data = concmdRead(sock, nodeid, MEDUSA.CMD.RAWDATA, [mod(nwords,65536) nwords/65536]);
	time = toc;
end
