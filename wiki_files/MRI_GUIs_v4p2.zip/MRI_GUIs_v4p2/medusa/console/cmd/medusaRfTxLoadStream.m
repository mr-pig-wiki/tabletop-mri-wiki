function time = medusaRfTxLoadStream(nodeid, data)
% function time = medusaRfTxLoadStream(nodeid, data)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% mask subchannel bits of NODEID
nodeid = bitand(nodeid, hex2dec('FFFFFF00'));

% make sure input is row vector
data = reshape(data,1,length(data));

% translate data into DDS format
% 12-bit amplitude (0-4095)
% 14-bit phase (0-16384)
if( (max(max(abs(data))) <= 1.0) )
	% assume input normalized to 1.0
	txdata = [abs(data)*4095; angle(data)*16384/(2*pi);];
else
	% assume input normalized to 16-bit value
	data = data ./ 32768;
	txdata = [abs(data)*4095; angle(data)*16384/(2*pi);];
end
% round magnitude such that only exact 0 turns off TxGate
% could use 'ceil' here, but we're doing this a fun way
txdata(1,find((txdata(1,:)>0) & (txdata(1,:)<1))) = 1;
txdata = round(txdata);
% clamp data to allowed range
% magnitude
txdata(1,find(txdata(1,:) >= 4096)) = 4095;
txdata(1,find(txdata(1,:) <     0)) = 0;
% phase
txdata(2,:) = bitand(txdata(2,:)+65536, 16384-1);

% reformat data vector
txdata = reshape(txdata,1,size(txdata,1)*size(txdata,2));

% load data
tic;
concmd(sock, nodeid+MEDUSA.SUB.RFTX.MEM_CH, MEDUSA.CMD.RAWDATA, txdata);
time = toc;
