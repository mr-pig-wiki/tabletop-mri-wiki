% This sequence is called by FID_GUI
% For use with the MIT 6.S02 laboratory imaging system
% Jan 3, 2013
%
% The PSD is rendered as a Matlab structure called 'psd'.
% Since this script uses only the RF Tx/Rx system (no gradients),
% it will not fill in the data tree for psd.grad.
%
% This PSD will generate a short hard pulse excitation,
% followed by a receive acquisition window to get the FID.

function [FID] = FID_func
global psd
global H
%check_debug_mode = isfield(psd,'debug_mode');  if check_debug_mode == 0, psd.debug_mode = 0; end

%if psd.debug_mode == 0
% set up pulse amplitudes for flip angle calibration
%%% BE CAREFUL NOT TO SET rftx_amp TOO HIGH WHEN USING TOMCO!!!!!!!!!!
%%% (Less than 0.2 should be adequate)

% set a unitless RF Tx voltage  multiplier
% correct value for Tomco with big probe and 100 us pulse
rftx_amp = psd.rftx_amp;
%rftx_amp = [0.01:.005:.1];

%correct value for ZHL-1A + gali amp
%rftx_amp = [0.175];
%rftx_amp = .1:.001:.2;

psd.rfrx.freq = 1e6*psd.f0;	% receive at ~1.5T proton
% transmit parameters
% set transmit pulse length to 1ms
rftx_time = psd.rftx_time;   %%% for tomco (have to set to 150us instead of 100us bc gate issue)
%rftx_time = .1e-3;
num_reps = 1;               % number of repetitions (for shimming), not averaged
num_ave = 1;
Ntr = 1;					% set number of TRs in the PSD --> will be averaged


tr = psd.tr*1e-3;				% set the TR interval (repeat time) to 500ms
psd.param.tr = tr;

rfrx_time = psd.tro*1e-3;			% set receive acquisition length (100ms)

apodization_switch = 0;
downsampling_factor = 1;

shim_optimization = psd.auto_shim;         % 1 to re-run shim optimizer, 0 to load old shim value
%shims = [-.0011 .0012 -.0012];
%shims = [-.0013 .0009 -.001*0];
%shims = [-0.000 0.0005 0.00005];
%shims = 0*[0.001 0.001 0.001];
%load shims.mat

%psd.shims(1) = str2num(get(H.x_shim_text,'String'));
%psd.shims(2) = str2num(get(H.y_shim_text,'String'));
%psd.shims(3) = str2num(get(H.z_shim_text,'String'));
shims = psd.shims;

shim_bound = .01;   TolX = 1e-9;    % the smaller the tolerance, the longer the shim optimizer will run

% setup sample rates
% here we choose to 



% set RF receiver gain
%psd.rfrx.gain = 0;		% (3 * 3dB/step = 9dB)

% set RF transmitter gain -- not relevant for our hardware setup
psd.rftx.gain = 0;		% (0 * 3dB/step = 0dB -- has no effect unless external PGA amp is used)

% setup RF carrier frequencies (in Hz)
psd.rftx.freq = psd.rfrx.freq;


% initialize console parameters
% setup NodeID addresses (this selects which hardware is involved in this PSD)
%medusaReset(psd.ctrl.nodeid);
ff = 1;

num_flips = numel(rftx_amp);
for aa=1:num_ave
for ii=1:num_reps
while ff <= num_flips && get(H.toggle_stop_button,'Value') ~= 1,     if num_flips > 1, tic, end

% % set the numeric ID of this PSD (this is used various places to identify the PSD)
% psd.id = 101;
% % set the text message output of Medusa scripts to stdout
% psd.fid = 0;



% define some parameter constants just to help us generate the sequence
% overall parameters
rf_ch = 1;					% use one RF channel

% receive parameters
rfrx_delay = rftx_time + 600e-6;		% set receive acquisition to shortly after transmit pulse ends


% create pulses
% make single hard pulse (containing rftx_time*psd.rftx.smpclk samples)
psd.rftx.data = rftx_amp(ff)*ones(1, rftx_time*psd.rftx.smpclk);
% force terminate RF Tx to zero at end of pulse
psd.rftx.data = [psd.rftx.data 1/4095 1/4095 0];  % account for one point quantization error, then force transmitter to zero

% generate RF pulse array from single pulse
% data should have the format:
%   [[Tx-Ch1 for TR#0] [Tx-Ch1 for TR#1] ... [Tx-Ch1 for TR#N]]
% replicate same RF pulse for each TR
psd.rftx.data = psd.rftx.data' * ones(1,Ntr);
% reshape RF data back to 1 row
psd.rftx.data = reshape(psd.rftx.data, 1, size(psd.rftx.data,1)*size(psd.rftx.data,2));
% duplicate the row for the number of RF channels we will use
psd.rftx.data = (psd.rftx.data' * ones(1,rf_ch)).';

% setup TR timing parameters
% controller
psd.ctrl.trlength = tr*psd.ctrl.smpclk;		% set overall TR length (measured in Controller samples)
psd.ctrl.ntrs = Ntr;						% set number of TRs in the scan
% RF receiver
psd.rfrx.start = 1+round( rfrx_delay*psd.rfrx.smpclk );			% start Rx acquire this many samples from start of TR
psd.rfrx.length = round( rfrx_time*psd.rfrx.smpclk );			% acquire this many Rx samples per TR
psd.rfrx.data = zeros(rf_ch,psd.ctrl.ntrs*psd.rfrx.length);		% preallocate the memory for the Rx data
% RF transmitter
psd.rftx.start = 1;										% start Tx playback at first sample of TR
psd.rftx.length = size(psd.rftx.data,2)/psd.ctrl.ntrs;	% play this many Tx samples per TR

psd.grad.data = zeros(5,rfrx_time*psd.rfrx.smpclk);

% print information about the sequence
psdPrintStats(psd);

% plot the sequence to verify visually
% fprintf('Plotting...\n')
% % here we demonstrate two different views of the same PSD
% psdPlotMD(100,psd,0,-0.1);	% figure 100: plot PSD as time-series of TRs
% psdPlotOV(101,psd,0,-0.1);	% figure 101: plot PSD as single TR (data from each is overlapped)
% fprintf('----------------------------------------\n')

% PSD generation is complete
% this PSD can now be executed by calling 'psdrun':
% >> psdrun
% 
% or it can be executed directly by calling the Medusa commands:
% >> medusaPsdConfigure(psd);
% >> psd = medusaPsdRun(psd);


if ii==1 && ff==1
%figure(2),psdPlotOV(100,psd,0,-0.1)
end



psd.grad.start = 1;
psd.grad.length = length(psd.grad.data);

shim_string = ['xyz'];

%%psdgen_p2dft

if shim_optimization == 1  
    

    freq_axis = .001.*[-ceil(psd.rfrx.length/2):1:floor(psd.rfrx.length/2)-1]*psd.rfrx.smpclk/psd.rfrx.length;  % freq in KHz
    smpperiod = 1/psd.rfrx.smpclk;
    time = (smpperiod:smpperiod:psd.rfrx.length*smpperiod);

    options = optimset('MaxIter',10000,'TolX',TolX); 
for dd=1:3,disp(['shimming ',num2str(shim_string(dd))])
    if get(H.toggle_stop_button,'Value') ~= 1
  [new_shim FVAL EXITFLAG] = fmincon(@(new_shim)shim_opt_MIT_func(new_shim,dd,shims,freq_axis,time,psd),...
      [-0.0001],[],[],[],[],[-shim_bound],[shim_bound],[],options);
    end
  shims(dd) = new_shim;
  shims_mA(dd) = round(shims(dd).*H.shim_scale_factor);
  string = 'xyz';
  eval(['set(H.',string(dd),'_shim_text,''String'',shims_mA(',num2str(dd),'))'])  
  eval(['set(H.',string(dd),'_shim_slider,''Value'',shims_mA(',num2str(dd),'))'])

end
  FVAL,EXITFLAG
 % save shims.mat shims
  set(H.system_status,'ForegroundColor',[0 1 0])
  set(H.system_status,'String','NEW SHIM SETTINGS SAVED TO FILE SHIMS.MAT')

  
  psd.grad.data(1,:) = shims(1);
  psd.grad.data(2,:) = shims(2);
  psd.grad.data(3,:) = shims(3);
  
  medusaPsdConfigure(psd);
  psd = medusaPsdRunStream(psd); 
  
  psd.shims = shims;
  
  
  
else
    
    
  psd.grad.data(1,:) = shims(1);
  psd.grad.data(2,:) = shims(2);
  psd.grad.data(3,:) = shims(3);
  shims
 % psd.grad.data(:,end) = 0;
 % psd.grad.data(:,1) = 0;
 %  psd.grad.data(4,1) = .125;
%   psd.grad.data(:,1:8) = 0;
%   psd.grad.data(:,end) = 0;
  
    medusaPsdConfigure(psd);
    psd = medusaPsdRunStream(psd);
end

if(0)
fprintf('Grad DMA Ptr: %1.0f\n', medusaDataGetPtr( psd.grad.nodeid+MEDUSA.SUB.GRAD.DMA_CH));
fprintf('Grad MEM Ptr: %1.0f\n', medusaDataGetPtr( psd.grad.nodeid+MEDUSA.SUB.GRAD.MEM_CH));
fprintf('RFRx DMA Ptr: %1.0f\n', medusaDataGetPtr( psd.rfrx.nodeid+MEDUSA.SUB.RFRX.DMA_CH));
fprintf('RFRx MEM Ptr: %1.0f\n', medusaDataGetPtr( psd.rfrx.nodeid+MEDUSA.SUB.RFRX.MEM_CH));
fprintf('RFTx DMA Ptr: %1.0f\n', medusaDataGetPtr( psd.rfrx.nodeid+MEDUSA.SUB.RFTX.DMA_CH));
fprintf('RFTx MEM Ptr: %1.0f\n', medusaDataGetPtr( psd.rfrx.nodeid+MEDUSA.SUB.RFTX.MEM_CH));
end
	
% psdPlotOV(100,psd,0,-0.1);
% refresh(100);
% beep
% 
% if(1)
%  	psdPlotRX(psd.id+10,psd);
%   psd = psdRecon2dft(psd);
% end
%% 
















%%
data = psd.rfrx.data;
totpoints = numel(data);
points = totpoints/Ntr;
% for n = 1:points
%     ave(n) = mean(data(1+(n-1):points:end));
% end
    
datagrid = ones(points, Ntr);
for n = 1:Ntr
    datagrid(:,n) = data((n-1)*points+1:n*points);
end




smpperiod = 1/psd.rfrx.smpclk;

time_tot = (smpperiod:smpperiod: totpoints*smpperiod);
time = (smpperiod:smpperiod:points*smpperiod);

freq_axis = .001*[-ceil(points/2/downsampling_factor):1:floor(points/2/downsampling_factor)-1]*psd.rfrx.smpclk/points;




%apodize FID

dataout = mean(datagrid,2);
dataout_raw = dataout;
% dataout = dataout.*exp(-0*[1:points].'./(points/2));  % set strength of apodization

% figure;
% for n = 1:Ntr
% plot(time,mean(real(datagrid(:,(1:n))),2));
% pause(.1);
% end5

% DC correction
dataout = dataout;

if apodization_switch == 1
    dataout = dataout.*exp(-time.'/(.015));
else
end

complex_spec = (fftshift(fft(fftshift(dataout(1:downsampling_factor:end)))));
spec = abs(fftshift(fft(fftshift(dataout(1:downsampling_factor:end))))).';

if numel(spec) > numel(freq_axis)
   spec = spec(1:numel(freq_axis));
end


if num_flips > 1
    disp(['size freq_axis ', num2str(size(freq_axis))])
    disp(['size spec ', num2str(size(spec))])
plot(H.projection_plot,freq_axis,spec);
[Y I] = max(spec);   freq_peak = freq_axis(I);  Y_all(ff,ii) = Y;  I_all(ff,ii) = I;
if ii == 1, max_amp = Y; end
    if I_all(ff,ii) < 10, I_all(ff,ii) = I_all(ff,ii)+20; end
    if I_all(ff,ii) > numel(spec)-10, I_all(ff,ii) = I_all(ff,ii)-20; end
int_spec(ff) = sum(spec(I_all(ff,ii)-3:I_all(ff,ii)+3));
axis(H.projection_plot,[freq_axis(1) freq_axis(end) 0 1.25*max_amp])
xlabel(H.projection_plot,'freq(Hz)')
noise = (complex_spec(10:round(numel(complex_spec)./6)));
noisestd = std(abs(noise));
SNR(ii) = max(spec)/noisestd;
%title(['FID spectrum, peak ',num2str(max(abs(spec))), ', noise std = ', num2str(noisestd),', SNR = ', num2str(SNR(ii))])
fo_actual = freq_peak+psd.rfrx.freq;
title(H.projection_plot,['frequency spectrum, SNR = ', num2str(SNR(ii))]);

datacursormode on 
else
    datacursormode off
end
%figure; plot(time(1:6250), abs(data(points:points*2-1)));




if ii==1, [Y2 I2] = max(abs(dataout)); end

[temp1 temp2] = max(abs(dataout(10)));  Yt(ff) = temp1;

if num_flips > 1,
    plot(H.readout_plot,[time.' time.'], [abs(dataout) real(dataout)])
axis(H.readout_plot,[time(1) time(end) -1.25*Y2 1.25*Y2]), 
xlim(H.readout_plot,[0,time(points)])
xlabel(H.readout_plot,'time (s)');
xlabel(H.projection_plot,'freq (KHz)');

%ylabel('?')'
title(H.readout_plot,'free induction decay');
%title(H.projection_plot,'frequency spectrum');

pause(1e-9)
datacursormode on
end



pause(.01)


if num_flips > 1
   
    plot(H.flip_angle_plot,rftx_amp(1:ff),int_spec,'o')
    title(H.flip_angle_plot,['pulse length is ',num2str((rftx_time*1000)),' ms']),pause(1e-6)
    xlabel(H.flip_angle_plot,'transmit amplitude')
    ylabel(H.flip_angle_plot,'relative signal amplitude')
    
    datacursormode on;
    
end

%figure; 5plot(abs(fftshift(fft(ave))))

if num_flips > 1, toc, pause(tr - toc); end
ff = ff+1;
end  % flip angle loop
end  % reps

%FID.data_all(:,aa) = dataout;

end  % averages

FID.data_ave = mean(dataout,2);


FID.data = dataout;
FID.time = time;
FID.spec = spec;
FID.freq_axis = freq_axis;

% 
% else   % debug mode
%     
%     FID.data = 0;
%     FID.time = 0;
%     FID.spec = 0;
%     FID.freq_axis = 0;
%     
% end




%disp(['Average SNR = ', num2str(mean(SNR))]);

