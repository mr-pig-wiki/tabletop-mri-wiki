
psdgen_rftest
psdBinWrite(psd, 'scan_rftest');

% run scan from generated files using external 'medusasx' program
fprintf('---------------------------------------------------------\n');
fprintf('Running Scan....\n');

% NOTE: it's possible to call medusasx from within matlab, but it seems to
% run slower, or less reliably.  This is why "manual" run has been selected
% below.

manualrun = 1;

if(manualrun == 1)
	fprintf(' -- Manual run mode has been selected.\n');
	fprintf(' -- Please open a command prompt and go to folder: .../medusa/matlab/ops_ge/psd\n')
	fprintf(' -- Then run:  >medusasx.exe scan_ext\n\n');
	fprintf('When medusasx terminates, come back here and press any key to continue.\n')
	pause
else
	% start the scan using 'medusasx' program (run command-line prog from within Matlab)
	fprintf('Using automatic execution of medusasx from within Matlab.\n');
	system('psd\medusasx psd\scan_rftest');
	%system( ['psd\medusasx psd\' extfile] );
end
fprintf('---------------------------------------------------------\n');


psd = psdBinReadRx(psd, 'scan_rftest');

fprintf('Signal strength (Peak): %6.0f dB\n', 20*log10( max( abs(psd.rfrx.data*32768) / 32768)) );
fprintf('Signal strength (Mean): %6.0f dB\n', 20*log10( mean(abs(psd.rfrx.data*32768) / 32768)) );

psdPlotOV(100,psd,0,-0.1);

figure(200)
hold off
plot(0:(length(psd.rfrx.data)-1), real(psd.rfrx.data), 'b');
hold on
plot(0:(length(psd.rfrx.data)-1), imag(psd.rfrx.data), 'r');
grid off
axis([0 length(psd.rfrx.data)-1 -1 +1])
legend('I','Q');
