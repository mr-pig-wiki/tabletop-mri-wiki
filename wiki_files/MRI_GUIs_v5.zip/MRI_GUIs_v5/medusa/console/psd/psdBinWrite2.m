function psdBinWrite2(psd, filename)
% function psdBinWrite2(psd, filename)
% write PSD as binary files (for use with 'medusasx')
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% setup output fid
%fid = MEDUSA.FID;
fid = 1;

% prepare PSD data
fprintf(fid,'Preparing PSD data...');
psddata = [ psd.ctrl.nodeid psd.ctrl.smpclk psd.ctrl.trlength psd.ctrl.ntrs ...
			psd.grad.nodeid psd.grad.smpclk psd.grad.start psd.grad.length ...
			psd.rftx.nodeid psd.rftx.smpclk psd.rftx.start psd.rftx.length psd.rftx.freq psd.rftx.gain ...
			psd.rfrx.nodeid psd.rfrx.smpclk psd.rfrx.start psd.rfrx.length psd.rfrx.freq psd.rfrx.gain ...
		];
% save psd data
fprintf(fid,'Writing PSD file...');
fid = fopen(['psd/' filename '_psd.bin'],'wb','n'); % n=native endian, b=big endian
stat = fwrite(fid, psddata, 'uint32');
fclose(fid);
fprintf(fid,'done.\n');


fprintf(fid,'Preparing RFTX data...');
% translate data into DDS format
% 12-bit amplitude (0-4095)
% 14-bit phase (0-16384)
txdata = uint16([abs(psd.rftx.data)*4095; mod(round(angle(psd.rftx.data)*16384/(2*pi)), 16384);]);
txdata = (reshape(txdata,size(txdata,1)*size(txdata,2),1));
% save rftx data
fprintf(fid,'Writing RFTX file (%1.0f samples)...', length(txdata)/2);
fid = fopen(['psd/' filename '_rftx.bin'],'wb','n'); % n=native endian, b=big endian
stat = fwrite(fid, txdata, 'uint16');
fclose(fid);
clear txdata;
fprintf(fid,'done.\n');

fprintf(fid,'Preparing GRAD data...');
% translate data into gradient format
%psd.grad.data(1,:) = mod((psd.grad.data(1,:)*32767) + 32768, 65536);
%psd.grad.data(2,:) = mod((psd.grad.data(2,:)*32767) + 32768, 65536);
%psd.grad.data(3,:) = mod((psd.grad.data(3,:)*32767) + 32768, 65536);
%psd.grad.data(4,:) = mod((psd.grad.data(4,:)*32767) + 32768, 65536);
psd.grad.data(1:4,:) = (psd.grad.data(1:4,:)*32767);
psd.grad.data = (reshape(psd.grad.data,size(psd.grad.data,1)*size(psd.grad.data,2),1));

% save rftx data
fprintf(fid,'Writing GRAD file (%1.0f samples)...', length(psd.grad.data)/5);
fid = fopen(['psd/' filename '_grad.bin'],'wb','n'); % n=native endian, b=big endian
stat = fwrite(fid, psd.grad.data, 'int16');
fclose(fid);
fprintf(fid,'done.\n');

%txdata(500000+(1:20))
%grdata(1:50)
