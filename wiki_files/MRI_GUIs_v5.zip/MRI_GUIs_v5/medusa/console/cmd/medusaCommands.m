% Medusa Command Codes and Constants
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global MEDUSA;

% Text Output FID for all Medusa Matlab functions
%MEDUSA.FID = 0;	% NULL (no output)
MEDUSA.FID = 1;		% STDOUT (default)
%MEDUSA.FID = 2;	% STDERR

% ----- Command codes -----
% command code fields
MEDUSA.CMD.OPCODE			= hex2dec('0FFF');
MEDUSA.CMD.WRITE			= hex2dec('0000');
MEDUSA.CMD.READ				= hex2dec('8000');

% system commands
MEDUSA.CMD.SYNC				= hex2dec('007F');
MEDUSA.CMD.ID				= hex2dec('007E');
MEDUSA.CMD.NOP				= hex2dec('007D');
MEDUSA.CMD.LOOPBACK			= hex2dec('007C');
MEDUSA.CMD.RESET			= hex2dec('007B');

% general commands
MEDUSA.CMD.OPSTATE			= hex2dec('0000');
MEDUSA.CMD.STARTTXRX		= hex2dec('0001');
MEDUSA.CMD.WRITETXBUFFER	= hex2dec('0002');
MEDUSA.CMD.READRXBUFFER		= hex2dec('0003');

% general module commands
MEDUSA.CMD.TRLENGTH			= hex2dec('0004');
MEDUSA.CMD.TRINTERVAL		= hex2dec('0005');
MEDUSA.CMD.SAMPFREQ			= hex2dec('0006');

% gating
MEDUSA.CMD.GATE0			= hex2dec('000C');
MEDUSA.CMD.GATE1			= hex2dec('000D');
MEDUSA.CMD.GATE2			= hex2dec('000E');
MEDUSA.CMD.GATE3			= hex2dec('000F');
% RF TX
MEDUSA.CMD.DDSFREQ			= hex2dec('0010');
MEDUSA.CMD.DDSPHASE			= hex2dec('0011');
MEDUSA.CMD.DDSAMPL			= hex2dec('0012');
MEDUSA.CMD.DDSSAMPFREQ		= hex2dec('0013');
MEDUSA.CMD.DDSFREQDIV		= hex2dec('0014');
MEDUSA.CMD.DDSBUFSIZE		= hex2dec('0015');
MEDUSA.CMD.RFTXGAIN			= hex2dec('0016');
% RF RX
MEDUSA.CMD.DDRFREQ			= hex2dec('0020');
MEDUSA.CMD.DDRPHASE			= hex2dec('0021');
MEDUSA.CMD.DDRDECSCALE1		= hex2dec('0022');
MEDUSA.CMD.DDRDECSCALE2		= hex2dec('0023');
MEDUSA.CMD.DDRDEC3			= hex2dec('0024');
MEDUSA.CMD.DDRFREQDIV		= hex2dec('0025');
MEDUSA.CMD.DDRBUFSIZE		= hex2dec('0026');
MEDUSA.CMD.RXFILTER			= hex2dec('0027');
% Gradient
MEDUSA.CMD.GRADDIRWRITE		= hex2dec('0030');
MEDUSA.CMD.GRADSHIM			= hex2dec('0031');
% Controller
MEDUSA.CMD.CTRLSYSCLK		= hex2dec('0040');
MEDUSA.CMD.TRCOUNT			= hex2dec('0041');
MEDUSA.CMD.BUFFERLEVEL		= hex2dec('0048');
MEDUSA.CMD.DMATRANSFER		= hex2dec('0049');
% Raw commands
MEDUSA.CMD.RAWREG			= hex2dec('0050');
MEDUSA.CMD.RAWREG32			= hex2dec('0051');
MEDUSA.CMD.RAWADDR			= hex2dec('0052');
MEDUSA.CMD.RAWDATA			= hex2dec('0053');
MEDUSA.CMD.RAWREGCLRBIT		= hex2dec('0054');
MEDUSA.CMD.RAWREGSETBIT		= hex2dec('0055');
MEDUSA.CMD.RAWDATAINC		= hex2dec('0056');
MEDUSA.CMD.RAWADDRINC		= hex2dec('0057');
MEDUSA.CMD.MSYNC			= hex2dec('0058');
MEDUSA.CMD.SAMPLEBUFFER		= hex2dec('0059');
MEDUSA.CMD.SPECTRUMSCAN		= hex2dec('005A');
MEDUSA.CMD.VECTORMEASURE	= hex2dec('005B');
MEDUSA.CMD.RUNSTATUS		= hex2dec('005C');
MEDUSA.CMD.I2C				= hex2dec('005D');
MEDUSA.CMD.MUX				= hex2dec('005E');
MEDUSA.CMD.PGA				= hex2dec('005F');
MEDUSA.CMD.GPIODATA			= hex2dec('0060');
MEDUSA.CMD.GPIODIR			= hex2dec('0061');
MEDUSA.CMD.GPIOADC			= hex2dec('0062');
MEDUSA.CMD.RFPHASESYNC		= hex2dec('0063');

% Data transfer
MEDUSA.DATA.RXSAMPLES		= hex2dec('0080');
MEDUSA.DATA.TXSAMPLES		= hex2dec('0090');
MEDUSA.DATA.GRSAMPLES		= hex2dec('00A0');

% module register address map
% main registers
MEDUSA.REG.MAIN.ID			= hex2dec('0000');
MEDUSA.REG.MAIN.LED			= hex2dec('0001');
MEDUSA.REG.MAIN.CONF		= hex2dec('0002');
MEDUSA.REG.MAIN.GATE		= hex2dec('0003');
% memory portal(s)
MEDUSA.REG.IOMEM0.DATA		= hex2dec('0010');
MEDUSA.REG.IOMEM0.DATAINC	= hex2dec('0011');
MEDUSA.REG.IOMEM0.ADDR		= hex2dec('0012');
MEDUSA.REG.IOMEM0.ADDRLO	= hex2dec('0012');
MEDUSA.REG.IOMEM0.ADDRHI	= hex2dec('0013');
MEDUSA.REG.IOMEM1.DATA		= hex2dec('0014');
MEDUSA.REG.IOMEM1.DATAINC	= hex2dec('0015');
MEDUSA.REG.IOMEM1.ADDR		= hex2dec('0016');
MEDUSA.REG.IOMEM1.ADDRLO	= hex2dec('0016');
MEDUSA.REG.IOMEM1.ADDRHI	= hex2dec('0017');
% DMA controller(s)
MEDUSA.REG.DMA0.SRCADDR		= hex2dec('0020');
MEDUSA.REG.DMA0.DSTADDR		= hex2dec('0021');
MEDUSA.REG.DMA0.CTRL		= hex2dec('0023');
MEDUSA.REG.DMA1.SRCADDR		= hex2dec('0024');
MEDUSA.REG.DMA1.DSTADDR		= hex2dec('0025');
MEDUSA.REG.DMA1.CTRL		= hex2dec('0027');
% TR controller
MEDUSA.REG.TRCTRL.CTRL		= hex2dec('0030');
MEDUSA.REG.TRCTRL.STAT		= hex2dec('0031');
MEDUSA.REG.TRCTRL.SMPCLKCTRL= hex2dec('0032');
MEDUSA.REG.TRCTRL.TRCOUNT	= hex2dec('0033');
MEDUSA.REG.TRCTRL.TRLEN		= hex2dec('0034');
MEDUSA.REG.TRCTRL.TRLENLO	= hex2dec('0034');
MEDUSA.REG.TRCTRL.TRLENHI	= hex2dec('0035');
MEDUSA.REG.TRCTRL.TRPOS		= hex2dec('0036');
MEDUSA.REG.TRCTRL.TRPOSLO	= hex2dec('0036');
MEDUSA.REG.TRCTRL.TRPOSHI	= hex2dec('0037');

% RF Module specific
MEDUSA.REG.RF.RXDI			= hex2dec('0040');
MEDUSA.REG.RF.RXDQ			= hex2dec('0041');
MEDUSA.REG.RF.TXDIA			= hex2dec('0048');
MEDUSA.REG.RF.TXDQA			= hex2dec('0049');
MEDUSA.REG.RF.TXDPHASE		= hex2dec('004A');

% Gradient Module specific
MEDUSA.REG.GRAD.DAC0		= hex2dec('0040');
MEDUSA.REG.GRAD.DAC1		= hex2dec('0041');
MEDUSA.REG.GRAD.DAC2		= hex2dec('0042');
MEDUSA.REG.GRAD.DAC3		= hex2dec('0043');
MEDUSA.REG.GRAD.GATE		= hex2dec('0044');

% Vector Module specific
MEDUSA.REG.VMOD.DAC0I		= hex2dec('0040');
MEDUSA.REG.VMOD.DAC0Q		= hex2dec('0041');
MEDUSA.REG.VMOD.DAC1I		= hex2dec('0042');
MEDUSA.REG.VMOD.DAC1Q		= hex2dec('0043');
MEDUSA.REG.VMOD.DAC2I		= hex2dec('0044');
MEDUSA.REG.VMOD.DAC2Q		= hex2dec('0045');
MEDUSA.REG.VMOD.DAC3I		= hex2dec('0046');
MEDUSA.REG.VMOD.DAC3Q		= hex2dec('0047');
MEDUSA.REG.VMOD.GATE		= hex2dec('0048');

% bit defines Gating
MEDUSA.REG.MAIN.GATE_RFRX				= hex2dec('0001');
MEDUSA.REG.MAIN.GATE_RFTX				= hex2dec('0002');

% bit defines TR controller
MEDUSA.REG.TRCTRL.CTRL_ENABLE			= hex2dec('0001');
MEDUSA.REG.TRCTRL.CTRL_TRIG_SW			= hex2dec('0002');
MEDUSA.REG.TRCTRL.CTRL_TRIG_MSYNC		= hex2dec('0004');
MEDUSA.REG.TRCTRL.CTRL_TR_REPEAT		= hex2dec('0008');
MEDUSA.REG.TRCTRL.CTRL_SMPCLK_RESYNC	= hex2dec('0010');
MEDUSA.REG.TRCTRL.CTRL_MEM0_RESET		= hex2dec('0800');
MEDUSA.REG.TRCTRL.CTRL_MEM1_RESET		= hex2dec('1000');
MEDUSA.REG.TRCTRL.CTRL_MSYNC_OE			= hex2dec('2000');
MEDUSA.REG.TRCTRL.CTRL_SMPCLK_OE		= hex2dec('4000');
MEDUSA.REG.TRCTRL.CTRL_TRCOUNT_INC		= hex2dec('8000');

MEDUSA.REG.TRCTRL.STAT_BUSY				= hex2dec('0001');
MEDUSA.REG.TRCTRL.STAT_BUSY_DMA0		= hex2dec('0002');
MEDUSA.REG.TRCTRL.STAT_BUSY_DMA1		= hex2dec('0004');

% bit defines Vector Modulator Conf
MEDUSA.REG.VMOD.CONF_MSYNC_GATE			= hex2dec('1000');
% bit defines Vector Modulator Gate
MEDUSA.REG.VMOD.GATE_TXGATE0			= hex2dec('0004');
MEDUSA.REG.VMOD.GATE_TXGATE1			= hex2dec('0008');
MEDUSA.REG.VMOD.GATE_TXGATE2			= hex2dec('0010');
MEDUSA.REG.VMOD.GATE_TXGATE3			= hex2dec('0020');
MEDUSA.REG.VMOD.GATE_COILON0			= hex2dec('0040');
MEDUSA.REG.VMOD.GATE_COILON1			= hex2dec('0080');
MEDUSA.REG.VMOD.GATE_COILON2			= hex2dec('0100');
MEDUSA.REG.VMOD.GATE_COILON3			= hex2dec('0200');
MEDUSA.REG.VMOD.GATE_OUTDISABLE			= hex2dec('0800');

% ----- Subchannel contants -----
MEDUSA.SUB.GRAD.CH			= 0;
MEDUSA.SUB.GRAD.DMA_CH		= 0;
MEDUSA.SUB.GRAD.MEM_CH		= 1;

MEDUSA.SUB.VMOD.CH			= 0;
MEDUSA.SUB.VMOD.DMA_CH		= 0;
MEDUSA.SUB.VMOD.MEM_CH		= 1;

MEDUSA.SUB.RFRX.CH			= 0;
MEDUSA.SUB.RFTX.CH			= 1;
MEDUSA.SUB.RFRX.DMA_CH		= 0;
MEDUSA.SUB.RFRX.MEM_CH		= 1;
MEDUSA.SUB.RFTX.DMA_CH		= 2;
MEDUSA.SUB.RFTX.MEM_CH		= 3;

% ----- Command arguments or response fields -----

% OPSTATE arguments
MEDUSA.OPSTATE.IDLE			= hex2dec('00');
MEDUSA.OPSTATE.RXSTREAM		= hex2dec('01');
MEDUSA.OPSTATE.TXRX			= hex2dec('02');
MEDUSA.OPSTATE.TXSETUP		= hex2dec('04');
MEDUSA.OPSTATE.TXTRIG		= hex2dec('06');
MEDUSA.OPSTATE.BUFREADY		= hex2dec('07');

% NODE ID fields
MEDUSA.ID.ADDR_MASK			= hex2dec('00FF');
MEDUSA.ID.TYPE_MASK			= hex2dec('0F00');
MEDUSA.ID.CONTROLLER		= hex2dec('0100');
MEDUSA.ID.RFMODULE			= hex2dec('0200');
MEDUSA.ID.GRADIENTMODULE	= hex2dec('0300');
MEDUSA.ID.VECTORMODULE		= hex2dec('0400');
MEDUSA.ID.AUXMODULE			= hex2dec('0500');
MEDUSA.ID.GATEMODULE		= hex2dec('0600');
MEDUSA.ID.GRGEMODULE		= hex2dec('0700');
MEDUSA.ID.GRVRMODULE		= hex2dec('0800');
% capabilities
MEDUSA.ID.RF_TXABLE			= hex2dec('0001');
MEDUSA.ID.RF_RXABLE			= hex2dec('0002');

MEDUSA.ID.GRAD_CH_MASK		= hex2dec('003F');
MEDUSA.ID.GRAD_MEM_MASK		= hex2dec('03C0');

