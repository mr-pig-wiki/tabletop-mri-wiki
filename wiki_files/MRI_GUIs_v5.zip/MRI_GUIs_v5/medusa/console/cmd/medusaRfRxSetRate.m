function smpclk = medusaRfRxSetRate(nodeid, smpclk, gain, sysclk)
% function smpclk = medusaRfRxSetRate(nodeid, smpclk, gain, sysclk)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

% determine decimations from table
% assumes 50MHz sysclk
smptable = [500000 	 2  5   10; ...
			250000 	 4  5   10; ...
			125000 	 4  10  10; ...
			62500 	 8  10  10; ...
			31250 	 8  20  10; ...
			15625 	16  20  10; ...
			7812.5 	16  20  20; ];

%dec1 = 2; scale1 = 1; dec2 = 5; scale2 = 4; dec3 = 10; % 500000
%dec1 = 4; scale1 = 2; dec2 = 5; scale2 = 4; dec3 = 10; % 250000
%dec1 = 4; scale1 = 2; dec2 = 10; scale2 = 8; dec3 = 10; % 125000
%dec1 = 8; scale1 = 4; dec2 = 10; scale2 = 8; dec3 = 10; % 62500
%dec1 = 8; scale1 = 4; dec2 = 20; scale2 = 14; dec3 = 10; % 31250

% lookup sampling frequency
smpidx = find(smpclk == smptable(:,1));
dec1 = smptable(smpidx,2);
dec2 = smptable(smpidx,3);
dec3 = smptable(smpidx,4);
smpclk = sysclk/(dec1*dec2*dec3);

% calculate base scale factors
scale1 = ceil(log2( ((dec1-1)^2)*1.0 ) );
scale2 = ceil(log2( ((dec2)^5)*1.0 ) )-5;

% apply gain
if(ceil(gain/2) <= scale1)
	scale1 = floor(scale1-ceil(gain/2));
	scale2 = floor(scale2-floor(gain/2));
else
	scale2 = floor(scale2-(gain-scale1));
	scale1 = floor(0);
end
totalgain = ceil(gain/2) + floor(gain/2);

medusaRfRxSetDecScale(nodeid, dec1,scale1,dec2,scale2,dec3);

