function time = medusaVmodLoad(nodeid, data, gate)
% function time = medusaVmodLoad(nodeid, data, gate)
% 'data' expected as 4 x row vectors
% 'gate' may be 0 if no extended gating needed
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% mask subchannel bits of NODEID
nodeid = bitand(nodeid, hex2dec('FFFFFF00'));

% reset load address back to start
medusaDataSetPtr(nodeid+MEDUSA.SUB.GRAD.MEM_PTR, 0*1024);
% load gradient data
time = medusaVmodLoadStream(nodeid,data,gate);
% reset load address back to start
medusaDataSetPtr(nodeid+MEDUSA.SUB.GRAD.MEM_PTR, 0*1024);
