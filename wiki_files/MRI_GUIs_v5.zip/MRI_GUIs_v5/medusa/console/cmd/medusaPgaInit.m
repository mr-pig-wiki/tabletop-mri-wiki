function medusaPgaInit(nodeid, addr)
% function medusaPgaInit(nodeid, addr)
%  addr = device address of PGA submodule
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global MEDUSA
global sock

% initialize PGA
%cmdlinkCmd(cmdlinksock, nodeid, 'p', ['i' addr 0]);
% set PGA to disabled
medusaPgaGainSet(nodeid, addr, 0);
