function medusaGpioDirSet(nodeid, port, value)
% function medusaGpioDirSet(nodeid, port, value)
%  port    = device port address, ie. 0,1,2...
%  value   = bitfield direction value to set
%            bitvalue 0 => pin is an input
%            bitvalue 1 => pin is an output
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global MEDUSA
global sock

concmd32(sock, nodeid, MEDUSA.CMD.GPIODIR, [value]);
