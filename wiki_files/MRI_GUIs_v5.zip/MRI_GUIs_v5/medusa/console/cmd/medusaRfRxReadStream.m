function data = medusaRfRxReadStream(nodeid, nsamples)
% function data = medusaRfRxReadStream(nodeid, nsamples)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% mask subchannel bits of NODEID
nodeid = bitand(nodeid, hex2dec('FFFFFF00'));

% read data
nsamples = nsamples*2;
data = concmdRead(sock, nodeid+MEDUSA.SUB.RFRX.MEM_CH, MEDUSA.CMD.RAWDATA, [mod(nsamples,65536) nsamples/65536]);
data = (data(1:2:end)+i*data(2:2:end)) ./ 32767;
