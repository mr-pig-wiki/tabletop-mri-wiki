function medusaMsyncCPU(nodeid)
% function medusaMsyncCPU(nodeid)
%   Triggers an Msync immediately on selected controller under CPU control
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% do MSYNC
concmd(sock, nodeid, MEDUSA.CMD.MSYNC, [0]);
