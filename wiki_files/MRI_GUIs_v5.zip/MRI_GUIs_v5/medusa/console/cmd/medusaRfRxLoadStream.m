function time = medusaRfRxLoadStream(nodeid, data)
% function time = medusaRfRxLoadStream(nodeid, data)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% mask subchannel bits of NODEID
nodeid = bitand(nodeid, hex2dec('FFFFFF00'));

% make sure input is row vector
data = reshape(data,1,length(data));

% translate data into DR format
% 16-bit I-phase amplitude (+/-32767)
% 16-bit Q-phase amplitude (+/-32767)
rxdata = [real(data); imag(data)];
% rescale if data appears to be normalized to 1.0
if( (max(max(rxdata)) <= 1.0) & (min(min(rxdata)) >= -1.0) )
	rxdata = rxdata * 32767;
end
rxdata = reshape(rxdata,1,size(rxdata,1)*size(rxdata,2));

% set nodeid to RX channel
%nodeid = bitand(nodeid, hex2dec('FFFFFFFE'));
% load data
tic;
concmd(sock, nodeid+MEDUSA.SUB.RFRX.MEM_CH, MEDUSA.CMD.RAWDATA, rxdata);
time = toc;
