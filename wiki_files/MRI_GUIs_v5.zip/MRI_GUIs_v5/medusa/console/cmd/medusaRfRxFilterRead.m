function dfilter = medusaRfRxFilterRead(nodeid)
% function dfilter = medusaRfRxFilterRead(nodeid)
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA

% mask subchannel bits of NODEID
nodeid = bitand(nodeid, hex2dec('FFFFFF00'));

% read data
data = concmdRead(sock, nodeid, MEDUSA.CMD.RXFILTER, []);
% normalize from signed 16-bit to +/-1.0
dfilter = data ./ 32767;
