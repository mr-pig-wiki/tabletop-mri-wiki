function freqSmpclkHz = medusaSetSmpclk(nodeid, freqSmpclkHz)
% function freqSmpclkHz = medusaSetSmpclk(nodeid, freqSmpclkHz)
% sets the module's sampling clock (sample rate)
%  - frequency value must be in Hertz
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global sock
global MEDUSA
concmd32(sock, nodeid, MEDUSA.CMD.SAMPFREQ, freqSmpclkHz);
