function value = concmdRead(sock,nodeid,cmd,args)
% function value = concmdRead(sock,nodeid,cmd,[args])
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

global MEDUSA

% issue command
concmd(sock, nodeid, cmd+MEDUSA.CMD.READ, [args]);

% try to get response
value = NaN;
timeout = 50;
while(timeout > 0)
	packet = conmex('read', double(nodeid), 2);
	% if we get an empty packet, wait a moment, and try again
	if(packet == 0)
		pause(0.1);
		timeout = timeout-1;
		continue;
	end
	% if we get what we want, break right away
	if(packet(2) == cmd+MEDUSA.CMD.READ)
		value = packet(3:end);
%		value32(find(value32<0)) = value32(find(value32<0)) + 2^31;
		% breakdown value32's into two value16's
%		valueL = (bitand(value32,hex2dec('0000FFFF'))); 
%		valueH = (bitshift(value32, -16));
		% interleave
%		value(1:2:(length(valueL)*2)) = valueL;
%		value(2:2:(length(valueH)*2)) = valueH;
		value(find(value>32767)) = value(find(value>32767)) - 65536;
		%fprintf('Got packet\n');
		break;
	end
end
