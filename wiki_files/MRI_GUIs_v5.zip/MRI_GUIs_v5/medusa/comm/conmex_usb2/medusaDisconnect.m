% Medusa disconnect script
%
% This is part of the Medusa software suite.
% Pascal Stang, Copyright 2006-2012, All rights reserved.
%
% $LICENSE$

sock = 0;
condisconnect(sock);
