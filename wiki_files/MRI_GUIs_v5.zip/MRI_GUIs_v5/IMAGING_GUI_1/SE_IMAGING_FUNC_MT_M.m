% spin echo pulse sequence, MIT 6.02M class
% Dec 13, 2012
function [SE] = SE_IMAGING_FUNC_MT_M
global psd
global H


debug_switch = 0;  % set to 1 for debugging mode.  this lets sequence run without the MEDUSA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ================= USER SPECIFIED SEQUENCE PARAMETERS ===================

freq = 1e6*psd.f0;     % set center frequency
te = psd.te_se*1e-3;         % set TE in sec
tr = psd.tr*1e-3;           % set TR is sec
tro = psd.tro*1e-3;        % set readout length in sec

resolution = [floor(tro*psd.grad.smpclk) 64 1];  % set resolution in [readout PE1 PE2] directions

resolution(1) = psd.matrix_size_ro;
resolution(2) = psd.matrix_size_pe1_se;
%resolution(3) = psd.matrix_size_pe1_se;

FOV = [psd.FOV_ro psd.FOV_pe1 psd.FOV_pe2]    % FOV in cm in [readout PE1 PE2]

% set to 'XY' for coronal (XY), 'XZ' for axial (XZ), 'YZ' for sagittal (YZ)
% or reverse these to change the readout direction.  Other dimension is SS/PE2
slice_orientation = psd.slice_orientation;

num_ave = psd.num_ave;         % set number of averages

projection = 0;  %%switch to choose projection versus image
%% ================  END OF USER SPECIFIED PARAMETERS =====================
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Secondary pulse sequence parameters ====================================
tcr = 1e-3;   % crusher duration in sec
% scale crushers relative to readout gradient moment
scale_crushers = [0 0 2]*.2;    % set each channel: [RO PE1 PE2]
%scale_crushers = [1 0 0]*0;    % set each channel: [RO PE1 PE2]

% gradient channel pulse switches  for debugging
ro_switch  = 1;      % set to zero to turn off readout and rewinder gradient
pe1_switch = 1;     % set to zero to turn off PE1 gradient
pe2_switch = 1;     % set to zero to turn off PE2 gradient
% =========================================================================

%% hard-coded sequence parameters =========================================
rftx_time_90 = psd.rftx_time_90;			% set transmit pulse length for 90 deg pulse
rftx_time_180 = psd.rftx_time_180;         % set transmit pulse legnth for 180 deg pulse

tx_gating_time = 0e-6;         % this is the time needed for the gating pulse to enable the power amplifier
% NOTE: the actual pulse duration is shorter than rftx_time by the tx_gating delay

% set RF transmit pulse amplitudes
% CAREFUL DO NOT SET THIS LEVEL ABOVE 0.25 WHEN USING THE TOMCO TX AMPLIFIER!!!
rftx_amp_90 = psd.rftx_amp_90;   rftx_amp_180 = psd.rftx_amp_180;  % if rftx_amp_90 > .25 || rftx_amp_180 > .25, disp('transmit amplitude too high!'),crash, end
% rftx_amp_90 = .175;   rftx_amp_180 = .175*2; % when using Mini-Circuits 1W amp


psd.rfrx.gain = psd.RX_gain;     % adjust MEDUSA receiver gain if necessary
psd.rftx.gain = 0;      % set RF transmitter gain, NOT RELEVANT

tpe = 2e-3;             % set length of phase encode pulse
trew = 2e-3;           % set length of rewinder gradient lobe
pad_time_after_90 = 500e-6;  % set length of pad time after RF90


shims = [psd.shims(1) psd.shims(2) psd.shims(3)];
%figure,plot(shims)
%load shims.mat

gradient_sensitivity_Hz_cm_M = .5*[285000 285000 408300];  % gradient strength in gauss/cm/MEDUSA_unit, include factor of 2 for consistency with homework
gradient_sensitivity_mT_m_M = gradient_sensitivity_Hz_cm_M/425.7;


if projection == 1
        grad_switch = [1 0 0];
% elseif resolution(2) == 16
%     gradient_sensitivity_G_cm = [3*.5 3/4*.08 3*.017];   %32 phase encodes
% elseif resolution(2) == 32
%     gradient_sensitivity_G_cm = [3*.5 3/2*.08 3*.017];   %32 phase encodes
% elseif resolution(2) == 64
%     gradient_sensitivity_G_cm = [3*.5 3*.08 3*.017];   %64 phase encodes
% elseif resolution(2) == 128
%      gradient_sensitivity_G_cm = [3*.5 6*.08 3*.017];   %64 phase encodes
else
    grad_switch = [1 1 1];
end
    
%gradient_sensitivity_G_cm = [283337.4 399633.5 408600.05];  % gradient strength in gauss/cm/MEDUSA_unit
%gradient_sensitivity_G_cm = [3*.5 3*.08 3*.005];   %64 phase encodes
%gradient_sensitivity_G_cm = [3*.5 3/2*.08 3*.005];   %32 phase encodes




gamma = 4.25781e3;	% Hz/gauss
G_max = 5;          % maximum allowable gradient strength in amps
gradient_ramp_time = 200e-6;  % gradient ramp time in ms
gradient_safety_threshold = 1;

%% calculated parameters ==================================================
% groArea = gradient_sensitivity_G_cm(1)*(psd.grad.smpclk/(gamma*FOV(1)));	% readout area
% gpeArea_1 = gradient_sensitivity_G_cm(2)*(psd.grad.smpclk/(gamma*FOV(2)));  % delta_PE1 area
% gpeArea_2 = gradient_sensitivity_G_cm(3)*(psd.grad.smpclk/(gamma*FOV(3)));  % delta_PE2 area

% define slice orientation vector
if     slice_orientation == 'XY', slice_vec = [1 2 3]; ind_x = 1;  ind_y = 2;  ind_z = 3;
elseif slice_orientation == 'XZ', slice_vec = [1 3 2]; ind_x = 1;  ind_y = 3;  ind_z = 2;
elseif slice_orientation == 'YZ', slice_vec = [2 3 1]; ind_x = 3;  ind_y = 1;  ind_z = 2;
elseif slice_orientation == 'YX', slice_vec = [2 1 3]; ind_x = 2;  ind_y = 1;  ind_z = 3;
elseif slice_orientation == 'ZY', slice_vec = [3 2 1]; ind_x = 3;  ind_y = 2;  ind_z = 1; 
elseif slice_orientation == 'ZX', slice_vec = [3 1 2]; ind_x = 2;  ind_y = 3;  ind_z = 1;
end
slice_str(1).orientation = 'readout';
slice_str(2).orientation = 'phase enc.';
slice_str(3).orientation = 'crusher';

%groArea = grad_switch(1)*resolution(1)*resolution(1)/(FOV(1)*gradient_sensitivity_Hz_cm_M(slice_vec(1))*tro);


% gpeArea_1 = grad_switch(2)*psd.grad.smpclk*resolution(2)/(2*FOV(2)*gradient_sensitivity_Hz_cm_M(slice_vec(2)));
gpeArea_2 = grad_switch(3)*psd.grad.smpclk*resolution(3)/(2*FOV(3)*gradient_sensitivity_Hz_cm_M(slice_vec(3)));


%groArea = grad_switch(1)*resolution(1)*resolution(1)/(FOV(1)*gradient_sensitivity_Hz_cm_M(slice_vec(1))*tro);
%groArea = 7000*4.24*(psd.G1_mT_m/gradient_sensitivity_mT_m_M(slice_vec(1)))*tro;

% replacement line for groArea
groArea_ideal = 100* grad_switch(1)* (1/gradient_sensitivity_mT_m_M(slice_vec(1))) * resolution(1)/(psd.FOV_ro);  % WORKING LINE
groArea =  psd.G1_mT_m * tro * psd.grad.smpclk / gradient_sensitivity_mT_m_M(slice_vec(1));


%gpeArea_1 = grad_switch(2)*psd.grad.smpclk*resolution(2)/(2*FOV(2)*gradient_sensitivity_Hz_cm_M(slice_vec(2)));

%gpeArea_1 = (1/resolution(2))*8*800*42570*(psd.G2_mT_m/(resolution(2)/2)/gradient_sensitivity_mT_m_M(slice_vec(2)))*tpe;  % working for N_pe >= 64
% INSERT NEW LINE HERE


% groArea = 0;
% gpeArea_1 = 0;
% gpeArea_2 = 0;

gr_ramp = round((gradient_ramp_time/(1/psd.grad.smpclk))); % gradient trapezoid ramps (# samples to ramp)

% load sequence parameters into PSD structure
psd.rfrx.freq = freq;	  psd.rftx.freq = freq;
psd.ctrl.ntrs = 1;
psd.param.Nro = resolution(1);
psd.param.Npe = 1;
psd.param.tr = tr;
psd.ctrl.trlength = tr*psd.ctrl.smpclk;
psd.param.te = te;
psd.param.tpe = tpe;
psd.param.tro = tro;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initialize MEDUSA console
psd.id = 100;   psd.fid = 0;

% initialize console parameters
% setup NodeID addresses
psd.ctrl.nodeid = hex2dec('011000');	% Medusa Controller
psd.rfrx.nodeid = hex2dec('010000');	% Medusa RF module for Rx
psd.rftx.nodeid = hex2dec('010000');	% Medusa RF module for Tx
psd.grad.nodeid = hex2dec('010800');	% Medusa Gradient module



%% Define pulses and readout

% define transmit pulses

pulse_RF_90 = [rftx_amp_90*ones(1, (rftx_time_90-tx_gating_time)*psd.rftx.smpclk)];  % define shape of 90 deg RF pulse
pulse_RF_180 = [1i*rftx_amp_180*ones(1, (rftx_time_180-tx_gating_time)*psd.rftx.smpclk)]; % define shape of 180 deg RF pulse

% define gradient pulses using gradient moments
gro_rewinder = [grLobeTrap(groArea/2, gr_ramp, trew, psd.grad.smpclk)]; % preparation windup for readout
gro_readout = [grLobeTrap(groArea,   gr_ramp, tro+2*gr_ramp/psd.grad.smpclk, psd.grad.smpclk)];  % readout gradient pulse

gpe2_delta = [grLobeTrap(gpeArea_2, gr_ramp, tpe, psd.grad.smpclk)];  % delta_k PE2 gradient pulse

if resolution(3) == 1, gpe2 = 0; end

% define crusher gradient pulses
crusher_RO = grLobeTrap(abs(groArea)*scale_crushers(1), gr_ramp, tcr, psd.grad.smpclk);
crusher_PE1 = grLobeTrap(abs(groArea)*scale_crushers(2), gr_ramp, tcr, psd.grad.smpclk);
%crusher_PE2 = grLobeTrap(abs(groArea)*scale_crushers(3), gr_ramp, tcr, psd.grad.smpclk);
crusher_PE2 = grLobeTrap(1, gr_ramp, tcr, psd.grad.smpclk);   % JPS 03/2015 hard code crusher gradient moment; helps with plotting


% create empty vectors for each gradient waveform
gro = zeros(1,floor(tr*psd.grad.smpclk)-1);
gpe1 = zeros(1,floor(tr*psd.grad.smpclk)-1);
gpe2 = zeros(1,floor(tr*psd.grad.smpclk)-1);


% add ssi
ssi = 0*gro.'; ssi(1) = hex2dec('1000')/32767;	% create start-of-sequence flag
% add gating
gate = 0*gro.';




%% set sequence event timing

psd.rftx.data = [];
psd.rftx.data = [psd.rftx.data eps*ones(1,round(tx_gating_time*psd.rftx.smpclk))];
psd.rftx.data = [psd.rftx.data pulse_RF_90];
psd.rftx.data = [psd.rftx.data zeros(1,round((te/2-rftx_time_90/2-rftx_time_180/2-tx_gating_time)*psd.rftx.smpclk))];
psd.rftx.data = [psd.rftx.data eps*ones(1,round(tx_gating_time*psd.rftx.smpclk))];
psd.rftx.data = [psd.rftx.data pulse_RF_180];
psd.rftx.data = [psd.rftx.data 0 0 0 0];
% 
% dummy 180 that is the second pulse in an echo train
% psd.rftx.data = [psd.rftx.data zeros(1,round((te-rftx_time_180-tx_gating_time)*psd.rftx.smpclk))];
% psd.rftx.data = [psd.rftx.data eps*ones(1,round(tx_gating_time*psd.rftx.smpclk))];
% psd.rftx.data = [psd.rftx.data -1i*pulse_RF_180];
% psd.rftx.data = [psd.rftx.data 0];




psd.rfrx.start = round( (te - .5*tro + 2*rftx_time_90/2)*psd.rfrx.smpclk)-1;
psd.rfrx.length = resolution(1);
psd.rfrx.data = zeros(1,psd.rfrx.length);
% transmitter
psd.rftx.start = 1;
psd.rftx.length = length(psd.rftx.data);

% define readout pulse start and end times
readout_start_ind = round((te-tro/2 + rftx_time_90/2)*psd.grad.smpclk) - gr_ramp - 1;
readout_end_ind = readout_start_ind + numel(gro_readout) - 1;

% add readout gradient into sequence
gro(readout_start_ind:readout_end_ind) = gro_readout;

% define PE pulse start and end times
pe_start_ind = ceil((rftx_time_90 + pad_time_after_90)*psd.grad.smpclk);
%pe_end_ind = pe_start_ind + numel(gpe1_delta) - 1;
pe_end_ind = pe_start_ind + ceil(tpe*psd.grad.smpclk) - 1;



% add rewinder to sequence
gro(pe_start_ind:pe_start_ind+numel(gro_rewinder)-1) = gro_rewinder;

% switches to disable (or scale) gradient pulses
gro = ro_switch*gro;

% set crusher start and end indices within gradient vector
crusher_pre_start_ind = ceil((rftx_time_90/2 + te/2 - tcr - tx_gating_time -400e-6)*psd.grad.smpclk)-1;
crusher_pre_end_ind = crusher_pre_start_ind + numel(crusher_RO)-1;

crusher_post_start_ind = ceil((rftx_time_90/2 + te/2 + rftx_time_180 - tx_gating_time + 400e-6)*psd.grad.smpclk)-1;
crusher_post_end_ind = crusher_post_start_ind + numel(crusher_RO)-1;





%% check minimum TE and break out of sequence if timing is incorrect


data = zeros((resolution));
data_all = zeros(resolution(1),resolution(2),resolution(3),num_ave);

% generate normalized phase encode steps
pe1_steps = [-1:2/(resolution(2)):1-2/(resolution(2))];
if resolution(3) == 1, pe2_steps = 0; else pe2_steps = [-1:2/(resolution(3)):1-2/(resolution(3))]; end


%%   LOOP THROUGH SEQUENCE CALLS (PHASE ENCODES, ETC.)
for vv = 1:num_ave
for aa=1:resolution(3)  % outer loop, PE2
    for bb=1:resolution(2),  % inner loop, PE1
        if get(H.toggle_stop_button,'Value') == 0

        if aa==1 && bb==1, tic, end
        disp(['acquiring PE1=',num2str(bb), ', PE2=',num2str(aa)])

clear psd.grad.data        
        
    %    psd.rftx.data = psd.rftx.data;
        
      %  gpeArea_1 = (1/resolution(2))*8*800*42570*(psd.G2_mT_m/(resolution(2)/2)/gradient_sensitivity_mT_m_M(slice_vec(2)))*tpe;  % working for N_pe >= 64
        
        gpeArea_1_ideal = 1/2*100*(1/gradient_sensitivity_mT_m_M(slice_vec(2)))* resolution(2)/(psd.FOV_pe1);  % WORKING LINE
        gpeArea_1 = psd.G2_mT_m * tpe *psd.grad.smpclk / gradient_sensitivity_mT_m_M(slice_vec(2));
        
        gpeArea_1 = gpeArea_1* pe1_steps(bb);
        % add PEs to sequence
        gpe1_delta = [grLobeTrap(gpeArea_1, gr_ramp, tpe, psd.grad.smpclk)];	% delta_k PE1 gradient pulse
        gpe1(pe_start_ind:pe_end_ind) = gpe1_delta;
        
        gpe2(pe_start_ind:pe_end_ind) = gpe2_delta;
        
        gpe1 = pe1_switch*gpe1;
        gpe2 = pe2_switch*gpe2;

% set up readout, PE, and PE2 directions
    gx_temp = gro';
    if resolution(2) > 1, gy_temp = gpe1'; else gy_temp = 0*gpe1'; end
    if resolution(3) > 1, gz_temp = gpe2' * pe2_steps(aa); else gz_temp = 0*gpe2'; end
    temp = [gx_temp.'; gy_temp.'; gz_temp.'];
    %psd.grad.data = [temp(ind_x,:); temp(ind_x,:); temp(ind_x,:); ssi.'; gate.']; 
     psd.grad.data = [temp(ind_x,:); temp(ind_y,:); temp(ind_z,:); ssi.'; gate.']; % working version of this line




% insert crushers into sequence
temp_crusher = [crusher_RO; crusher_PE1; crusher_PE2];

psd.grad.data(1,crusher_pre_start_ind:crusher_pre_end_ind) = psd.grad.data(1,crusher_pre_start_ind:crusher_pre_end_ind) + temp_crusher(ind_x,:);
psd.grad.data(2,crusher_pre_start_ind:crusher_pre_end_ind) = psd.grad.data(2,crusher_pre_start_ind:crusher_pre_end_ind) + temp_crusher(ind_y,:);
psd.grad.data(3,crusher_pre_start_ind:crusher_pre_end_ind) = psd.grad.data(3,crusher_pre_start_ind:crusher_pre_end_ind) + temp_crusher(ind_z,:);

psd.grad.data(1,crusher_post_start_ind:crusher_post_end_ind) = psd.grad.data(1,crusher_post_start_ind:crusher_post_end_ind) + temp_crusher(ind_x,:);
psd.grad.data(2,crusher_post_start_ind:crusher_post_end_ind) = psd.grad.data(2,crusher_post_start_ind:crusher_post_end_ind) + temp_crusher(ind_y,:);
psd.grad.data(3,crusher_post_start_ind:crusher_post_end_ind) = psd.grad.data(3,crusher_post_start_ind:crusher_post_end_ind) + temp_crusher(ind_z,:);





% add in shim settings -- does not depend on slice orientation
psd.grad.data(1,:) = psd.grad.data(1,:) + shims(1);
psd.grad.data(2,:) = psd.grad.data(2,:) + shims(2);
psd.grad.data(3,:) = psd.grad.data(3,:) + shims(3);

% define total number of gradient points
psd.grad.start = 1;
psd.grad.length = length(psd.grad.data);


if max(max(abs(psd.grad.data))) > gradient_safety_threshold
   fprintf(['Error: \tgradient strength too high\n'])
crash
end



% fill in zeros for remainder of rftx and rfrx

%dummy = zeros(1,round(tr*psd.rftx.smpclk)-1);
%dummy(1:numel(psd.rftx.data)) = psd.rftx.data;
%psd.rftx.data = dummy;





%% end pulse sequence specification


%% check sequence parameters for consistency ==============================

if te/2 < rftx_time_90/2 + tpe + rftx_time_180/2
    fprintf(['ERROR:\t TE = ',num2str(te),' is too short for the specified RF pulse and phase encode lobe durations\n']) 
    crash
end

if te/2 < rftx_time_90/2 + trew + rftx_time_180/2
    fprintf(['ERROR:\t TE = ',num2str(te),' is too short for the specified RF pulse and rewind gradient lobe durations\n']);
    crash
end

if te/2 < rftx_time_180/2 + tro/2
    fprintf(['ERROR:\t TE = ',num2str(te),' is too short for the specified RF pulse and readout gradient lobe durations\n']);
    crash
end

if tr < te + tro/2 + rftx_time_90/2
   fprintf(['ERROR:\t TR = ',num2str(tr),' is too short for the specified TE\n']);
   crash 
end

%% run sequence ===========================================================
if debug_switch == 0
  %  medusaReset(psd.ctrl.nodeid)
 %  medusaRfTxSetPhase(psd.rftx.nodeid,0);
 %  medusaRfRxSetPhase(psd.rfrx.nodeid, 0);
   %medusaRfTxPhaseSync(psd.ctrl.nodeid)
   
    medusaPsdConfigure(psd);
psd = medusaPsdRun(psd);  end_time = toc; pause((tr-end_time)), tic
else
    psd.rfrx.data(:) = 0;   psd.rfrx.data(round(numel(psd.rfrx.data)/2)) = 1;
     end_time = toc; pause((tr-end_time)), tic
end
% =========================================================================
 
data(:,bb,aa) = psd.rfrx.data;
data_all(:,bb,aa,vv) = data(:,bb,aa);


 %  if resolution(2) > 1, figure(8),subplot(1,2,1),imagesc(abs(data)),pause(1e-9),title(['k-space for slice',num2str(aa)]),subplot(1,2,2),imagesc(abs(fftshift(fft2(fftshift(data))))),end

% compute parameters for plotting 
num_rfrx_points = numel(psd.rfrx.data(1,:));
rx_time = (0:1:num_rfrx_points-1)/psd.rfrx.smpclk;
freq_proj = (-floor(num_rfrx_points/2):1:ceil(num_rfrx_points/2)-1)*psd.rfrx.smpclk/num_rfrx_points;

grad_time = (0:1:numel(psd.grad.data(1,:))-1)/psd.grad.smpclk;
tx_time = (0:1:numel(psd.rftx.data)-1)/psd.rftx.smpclk;
relevant_range_grad = grad_time(1:round(numel(rx_time)+te/tr*numel(grad_time)));
relevant_range_tx = tx_time(1:round(1.25*te/tr*numel(tx_time)));

psd.grad.data = psd.grad.data(:,1:numel(relevant_range_grad));  % eliminate unnecessary zeros in gradient vector

if resolution(3) == 1
    
    plot(H.readout_plot,rx_time,abs(squeeze(data_all(:,bb,1,vv)))),%plot(H.readout_plot,rx_time,real(squeeze(data_all(:,bb,1,vv))),'r'),hold off
    
%    axis([rx_time(1) rx_time(end) 0 1.5*max(max(abs(squeeze(data_all(:,bb,1,vv)))))])
    if num_ave > 1
       hold off,plot(H.projection_plot,freq_proj,mean(abs(fftshift(fft(squeeze(data_all(:,bb,aa,:)),[],1),1)),2))
        axis(H.projection_plot,[freq_proj(1) freq_proj(end) 0 1.25*max(mean(abs(fftshift(fft(squeeze(data_all(:,bb,aa,:)),[],1),1)),2))])
        
        
    else
      if resolution(2) == 1
        hold off,plot(H.projection_plot,freq_proj,mean(abs(fftshift(fft(squeeze(data_all(:,bb,aa,vv)),[],1),1)),2))
        axis(H.projection_plot,[freq_proj(1) freq_proj(end) 0 1.25*max(mean(abs(fftshift(fft(squeeze(data_all(:,bb,aa,vv)),[],1),1)),2))])
      else
        plot(H.projection_plot,freq_proj,abs(fftshift(fft(data_all(:,bb,1,vv),[],1),1)))
        axis(H.projection_plot,[freq_proj(1) freq_proj(end) 0 1.25*max(mean(abs(fftshift(fft(squeeze(data_all(:,bb,aa,vv)),[],1),1)),2))])
      end, hold off
    end
        title(H.readout_plot,'readout'), title(H.projection_plot,'1-D projection')

imagesc(flipdim(abs(data),1),'Parent',H.kspace_plot),title(H.kspace_plot,'k-space data')

im = abs(fftshift(fft2(fftshift(data))));

% removed 5/5/2013 so that students can't see images in GUI
% imagesc(flipdim(im,1),'Parent',H.image_plot),
% title(H.image_plot,'object image')


% 
% if im(1+floor(numel(im(:,1))/2),1+floor(numel(im(1,:))/2)) > 10.*mean(mean(im))
%     scale_max = 10.*mean(mean(im));
%     set(H.image_plot,'CLim',[0 scale_max])
% 
% else
% end



datacursormode on;


ADC_plot = zeros(1,numel(relevant_range_grad));
ADC_vec = psd.rfrx.start:psd.rfrx.start+psd.rfrx.length-1;
ADC_plot(ADC_vec) = .5*max(gro);

temp50 = zeros(1,numel(relevant_range_grad));  temp50(1:numel(psd.rftx.data)) = abs(psd.rftx.data);

clear plot_block
plot_block = real([psd.grad.data(1:3,1:numel(relevant_range_grad)).' temp50.' ADC_plot.']);
plot_block(:,1) = plot_block(:,1) * gradient_sensitivity_mT_m_M(1);
plot_block(:,2) = plot_block(:,2) * gradient_sensitivity_mT_m_M(2);
plot_block(:,3) = plot_block(:,3) * gradient_sensitivity_mT_m_M(3);
plot_block(:,4) = 15*plot_block(:,4);
plot_block(:,5) = plot_block(:,5) * .5*gradient_sensitivity_mT_m_M(1);
%figure(90),plot(gro(1:500)),pause(1)

plot(H.sequence_plot, relevant_range_grad.*1e3, plot_block),
legend(H.sequence_plot,['G_X: ',slice_str(ind_x).orientation],...
    ['G_Y: ',slice_str(ind_y).orientation],['G_Z: ',slice_str(ind_z).orientation],'RF pulses','Acq. window','Location','NorthEast')
xlabel(H.sequence_plot,'ms'),ylabel(H.sequence_plot,'mT/m'); title(H.sequence_plot,'pulse sequence diagram'),set(H.sequence_plot,'FontSize',8)

 if aa==1  & bb==1 & vv==1
     range_params = [relevant_range_grad(1).*1e3 relevant_range_grad(end).*1e3 -1.5*max(max(abs(plot_block(:,2:end)))) 3*max(max(abs(plot_block(:,2:end))))];
 end
    axis(H.sequence_plot,range_params),pause(1e-9)
 

%plot(H.sequence_plot,relevant_range_grad,psd.grad.data(1:3,1:numel(relevant_range_grad)).')
%hold on,plot(H.sequence_plot,relevant_range_tx,psd.rftx.data(1:numel(relevant_range_tx)),'g'),pause(.0000000001)
%hold on,plot(H.sequence_plot,tx_time,abs(psd.rftx.data)),
%plot(H.sequence_plot,([psd.rfrx.start psd.rfrx.start psd.rfrx.start+psd.rfrx.length-1 psd.rfrx.start+psd.rfrx.length-1])/psd.rfrx.smpclk,[0 .5*max(max(gro))*ones(1,2) 0],'k')

% if aa==1 && bb==1,axis([grad_time(1) te+1.5*tro min(min(psd.grad.data)) .8*max(max(psd.grad.data))]),end

 end
   


        end
    end  % end inner PE loop
end      % end outer PE loop
end





% plots for 2-D acquisitions
% if resolution(3) == 1
% figure(10),subplot(2,2,1),plot(rx_time,abs(data)),hold on,plot(rx_time,real(data),'r')
% subplot(2,2,2),plot(freq_proj,abs(fftshift(fft(data,[],1),1)))
%        axis([freq_proj(1) freq_proj(end) 0 1.25*max(mean(abs(fftshift(fft(squeeze(data_all(:,bb,aa,vv)),[],1),1)),2))])
% 
% subplot(2,2,3),imagesc(flipdim(abs(data),1)),subplot(2,2,4),imagesc(flipdim(abs(fftshift(fft2(fftshift(data)))),1))
% end

% plots for 3-D acquisitions
if resolution(3) ~= 1, im = fftshift(fftn(fftshift(data))); 
%figure(12),for ss=1:resolution(3), imagesc(flipdim(abs(im(:,:,ss)),1)),pause(.75),end
end

if resolution(3) > 1
    
figure;
for ss = 1:resolution(3)
    if resolution(3) < 17
     %       subplot(4,4,ss),imagesc(flipdim(abs(im(:,:,ss)),1))
    elseif resolution(3) >= 17
      %      subplot(8,8),imagesc(flipdim(abs(im(:,:,ss)),1))
        end
end
end


if num_ave > 1 && resolution(3) == 1
    for vv=1:num_ave,temp_im(:,:,vv) = abs(fftshift(fft2(fftshift(squeeze(data_all(:,:,1,vv)))))); end
 %  figure(20),imagesc(flipdim(mean(temp_im,3),1)),colormap(gray)
  %figure(20),imagesc(mean(temp_im,3)),colormap(gray)

   %axis image
end


psd.data = data;
psd.data_ave = mean(data_all,4);

SE = psd;


% 
% 
% 
% fprintf('Plotting...\n')
% %psdPlotRG(100,psd);
% %psdPlotMD(100,psd,0,-0.1);
% psdPlotOV(100,psd,0,-0.1);
% fprintf('----------------------------------------\n')
% 
% 
% 
% 
% 







