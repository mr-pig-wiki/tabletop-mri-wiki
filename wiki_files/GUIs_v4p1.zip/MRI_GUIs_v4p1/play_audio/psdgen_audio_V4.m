
fprintf('---------- AUDIO PSD Generator ----------\n')


temp_path = fileparts(mfilename('fullpath'));
cd(temp_path)

%%  VOLUME CONTROL...  DO NOT EXCEED 0.5
grad_amp = 0.35;
%%


psd.fid = 0;
psd.ctrl.nodeid = medusaNode(1);	% Medusa Controller #1
psd.rfrx.nodeid = medusaNode(1,0);	% Medusa RF module for Rx (module address 0)
psd.rftx.nodeid = medusaNode(1,0);	% Medusa RF module for Tx (module address 0)

psd.grad.nodeid = hex2dec('010800');	% Medusa Gradient module
medusaConnect
medusaReset(psd.ctrl.nodeid)
concmd32(sock, hex2dec('011000'), hex2dec('42'), hex2dec('4'));

psd.id = 101;



% setup sample rates
%psd.rfrx.smpclk = 500e3/8;	% set Rx sample rate in Hz (must be 500kHz/(2^N))
psd.rfrx.smpclk = 44100;	% set Rx sample rate in Hz (must be 500kHz/(2^N))
psd.rftx.smpclk = psd.rfrx.smpclk;
psd.grad.smpclk = psd.rfrx.smpclk;
psd.ctrl.smpclk = psd.rfrx.smpclk;

%psd.grad.smpclk = 500e3/2;
%psd.ctrl.smpclk = psd.grad.smpclk;

% set RF receiver gain
psd.rfrx.gain = 4;

% setup frequencies
freq = 87.5e6;
psd.rfrx.freq = freq;	% carrier frequency in Hz
psd.rftx.freq = freq;	% carrier frequency in Hz

% load music file
	fprintf('Loading audio file, please wait...');
    
    which_song = ceil(rand*5);
    
	%[Yaudio,FS,NBITS]=mp3read('u2.mp3'); filename = 'scan_u2';
    if which_song == 1
        [Yaudio,FS,NBITS]=mp3read('u2a.mp3'); filename = 'scan_u2a';
    elseif which_song == 2
        [Yaudio,FS,NBITS]=mp3read('u2.mp3'); filename = 'scan_u2';
    elseif which_song == 3
	    [Yaudio,FS,NBITS]=mp3read('nova.mp3'); filename = 'scan_nova';
    elseif which_song == 4
        [Yaudio,FS,NBITS]=mp3read('dota.mp3'); filename = 'scan_dota';
    elseif which_song == 5
        [Yaudio,FS,NBITS]=mp3read('yam.mp3'); filename = 'scan_yam';
    end

 %  [Yaudio,FS,NBITS]=mp3read('brahms_sonata_1st_movement.mp3'); filename = 'scan_brahms';
 %  	[Yaudio,FS,NBITS]=mp3read('dumont_gravis.mp3'); filename = 'scan_dumont';
  % 	[Yaudio,FS,NBITS]=mp3read('Dumont.mp3'); filename = 'scan_dumont';

    % [Yaudio,FS,NBITS]=mp3read('tessellate.mp3'); filename = 'scan_tess';
	%[Yaudio,FS,NBITS]=mp3read('yam.mp3'); filename = 'scan_yam';
	%[Yaudio,FS,NBITS]=mp3read('neo.mp3'); filename = 'scan_neo';
	%[Yaudio,FS,NBITS]=mp3read('nova.mp3'); filename = 'scan_nova';
	%[Yaudio,FS,NBITS]=mp3read('dota.mp3'); filename = 'scan_dota';
	Yaudio = int16(Yaudio*32767);
	fprintf('Done.\nFile sampling frequency = %8.0f\n', FS);


% setup scan parameters
tr = 100e-3;					% repeat time
trstart = 1;

% determine number of trs
Ntr = floor(length(Yaudio)/(tr*psd.ctrl.smpclk) );
Ntr = min(Ntr,1000);
% truncate audio
Yaudio = Yaudio(1:round(Ntr*tr*psd.ctrl.smpclk),1:2);

% make RFtx
fprintf('Creating PSD.RFTX...\n');
rftx_amp = 0.25;
% use FM modulation
psd.rftx.data = repmat(1i, 1, length(Yaudio));
psd.rftx.data(1,:) = 1.0*exp(-1i*(cumsum(  (double(Yaudio(:,1))+double(Yaudio(:,2)))/32767  )*rftx_amp*(2*pi)));
%psd.rftx.data(1:2:(2*length(Yaudio))) = 4095;
%psd.rftx.data(2:2:(2*length(Yaudio))) = mod(round(cumsum(Yaudio(:,1)+Yaudio(:,2))*16384/(2*pi)), 16384);

% make RFrx
psd.rfrx.data = [];

% make gradients
fprintf('Creating PSD.GRAD...\n');
% send direct wave
psd.grad.data = repmat((0), 5, length(Yaudio));
%psd.grad.data(1,:) = int16( double(Yaudio(:,1))*grad_amp*32767 );
%psd.grad.data(2,:) = int16( double(Yaudio(:,2))*grad_amp*32767 );
psd.grad.data(1,:) = ( double(Yaudio(:,1))*grad_amp );
psd.grad.data(2,:) = ( double(Yaudio(:,2))*grad_amp );
psd.grad.data(3,:) = ( double(Yaudio(:,1))*grad_amp );
psd.grad.data(4,:) = ( double(Yaudio(:,2))*grad_amp );
psd.grad.data(5,:) = (0);

%clear Yaudio

% setup TR parameters
fprintf('Setting PSD parameters...\n');
% controller
psd.ctrl.trlength = tr*psd.ctrl.smpclk;
psd.ctrl.ntrs = Ntr;
% receiver
psd.rfrx.start = 0;
psd.rfrx.length = tr*psd.ctrl.smpclk;
%psd.rfrx.length = length(psd.rfrx.data)/Ntr;
%psd.rfrx.data = zeros(1,Ntr * psd.rfrx.length);
% transmitter
psd.rftx.start = 0;
psd.rftx.length = length(psd.rftx.data)/Ntr;
% gradients
psd.grad.start = 0;
psd.grad.length = length(psd.grad.data)/Ntr;

if(1)
% PSD stats
fprintf('PSD ID#  : %1.0f\n', psd.id);
fprintf('Scan time: %8.2f sec (%1.0f TRs of %1.0f ms)\n', Ntr*tr, Ntr, tr*1000);
fprintf('RFTx data: %8.0f samples (%6.0f Kb)\n', size(psd.rftx.data,2), 2*2*size(psd.rftx.data,2)/1024 );
fprintf('RFRx data: %8.0f samples (%6.0f Kb)\n', size(psd.rfrx.data,2), 2*2*size(psd.rfrx.data,2)/1024 );
fprintf('Grad data: %8.0f samples (%6.0f Kb)\n', length(psd.grad.data), 2*5*length(psd.grad.data)/1024 );
fprintf('----------------------------------------\n')
% PSD info
fprintf('TR=  %7.2fms  (%7.0f samples)\n', tr*1000,  tr*psd.rfrx.smpclk );
fprintf('----------------------------------------\n')
end

% plot the sequence
fprintf('Plotting...\n')
%psdPlotRG(100,psd);
%psdPlotMD(100,psd,0,-0.1);
%psdPlotOV(100,psd,0,-0.1);
fprintf('----------------------------------------\n')

medusaPsdConfigure(psd);
medusaPsdRunStream(psd);