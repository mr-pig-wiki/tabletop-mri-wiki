function varargout = IMAGING_GUI_2(varargin)
%
%  VERSION NOTES
%  V4.0 RELEASED FEBRUARY, 2014 BY JASON STOCKMANN
%  EMAIL JAYSTOCK@NMR.MGH.HARVARD.EDU WITH QUESTIONS
%
%  FOR RELEASE NOTES AND FEATURES/BUG FIXES, PLEASE SEE:
%  https://gate.nmr.mgh.harvard.edu/wiki/Tabletop_MRI/index.php/Hardware:SourceCode
% 

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @IMAGING_GUI_2_OpeningFcn, ...
                   'gui_OutputFcn',  @IMAGING_GUI_2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before IMAGING_GUI_2 is made visible.
function IMAGING_GUI_2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to IMAGING_GUI_2 (see VARARGIN)

% Choose default command line output for IMAGING_GUI_2
handles.output = hObject;

% shim scaling factor from GPA output signal to mA
psd.shim_scale_factor = 10500;

% set frequency to value saved in text file by FID_GUI
psd.f0_setting_path = fileparts(which('FID_GUI.m'));



fid = fopen([psd.f0_setting_path,'\f0_setting.mat']);
if fid == -1,
    psd.f0 = 8.15;  % choose some arbitrary value in case f0_setting file doesn't exist
    save([psd.f0_setting_path,'\f0_setting.mat'],'f0')
    disp(['Couldn''t find f0_setting.mat... Defaulting frequency to ',num2str(psd.f0)])
else
    load([psd.f0_setting_path,'\f0_setting.mat'])
    psd.f0 = f0;
    set(handles.f0,'String',num2str(psd.f0));
    disp(['Frequency of last scan was ',num2str(f0)])
end

fclose(fid)



% Update handles structure
guidata(hObject, handles);

% UIWAIT makes IMAGING_GUI_2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = IMAGING_GUI_2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function f0_Callback(hObject, eventdata, handles)
% hObject    handle to f0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of f0 as text
%        str2double(get(hObject,'String')) returns contents of f0 as a double
global psd

psd.f0 = str2num(get(handles.f0,'String'));  f0 = psd.f0;
psd.fid = 0;
psd.ctrl.nodeid = medusaNode(1);	% Medusa Controller #1
psd.rfrx.nodeid = medusaNode(1,0);	% Medusa RF module for Rx (module address 0)
psd.rftx.nodeid = medusaNode(1,0);	% Medusa RF module for Tx (module address 0)

psd.grad.nodeid = hex2dec('010800');	% Medusa Gradient module
%medusaConnect
% medusaReset(psd.ctrl.nodeid)

f0_setting_path = fileparts(mfilename('fullpath'));
% temp_path = fileparts(which('SE_PROJ_GUI.m'))
%f0_setting_path = regexprep(temp_path,'.\gui','')
f0_setting = fullfile(f0_setting_path,'.\f0.mat');

save('f0_setting','f0')


% --- Executes during object creation, after setting all properties.
function f0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to f0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tr_Callback(hObject, eventdata, handles)
% hObject    handle to tr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tr as text
%        str2double(get(hObject,'String')) returns contents of tr as a double
global psd
psd.tr = str2num(get(handles.tr,'String'));


% --- Executes during object creation, after setting all properties.
function tr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tro_Callback(hObject, eventdata, handles)
% hObject    handle to tro (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tro as text
%        str2double(get(hObject,'String')) returns contents of tro as a double
global psd
psd.tro = str2num(get(handles.tro,'String'));
psd.rfrx.smpclk = str2num(get(handles.RX_BW,'String'));

psd.matrix_size_ro = floor(psd.tro*1e-3*psd.rfrx.smpclk);
set(handles.matrix_size_ro,'String',num2str(psd.matrix_size_ro));



% --- Executes during object creation, after setting all properties.
function tro_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tro (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end







function num_ave_Callback(hObject, eventdata, handles)
% hObject    handle to num_ave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of num_ave as text
%        str2double(get(hObject,'String')) returns contents of num_ave as a double


% --- Executes during object creation, after setting all properties.
function num_ave_CreateFcn(hObject, eventdata, handles)
% hObject    handle to num_ave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function rftx_amp_90_Callback(hObject, eventdata, handles)
% hObject    handle to rftx_amp_90 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global psd
% Hints: get(hObject,'String') returns contents of rftx_amp_90 as text
%        str2double(get(hObject,'String')) returns contents of rftx_amp_90 as a double
psd.rftx_amp_90 = str2num(get(handles.rftx_amp_90,'String'));


% --- Executes during object creation, after setting all properties.
function rftx_amp_90_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rftx_amp_90 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function rftx_amp_180_Callback(hObject, eventdata, handles)
% hObject    handle to rftx_amp_180 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global psd
% Hints: get(hObject,'String') returns contents of rftx_amp_180 as text
%        str2double(get(hObject,'String')) returns contents of rftx_amp_180 as a double
psd.rftx_amp_180 = str2num(get(handles.rftx_amp_180,'String'));


% --- Executes during object creation, after setting all properties.
function rftx_amp_180_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rftx_amp_180 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function file_path_string_Callback(hObject, eventdata, handles)
% hObject    handle to file_path_string (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of file_path_string as text
%        str2double(get(hObject,'String')) returns contents of file_path_string as a double


% --- Executes during object creation, after setting all properties.
function file_path_string_CreateFcn(hObject, eventdata, handles)
% hObject    handle to file_path_string (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in save_button.
function save_button_Callback(hObject, eventdata, handles)
% hObject    handle to save_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global psd

%grad_data = psd.grad.data;
%rftx_data = psd.rftx.data;
data = psd.data;
data_ave = psd.data_ave;
%output = [readout time spec freq_axis];

% browse to folder where shim settings are saved

save([get(handles.file_path_string,'String')],'data','data_ave')

set(handles.system_status,'ForegroundColor',[0 1 0])
set(handles.system_status,'String','OUTPUT DATA SAVED')




% --- Executes on selection change in imaging_popupmenu.
function imaging_popupmenu_Callback(hObject, eventdata, handles)
% hObject    handle to imaging_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns imaging_popupmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from imaging_popupmenu
global psd

popup_sel_index = get(handles.imaging_popupmenu, 'Value');
switch popup_sel_index
     case 1
         psd.which_seq = 'spin echo imaging'; 
         set(handles.te_se,'Visible','on');
         set(handles.te_tse,'Visible','off');
         
           
         set(handles.matrix_size_pe1_se,'Visible','on')
         set(handles.matrix_size_pe2_se,'Visible','on')
         
         set(handles.matrix_size_pe1_tse,'Visible','off')
         set(handles.matrix_size_pe2_tse,'Visible','off')
         
         set(handles.tro_tse,'Visible','off')
         set(handles.tro,'Visible','on')
         
         psd.tro = str2num(get(handles.tro,'String'))
         psd.matrix_size_ro = floor(psd.tro*1e-3*psd.rfrx.smpclk);
         set(handles.matrix_size_ro,'String',num2str(psd.matrix_size_ro))

         set(handles.sequence_plot_2,'Visible','off');
                
     case 2

         psd.which_seq = 'turbo spin echo imaging';
         set(handles.te_se,'Visible','off');
         set(handles.te_tse,'Visible','off');
           
         set(handles.matrix_size_pe1_se,'Visible','off')
         set(handles.matrix_size_pe2_se,'Visible','off')
         
         set(handles.matrix_size_pe1_tse,'Visible','on')
         set(handles.matrix_size_pe2_tse,'Visible','on')
         
         set(handles.tro_tse,'Visible','on')
         set(handles.tro,'Visible','off')

         set(handles.sequence_plot_2,'Visible','off');

             possible_tro_tse = [3.08];
             possible_matrix_sizes_pe1_tse = [72];
             possible_matrix_sizes_pe2_tse = [1 2 4 6 8 10 12 14 16 18 20 22 24];

            ind = get(handles.tro_tse,'Value');
            psd.tro_tse = possible_tro_tse(ind);
            psd.matrix_size_ro = floor(psd.tro_tse*1e-3*psd.rfrx.smpclk);
            set(handles.matrix_size_ro,'String',num2str(psd.matrix_size_ro))

         
end




% --- Executes during object creation, after setting all properties.
function imaging_popupmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to imaging_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in load_shims_button.
function load_shims_button_Callback(hObject, eventdata, handles)
% hObject    handle to load_shims_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global psd
shim_settings_path = fileparts(mfilename('fullpath'));
% temp_path = fileparts(which('SE_PROJ_GUI.m'))
%shim_settings_path = regexprep(temp_path,'.\gui','')
shim_settings = fullfile(shim_settings_path, 'shims.mat');

load(shim_settings);

psd.shims = shims;
set(handles.x_shim_setting,'String',num2str(round(psd.shim_scale_factor*psd.shims(1))));
set(handles.y_shim_setting,'String',num2str(round(psd.shim_scale_factor*psd.shims(2))));
set(handles.z_shim_setting,'String',num2str(round(psd.shim_scale_factor*psd.shims(3))));




% --- Executes on button press in zero_shims_button.
function zero_shims_button_Callback(hObject, eventdata, handles)
% hObject    handle to zero_shims_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
psd.shims = [0 0 0];
set(handles.x_shim_setting,'String',num2str(psd.shims(1)))
set(handles.y_shim_setting,'String',num2str(psd.shims(2)))
set(handles.z_shim_setting,'String',num2str(psd.shims(3)))



% --- Executes on button press in toggle_stop_button.
function toggle_stop_button_Callback(hObject, eventdata, handles)
% hObject    handle to toggle_stop_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function FOV_ro_Callback(hObject, eventdata, handles)
% hObject    handle to FOV_ro (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of FOV_ro as text
%        str2double(get(hObject,'String')) returns contents of FOV_ro as a double


% --- Executes during object creation, after setting all properties.
function FOV_ro_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FOV_ro (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function FOV_pe1_Callback(hObject, eventdata, handles)
% hObject    handle to FOV_pe1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of FOV_pe1 as text
%        str2double(get(hObject,'String')) returns contents of FOV_pe1 as a double


% --- Executes during object creation, after setting all properties.
function FOV_pe1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FOV_pe1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function FOV_pe2_Callback(hObject, eventdata, handles)
% hObject    handle to FOV_pe2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of FOV_pe2 as text
%        str2double(get(hObject,'String')) returns contents of FOV_pe2 as a double


% --- Executes during object creation, after setting all properties.
function FOV_pe2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FOV_pe2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end








function RX_gain_Callback(hObject, eventdata, handles)
% hObject    handle to RX_gain (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of RX_gain as text
%        str2double(get(hObject,'String')) returns contents of RX_gain as a double
global psd
% hObject    handle to RX_gain (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of RX_gain as text
%        str2double(get(hObject,'String')) returns contents of RX_gain as a double
psd.rfrx.gain = str2num(get(handles.RX_gain,'String'));
psd.rfrx.gain

set(handles.system_status,'ForegroundColor',[0 1 0]);
set(handles.system_status,'String','SYSTEM STATUS: NORMAL');


if psd.rfrx.gain  < -9, psd.rfrx.gain = -9; set(handles.RX_gain,'String',num2str(psd.rfrx.gain)); 
  set(handles.system_status,'ForegroundColor',[1 0 0])
  set(handles.system_status,'String','ERROR: RECEIVE GAIN MUST BE BETWEEN -9 and +6 DB')
end
if psd.rfrx.gain > 6, psd.rfrx.gain = 6; set(handles.RX_gain,'String',num2str(psd.rfrx.gain));
  set(handles.system_status,'ForegroundColor',[1 0 0])
  set(handles.system_status,'String','ERROR: RECEIVE GAIN MUST BE BETWEEN -9 and +6 DB')
end


% --- Executes during object creation, after setting all properties.
function RX_gain_CreateFcn(hObject, eventdata, handles)
% hObject    handle to RX_gain (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function matrix_size_pe1_se_Callback(hObject, eventdata, handles)
% hObject    handle to matrix_size_pe1_se (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global psd
% Hints: get(hObject,'String') returns contents of matrix_size_pe1_se as text
%        str2double(get(hObject,'String')) returns contents of matrix_size_pe1_se as a double
psd.matrix_size(2) = str2num(get(handles.matrix_size_pe1_se,'String'));



% --- Executes during object creation, after setting all properties.
function matrix_size_pe1_se_CreateFcn(hObject, eventdata, handles)
% hObject    handle to matrix_size_pe1_se (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function matrix_size_pe2_se_Callback(hObject, eventdata, handles)
% hObject    handle to matrix_size_pe2_se (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global psd
% Hints: get(hObject,'String') returns contents of matrix_size_pe2_se as text
%        str2double(get(hObject,'String')) returns contents of matrix_size_pe2_se as a double
psd.matrix_size(2) = str2num(get(handles.matrix_size_pe2_se,'String'));



% --- Executes during object creation, after setting all properties.
function matrix_size_pe2_se_CreateFcn(hObject, eventdata, handles)
% hObject    handle to matrix_size_pe2_se (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





% --- Executes during object creation, after setting all properties.
function slice_orientation_popupmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slice_orientation_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in slice_orientation_popupmenu.
function slice_orientation_popupmenu_Callback(hObject, eventdata, handles)
% hObject    handle to slice_orientation_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns slice_orientation_popupmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from slice_orientation_popupmenu
global psd

popup_sel_index = get(handles.slice_orientation_popupmenu, 'Value')
switch popup_sel_index
     case 1
         psd.slice_orientation = 'XZ';  
     case 2
         psd.slice_orientation = 'XY'
     case 3
         psd.slice_orientation = 'YZ'
     case 4
         psd.slice_orientation = 'ZX'
    case 5
         psd.slice_orientation = 'YX'
    case 6
         psd.slice_orientation = 'ZY'
end

   



function te_se_Callback(hObject, eventdata, handles)
% hObject    handle to te_se (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of te_se as text
%        str2double(get(hObject,'String')) returns contents of te_se as a double
global psd
psd.te_se = str2num(get(handles.te_se,'String'))


% --- Executes during object creation, after setting all properties.
function te_se_CreateFcn(hObject, eventdata, handles)
% hObject    handle to te_se (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in te_tse.
function te_tse_Callback(hObject, eventdata, handles)
% hObject    handle to te_tse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns te_tse contents as cell array
%        contents{get(hObject,'Value')} returns selected item from te_tse
global psd
psd.te_tse = str2num(get(handles.te_tse,'String'))

popup_sel_index = get(handles.te_tse, 'Value')
switch popup_sel_index
     case 1
         psd.te_tse = 4;  
     case 2
         psd.te_tse = 6;  
     case 3
         psd.te_tse = 8;  
     case 4
         psd.te_tse = 10;  
end



% --- Executes during object creation, after setting all properties.
function te_tse_CreateFcn(hObject, eventdata, handles)
% hObject    handle to te_tse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





% --- Executes on selection change in matrix_size_pe2_tse.
function matrix_size_pe2_tse_Callback(hObject, eventdata, handles)
% hObject    handle to matrix_size_pe2_tse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns matrix_size_pe2_tse contents as cell array
%        contents{get(hObject,'Value')} returns selected item from matrix_size_pe2_tse


% --- Executes during object creation, after setting all properties.
function matrix_size_pe2_tse_CreateFcn(hObject, eventdata, handles)
% hObject    handle to matrix_size_pe2_tse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on selection change in matrix_size_pe1_tse.
function matrix_size_pe1_tse_Callback(hObject, eventdata, handles)
% hObject    handle to matrix_size_pe1_tse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns matrix_size_pe1_tse contents as cell array
%        contents{get(hObject,'Value')} returns selected item from matrix_size_pe1_tse


% --- Executes during object creation, after setting all properties.
function matrix_size_pe1_tse_CreateFcn(hObject, eventdata, handles)
% hObject    handle to matrix_size_pe1_tse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on selection change in tro_tse.
function tro_tse_Callback(hObject, eventdata, handles)
% hObject    handle to tro_tse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns tro_tse contents as cell array
%        contents{get(hObject,'Value')} returns selected item from tro_tse


% --- Executes during object creation, after setting all properties.
function tro_tse_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tro_tse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end






















% --- Executes on button press in run_scan_button.
function run_scan_button_Callback(hObject, eventdata, handles)
% hObject    handle to run_scan_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global psd
global H



psd.id = 100;   psd.fid = 0;
psd.ctrl.nodeid = hex2dec('011000');	% Medusa Controller
psd.rfrx.nodeid = hex2dec('010000');	% Medusa RF module for Rx
psd.rftx.nodeid = hex2dec('010000');	% Medusa RF module for Tx
psd.grad.nodeid = hex2dec('010800');	% Medusa Gradient module
medusaConnect

H.sequence_plot = handles.sequence_plot;
H.sequence_plot_2 = handles.sequence_plot_2;
H.readout_plot = handles.readout_plot;
H.projection_plot = handles.projection_plot;
H.kspace_plot = handles.kspace_plot;
H.image_plot = handles.image_plot;

H.toggle_stop_button = handles.toggle_stop_button;
set(handles.toggle_stop_button,'Value',0);


% input parameters into psd data structure
psd.f0 = str2num(get(handles.f0,'String'));
psd.tr = str2num(get(handles.tr,'String'))
psd.num_ave = str2num(get(handles.num_ave,'String'));

psd.FOV_ro = str2num(get(handles.FOV_ro,'String'));
psd.FOV_pe1 = str2num(get(handles.FOV_pe1,'String'));
psd.FOV_pe2 = str2num(get(handles.FOV_pe2,'String'));

psd.rftx_amp_90 = str2num(get(handles.rftx_amp_90,'String'));
psd.rftx_amp_180 = str2num(get(handles.rftx_amp_180,'String'));

psd.RX_gain = str2num(get(handles.RX_gain,'String'));


popup_sel_index = get(handles.slice_orientation_popupmenu, 'Value')
switch popup_sel_index
     case 1
         psd.slice_orientation = 'XZ';  
     case 2
         psd.slice_orientation = 'XY';
     case 3
         psd.slice_orientation = 'YZ';
     case 4
         psd.slice_orientation = 'ZX';
    case 5
         psd.slice_orientation = 'YX';
    case 6
         psd.slice_orientation = 'ZY';
end


popup_sel_index = get(handles.imaging_popupmenu, 'Value')
switch popup_sel_index
     case 1
         psd.which_seq = 'spin echo imaging'; 
         set(handles.te_se,'Visible','on');
         set(handles.te_tse,'Visible','off');
         psd.te_se = str2num(get(handles.te_se,'String'));
         set(handles.sequence_plot_2,'Visible','off');


     case 2
         psd.which_seq = 'turbo spin echo imaging';
         set(handles.te_se,'Visible','off');
         set(handles.te_tse,'Visible','off');
         set(handles.sequence_plot_2,'Visible','off');

            popup_sel_index_2 = get(handles.te_tse, 'Value');
            switch popup_sel_index_2
                 case 1
                     psd.te_tse = 4;  
                 case 2
                     psd.te_tse = 6;  
                 case 3
                     psd.te_tse = 8;  
                 case 4
                     psd.te_tse = 10;  
            end
         
end

% set shims
if isfield(psd,'shims') == 0, 
    psd.shims = [0 0 0];  
else
    shim_settings_path = fileparts(mfilename('fullpath'));
    % temp_path = fileparts(which('SE_PROJ_GUI.m'))
    %shim_settings_path = regexprep(temp_path,'.\gui','')
    shim_settings = fullfile(shim_settings_path, 'shims.mat');
    load(shim_settings);
    psd.shims = shims;
end

% hard code the sampling bandwidths for imaging sequences
psd.grad.smpclk = 500e3/16;  
psd.ctrl.smpclk = 500e3/16;
psd.rftx.smpclk = 500e3/16;
psd.rfrx.smpclk = 500e3/16;

set(handles.RX_BW,'String',num2str(psd.rfrx.smpclk));  % update rfrx sampling clock in GUI

% set tansmit pulse duration for 90 deg and 180 deg pulses
psd.rftx_time_90 = 160e-6;  set(handles.rftx_time_90,'String',num2str(psd.rftx_time_90*1e6));
psd.rftx_time_180 = 160e-6;  set(handles.rftx_time_180,'String',num2str(psd.rftx_time_180*1e6));

psd.tro = str2num(get(handles.tro,'String'));
psd.matrix_size_ro = floor(psd.tro*1e-3*psd.rfrx.smpclk);
set(handles.matrix_size_ro,'String',num2str(psd.matrix_size_ro));




%% ============================ RUN SEQUENCE ==============================

if strcmp(psd.which_seq,'spin echo imaging')
    
    % read in desired matrix size
 %   psd.matrix_size_ro = str2num(get(handles.matrix_size_ro,'String'));
    psd.matrix_size_ro = floor(psd.tro*1e-3*psd.rfrx.smpclk);

    psd.tro = str2num(get(handles.tro,'String'));
    psd.matrix_size_pe1_se = str2num(get(handles.matrix_size_pe1_se,'String'));
    psd.matrix_size_pe2_se = str2num(get(handles.matrix_size_pe2_se,'String'));
    H.toggle_button_stop = 0;
    
    [SE] = SE_IMAGING_FUNC;
    
elseif strcmp(psd.which_seq,'turbo spin echo imaging')
    psd.te_tse = 4;
    possible_tro_tse = [3.08];
    possible_matrix_sizes_pe1_tse = [72];
    possible_matrix_sizes_pe2_tse = [1 2 4 6 8 10 12 14 16 18 20 22 24];

    ind = get(handles.tro_tse,'Value');
    psd.tro_tse = possible_tro_tse(ind);
    psd.matrix_size_ro = floor(psd.tro_tse*1e-3*psd.rfrx.smpclk);
    set(handles.matrix_size_ro,'String',num2str(psd.matrix_size_ro))

        
    ind = get(handles.matrix_size_pe1_tse,'Value');
    psd.matrix_size_pe1_tse = possible_matrix_sizes_pe1_tse(ind);
    ind = get(handles.matrix_size_pe2_tse,'Value');
    psd.matrix_size_pe2_tse = possible_matrix_sizes_pe2_tse(ind);
    
    
    [TSE] = TSE_IMAGING_FUNC;
    
end

% =========================================================================
